package com.libs.smarteist.autoimageslider.IndicatorView.animation.data;

public interface Value {/*empty*/
}
