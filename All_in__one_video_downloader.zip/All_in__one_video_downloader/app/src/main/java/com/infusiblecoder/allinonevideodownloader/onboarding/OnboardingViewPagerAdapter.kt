package com.infusiblecoder.allinonevideodownloader.onboarding

import android.content.Context
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.infusiblecoder.allinonevideodownloader.R

class OnboardingViewPagerAdapter(
    fragmentActivity: FragmentActivity,
    private val context: Context
) : FragmentStateAdapter(fragmentActivity) {

    private val colors = listOf(
        R.color.colorPrimaryDark,
        R.color.colorPrimary,
        R.color.black_colorAccent,
        R.color.black_colorAccent
    ).map { colorRes ->
        "#" + Integer.toHexString(ContextCompat.getColor(context, colorRes) and 0x00FFFFFF)
    }

    private val titles = listOf(
        R.string.title_onboarding_1,
        R.string.title_onboarding_2,
        R.string.title_onboarding_3,
        R.string.title_onboarding_4
    )

    private val descriptions = listOf(
        R.string.description_onboarding_1,
        R.string.description_onboarding_2,
        R.string.description_onboarding_3,
        R.string.description_onboarding_4
    )

    private val animations = listOf(
        R.raw.ani1,
        R.raw.ani2,
        R.raw.ani3,
        R.raw.ani4
    )

    override fun createFragment(position: Int): Fragment {
        return OnboardingFragment.newInstance(
            context.getString(titles[position]),
            context.getString(descriptions[position]),
            animations[position],
            colors[position]
        )
    }

    override fun getItemCount(): Int = titles.size


}
