/*
 * *
 * * Created by Syed Usama Ahmad on 3/17/23, 11:37 PM
 * * Copyright (c) 2023 . All rights reserved.
 * * Last modified 3/17/23, 11:01 PM
 *
 */

@file:Suppress("DEPRECATION")

package com.infusiblecoder.allinonevideodownloader.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.app.Dialog
import android.app.NotificationManager
import android.app.ProgressDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.os.PowerManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.Keep
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.ump.ConsentForm
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.infusiblecoder.allinonevideodownloader.BuildConfig
import com.infusiblecoder.allinonevideodownloader.R
import com.infusiblecoder.allinonevideodownloader.databinding.ActivityMainBinding
import com.infusiblecoder.allinonevideodownloader.fragments.DownloadMainFragment
import com.infusiblecoder.allinonevideodownloader.inappbilling.BillingClientSetup
import com.infusiblecoder.allinonevideodownloader.models.adminpanel.Setting
import com.infusiblecoder.allinonevideodownloader.utils.AdsManager
import com.infusiblecoder.allinonevideodownloader.utils.Constants
import com.infusiblecoder.allinonevideodownloader.utils.LocaleHelper
import com.infusiblecoder.allinonevideodownloader.utils.SharedPrefsMainApp
import com.infusiblecoder.allinonevideodownloader.utils.iUtils
import com.infusiblecoder.allinonevideodownloader.webservices.DownloadVideosMain
import com.suddenh4x.ratingdialog.AppRating
import com.suddenh4x.ratingdialog.preferences.RatingThreshold
import java.util.concurrent.Executor
import kotlin.system.exitProcess

@Keep
class MainActivity : AppCompatActivity() {

    val AUTO_START_INTENTS = arrayOf(
        Intent().setComponent(ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
        Intent("miui.intent.action.OP_AUTO_START").addCategory("android.intent.category.DEFAULT"),
        Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
        Intent().setComponent(ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")),
        Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),
        Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
        Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
        Intent().setComponent(ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")),
        Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
        Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
        Intent().setComponent(ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
        Intent().setComponent(ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.entry.FunctionActivity")).setData(Uri.parse("mobilemanager://function/entry/AutoStart"))
    )

    private var mBottomSheetDialog: BottomSheetDialog? = null
    private var nn: String? = "nnn"
    private var myString: String? = ""
    private val REQUEST_PERMISSION_CODE = 1001
    private val requiredPermissions = arrayOf(
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
    )

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val requiredPermissionsTIRAMISU = arrayOf(
        android.Manifest.permission.READ_MEDIA_IMAGES,
        android.Manifest.permission.READ_MEDIA_VIDEO,
        android.Manifest.permission.READ_MEDIA_AUDIO
    )

    private lateinit var progressDralogGenaratinglink: ProgressDialog

    private val APP_UPDATE_REQUEST_CODE = 261

    private var billingClient: BillingClient? = null

    var fragment: Fragment? = null
    private lateinit var binding: ActivityMainBinding
    private var biometricPrompt: BiometricPrompt? = null
    private var promptInfo: BiometricPrompt.PromptInfo? = null
    private lateinit var requestPermissionsLauncher: ActivityResultLauncher<Array<String>>
    private var hasNotificationPermissionGranted = false

    private lateinit var consentInformation: ConsentInformation
    private lateinit var consentForm: ConsentForm

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            val view = binding.root
            view.keepScreenOn = true
            enableEdgeToEdge()
            setContentView(view)

        } catch (e: Throwable) {
            e.printStackTrace()
        }

        try {
            requestPermissionsLauncher =
                registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                    if (SDK_INT >= 33 && requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }) {
                        val manager = getSystemService(NotificationManager::class.java)
                        val areNotificationsEnabled = manager.areNotificationsEnabled()

                        if (!areNotificationsEnabled) {
                            showNotificationPermissionRationale()
                        } else {
                            batteryRestrictionPermission()
                            batteryRestrictionPermissionIgnoreBatteryOptimization()
                        }
                    } else {
                        hasNotificationPermissionGranted = true
                    }
                    setLayout()
                }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }) {
                    if (SDK_INT >= 33) {
                        val manager = getSystemService(NotificationManager::class.java)
                        val areNotificationsEnabled = manager.areNotificationsEnabled()

                        if (!areNotificationsEnabled) {
                            showNotificationPermissionRationale()
                        } else {
                            batteryRestrictionPermission()
                            batteryRestrictionPermissionIgnoreBatteryOptimization()
                        }
                    } else {
                        hasNotificationPermissionGranted = true
                    }
                    setLayout()
                } else {
                    showStoragePermissionRationale()
                }
            } else {
                if (requiredPermissions.all { isPermissionGranted(it) }) {
                    setLayout()
                } else {
                    showStoragePermissionRationale()
                    runpermissioncheck()
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            progressDralogGenaratinglink = ProgressDialog(this@MainActivity)
            progressDralogGenaratinglink.setMessage(resources.getString(R.string.genarating_download_link))
            progressDralogGenaratinglink.setCancelable(false)

            val action = intent.action
            val type = intent.type

            if (Intent.ACTION_SEND == action && type != null) {
                if ("text/plain" == type) {
                    SplashScreen.initDlLibs(this@MainActivity, false)
                    handleSendText(intent)
                }
            }

            if (SDK_INT > 27) {
                AppRating.Builder(this)
                    .setMinimumLaunchTimes(5)
                    .setMinimumDays(5)
                    .setMinimumLaunchTimesToShowAgain(5)
                    .setMinimumDaysToShowAgain(10)
                    .setRatingThreshold(RatingThreshold.FOUR)
                    .showIfMeetsConditions()
            }

            doAllBioMetricTasks()
            initIInAppBillingAcknologement()

            if (!Constants.show_subscription) {
                binding.subscriptionFab.visibility = View.GONE
            } else {
                if (!BuildConfig.ISPRO) {
                    openAdsConsentDialog()
                    binding.subscriptionFab.visibility = View.VISIBLE
                    binding.subscriptionFab.setOnClickListener {
                        try {
                            if (iUtils.isSubactive) {
                                runOnUiThread {
                                    iUtils.ShowToast(this@MainActivity, resources.getString(R.string.youhavealready))
                                }
                            } else {
                                startActivity(Intent(this@MainActivity, SubscriptionActivity::class.java))
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                } else {
                    binding.subscriptionFab.visibility = View.GONE
                }
            }

            if (Constants.show_Ads && !BuildConfig.ISPRO && AdsManager.status_AdmobBanner) {
                val pp = SharedPrefsMainApp(this@MainActivity).preferencE_inappads
                if (pp.equals("nnn")) {
                    MobileAds.initialize(this@MainActivity) {
                        AdsManager.loadBannerAdAsync(this@MainActivity, binding.bannerContainer)
                    }
                } else {
                    binding.bannerContainer.visibility = View.GONE
                }
            } else {
                binding.bannerContainer.visibility = View.GONE
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    fun batteryRestrictionPermissionIgnoreBatteryOptimization() {
        val packageName = packageName
        if (!(getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)) {
            androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Remove Battery Restrictions")
                .setMessage("Please set Battery to \'No restrictions\' to allow App to run in the background, else our services wont be able to function")
                .setCancelable(false)
                .setPositiveButton("ALLOW") { _, _ ->
                    val intent1 = Intent()
                    intent1.action = "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"
                    intent1.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    val sb = "package:$packageName"
                    intent1.data = Uri.parse(sb)
                    startActivity(intent1)
                }
                .show()
        }
    }

    fun batteryRestrictionPermission() {
        val sh = getSharedPreferences("SETUP", MODE_PRIVATE)
        val isPermission = sh.getBoolean("permission", false)
        if (!isPermission) {
            for (intent1 in AUTO_START_INTENTS) if (packageManager.resolveActivity(intent1, PackageManager.MATCH_DEFAULT_ONLY) != null) {
                androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Enable AutoStart")
                    .setMessage("Please allow App to run in the background, else our services wont be able to function")
                    .setCancelable(false)
                    .setPositiveButton("ALLOW") { _, _ ->
                        try {
                            val edit = getSharedPreferences("SETUP", MODE_PRIVATE).edit()
                            edit.putBoolean("permission", true)
                            edit.apply()

                            for (intent2 in AUTO_START_INTENTS) if (packageManager.resolveActivity(intent2, PackageManager.MATCH_DEFAULT_ONLY) != null) {
                                startActivity(intent2)
                                break
                            }
                        } catch (e: java.lang.Exception) {
                            e.printStackTrace()
                        }
                    }
                    .show()
                break
            }
        }
    }

    private fun openAdsConsentDialog() {
        val params = ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build()
        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        consentInformation.requestConsentInfoUpdate(
            this, params,
            {
                if (consentInformation.isConsentFormAvailable) {
                    loadForm()
                }
            },
            {
                // Handle the error.
            })
    }

    private fun runpermissioncheck() {
        try {
            if (!BuildConfig.DEBUG) {
                verifyAppInstall(iUtils.verifyInstallerId(this@MainActivity))
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun loadForm() {
        UserMessagingPlatform.loadConsentForm(
            this,
            {
                this.consentForm = it
                if (consentInformation.consentStatus == ConsentInformation.ConsentStatus.REQUIRED) {
                    consentForm.show(this) {
                        if (consentInformation.consentStatus == ConsentInformation.ConsentStatus.OBTAINED) {
                            // App can start requesting ads.
                        }
                        loadForm()
                    }
                }
            },
            {
                // Handle the error.
            }
        )
    }

    private fun doAllBioMetricTasks() {
        try {
            val biometricManager: BiometricManager = BiometricManager.from(this@MainActivity)
            when {
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS -> { }
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                    val prefs = getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val editor = prefs.edit()
                    editor.putBoolean("isBio", false)
                    editor.apply()
                }
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                    runOnUiThread {
                        iUtils.ShowToastError(this@MainActivity, "The biometric sensor is currently unavailable")
                    }
                    val prefs = getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val editor = prefs.edit()
                    editor.putBoolean("isBio", false)
                    editor.apply()
                }
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                    val prefs = getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val editor = prefs.edit()
                    editor.putBoolean("isBio", false)
                    editor.apply()
                }
            }

            val executor: Executor = ContextCompat.getMainExecutor(this@MainActivity)
            biometricPrompt = BiometricPrompt(
                this@MainActivity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        runOnUiThread {
                            iUtils.ShowToastError(this@MainActivity, "Error in Authentication $errString")
                        }
                    }

                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        startActivity(Intent(this@MainActivity, GalleryActivity::class.java))
                    }
                })

            promptInfo = BiometricPrompt.PromptInfo.Builder().setTitle("Verify Identity")
                .setDescription("Use your fingerprint or device credentials to Access Gallery ")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build()

            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (!isFinishing) {
                        try {
                            showBottomSheetExitDialog()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            })
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun getBinding(): ActivityMainBinding? {
        return if (::binding.isInitialized) {
            binding
        } else {
            null
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            hasNotificationPermissionGranted = isGranted
            if (!isGranted) {
                if (SDK_INT >= 33) {
                    showNotificationPermissionRationale()
                }
            }
        }

    private fun showNotificationPermissionRationale() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermissionGranted) {
            try {
                if (!isFinishing) {
                    val alertBuilder = androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                    alertBuilder.setCancelable(true)
                    alertBuilder.setTitle(getString(R.string.alert))
                    alertBuilder.setMessage(getString(R.string.notificationpermission))
                    alertBuilder.setPositiveButton(R.string.yes) { _, _ ->
                        if (Build.VERSION.SDK_INT >= 33) {
                            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            hasNotificationPermissionGranted = true
                        }
                    }
                    alertBuilder.setNegativeButton(getString(R.string.cancel), null)
                    val alert = alertBuilder.create()
                    alert.show()
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        } else {
            hasNotificationPermissionGranted = true
        }
    }

    private fun showStoragePermissionRationale() {
        try {
            if (!isFinishing) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }) return
                } else {
                    if (requiredPermissions.all { isPermissionGranted(it) }) return
                }

                val alertBuilder = androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                alertBuilder.setCancelable(true)
                alertBuilder.setTitle(getString(R.string.alert))
                alertBuilder.setMessage(getString(R.string.write_neesory))
                alertBuilder.setPositiveButton(R.string.yes) { _, _ ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (!requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }) {
                            requestPermissionsLauncher.launch(requiredPermissionsTIRAMISU)
                        }
                    } else {
                        if (!requiredPermissions.all { isPermissionGranted(it) }) {
                            requestPermissionsLauncher.launch(requiredPermissions)
                        }
                    }
                }
                alertBuilder.setNegativeButton(getString(R.string.cancel), null)
                val alert = alertBuilder.create()
                alert.show()
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    fun getMyData(): String? {
        return myString
    }

    fun setmydata(mysa: String) {
        this.myString = mysa
    }

    private fun verifyAppInstall(isinatll: Boolean) {
        try {
            println("myappisvalid $isinatll")
            if (!isinatll) {
                if (!isFinishing) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(getString(R.string.please_install))
                        .setCancelable(false)
                        .setMessage(getString(R.string.isappfromplaystore))
                        .setPositiveButton(resources.getString(R.string.installapp)) { dialog, _ ->
                            dialog.dismiss()
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
                        }
                        .setNegativeButton(resources.getString(R.string.useanyway)) { dialog, _ ->
                            dialog.dismiss()
                        }
                        .setIcon(R.drawable.ic_appicon)
                        .show()
                }
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    private fun handleSendText(intent: Intent) {
        try {
            this.intent = null
            var url = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (url.isNullOrEmpty() && iUtils.checkURL(url)) {
                iUtils.ShowToast(this@MainActivity, this@MainActivity.resources?.getString(R.string.enter_valid))
                return
            }

            try {
                url = iUtils.extractUrls(url)[0]
            } catch (e: Exception) { }

            if (url != null) {
                val bundle = Bundle()
                bundle.putString("myinstaurl", url)
                val fragobj = DownloadMainFragment()
                fragobj.arguments = bundle
                this.setmydata(url)
                DownloadVideosMain.Start(this@MainActivity, url.trim(), false)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        try {
            intent.let { newIntent ->
                if (fragment is DownloadMainFragment) {
                    val my: DownloadMainFragment? = fragment as DownloadMainFragment?
                    my?.requireView()?.findViewById<EditText>(R.id.etURL)?.setText(newIntent.getStringExtra(Intent.EXTRA_TEXT).toString())
                    my?.DownloadVideo(newIntent.getStringExtra(Intent.EXTRA_TEXT).toString())
                } else {
                    handleSendText(newIntent)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setLayout() {
        try {
            runpermissioncheck()

            setupViewPager(binding.viewpager)

            // As we removed other fragments, hiding bottom nav to prevent empty tabs crash
            binding.bottomNavBar.visibility = View.GONE
            binding.bottomNavBarNonPlay.visibility = View.GONE

            binding.viewpager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    // Logic removed since bottom navbar is hidden
                }
            })

            binding.viewpager.offscreenPageLimit = 1

        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun setupViewPager(viewPager: ViewPager2) {
        try {
            val adapter = ViewPagerAdapter(supportFragmentManager, lifecycle)
            adapter.addFragment(DownloadMainFragment(), getString(R.string.download_fragment))
            // Removed other fragments as requested (Extra Features, Whatsapp)
            viewPager.adapter = adapter
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun isPermissionGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            if (requestCode == REQUEST_PERMISSION_CODE) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setLayout()
                    restartApp()
                } else {
                    iUtils.ShowToast(this@MainActivity, getString(R.string.info_permission_denied))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            iUtils.ShowToast(this@MainActivity, getString(R.string.info_permission_denied))
            finish()
        }
    }

    private class ViewPagerAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle) :
        FragmentStateAdapter(fragmentManager, lifecycle) {

        private val mFragmentList = ArrayList<Fragment>()
        private val mFragmentTitleList = ArrayList<String>()

        fun addFragment(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun createFragment(position: Int): Fragment {
            return if (position == 0) {
                mFragmentList[0]
            } else mFragmentList[position]
        }

        override fun getItemCount(): Int {
            return mFragmentList.size
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)

        val pp = SharedPrefsMainApp(this@MainActivity).preferencE_inappads
        if (pp.equals("nnn")) {
            menu.findItem(R.id.action_removeads).isVisible = true
        } else if (pp.equals("ppp")) {
            menu.findItem(R.id.action_removeads).isVisible = false
        }

        if (!Constants.show_subscription) {
            menu.findItem(R.id.action_removeads).isVisible = false
        } else {
            menu.findItem(R.id.action_removeads).isVisible = !BuildConfig.ISPRO
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_privacy -> {
                try {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(Setting.getPrivacyPolicy(this@MainActivity, Constants.iSAdminAttached)))
                    startActivity(browserIntent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                true
            }
            R.id.action_rate -> {
                try {
                    if (!isFinishing) {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle(getString(R.string.RateAppTitle))
                            .setMessage(getString(R.string.RateApp))
                            .setCancelable(false)
                            .setPositiveButton(getString(R.string.rate_dialog)) { _, _ ->
                                val appPackageName = packageName
                                try {
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$appPackageName")))
                                } catch (anfe: android.content.ActivityNotFoundException) {
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName")))
                                }
                            }
                            .setNegativeButton(getString(R.string.later_btn), null).show()
                    }
                } catch (e: Exception) {
                }
                true
            }
            R.id.action_share -> {
                try {
                    iUtils.shareApp(this@MainActivity)
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
                true
            }
            R.id.ic_whatapp -> {
                val launchIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launchIntent != null) {
                    startActivity(launchIntent)
                } else {
                    iUtils.ShowToast(this@MainActivity, this.resources.getString(R.string.appnotinstalled))
                }
                true
            }
            R.id.action_language -> {
                if (!isFinishing) {
                    val dialog = Dialog(this@MainActivity)
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                    dialog.setCancelable(true)
                    dialog.setContentView(R.layout.dialog_change_language)

                    dialog.findViewById<TextView>(R.id.l_english).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "en")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_french).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "fr")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_arabic).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_LTR, "ar")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_urdu).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_LTR, "ur")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_german).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "de")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_turkey).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "tr")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_portougese).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "pt")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_chinese).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "zh")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.findViewById<TextView>(R.id.l_hindi).setOnClickListener {
                        changeLanguage(application, View.LAYOUT_DIRECTION_RTL, "hi")
                        recreate()
                        dialog.dismiss()
                    }
                    dialog.show()
                }
                true
            }
            R.id.action_removeads -> {
                try {
                    if (iUtils.isSubactive) {
                        runOnUiThread {
                            iUtils.ShowToast(this@MainActivity, resources.getString(R.string.youhavealready))
                        }
                    } else {
                        startActivity(Intent(this@MainActivity, SubscriptionActivity::class.java))
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                true
            }
            R.id.action_opengallery -> {
                try {
                    val prefs = getSharedPreferences("whatsapp_pref", MODE_PRIVATE)
                    val lang = prefs.getBoolean("isBio", false)
                    if (lang) {
                        biometricPrompt!!.authenticate(promptInfo!!)
                    } else {
                        startActivity(Intent(this@MainActivity, GalleryActivity::class.java))
                    }
                } catch (e: Throwable) {
                    e.printStackTrace()
                    startActivity(Intent(this@MainActivity, GalleryActivity::class.java))
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun changeLanguage(context: Application?, direction: Int, language: String) {
        LocaleHelper.setLocale(context, language)
        window.decorView.layoutDirection = direction
        val editor: SharedPreferences.Editor = getSharedPreferences("lang_pref", Context.MODE_PRIVATE).edit()
        editor.putString("lang", language)
        editor.apply()
    }

    private fun showBottomSheetExitDialog() {
        try {
            @SuppressLint("InflateParams") val view: View = layoutInflater.inflate(R.layout.dialog_exit, null)
            val lytBottomSheet = view.findViewById<FrameLayout>(R.id.bottom_sheet)

            lytBottomSheet.background = ContextCompat.getDrawable(this, R.drawable.bg_rounded_light)

            val btnRate = view.findViewById<Button>(R.id.btn_rate)
            val btnShare = view.findViewById<Button>(R.id.btn_share)
            val btnExit = view.findViewById<Button>(R.id.btn_exit)
            val frameAd = view.findViewById<FrameLayout>(R.id.fl_adplaceholder)
            nn = SharedPrefsMainApp(this@MainActivity).preferencE_inappads

            frameAd.visibility = View.GONE

            btnRate.setOnClickListener {
                iUtils.rateApp(this)
                mBottomSheetDialog?.dismiss()
            }
            btnShare.setOnClickListener {
                iUtils.shareApp(this)
                mBottomSheetDialog?.dismiss()
            }
            btnExit.setOnClickListener {
                try {
                    mBottomSheetDialog?.dismiss()
                    finishAndRemoveTask()
                    exitProcess(0)
                } catch (e: Throwable) {
                    e.printStackTrace()
                }
            }

            mBottomSheetDialog = BottomSheetDialog(this, R.style.SheetDialogLight)
            mBottomSheetDialog!!.setContentView(view)
            mBottomSheetDialog!!.window?.addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            val bottomSheetBehavior: BottomSheetBehavior<*> = mBottomSheetDialog!!.behavior
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
            bottomSheetBehavior.addBottomSheetCallback(object :
                BottomSheetBehavior.BottomSheetCallback() {
                override fun onStateChanged(bottomSheet: View, newState: Int) {}
                override fun onSlide(bottomSheet: View, slideOffset: Float) {}
            })
            mBottomSheetDialog!!.show()
            mBottomSheetDialog!!.setOnDismissListener {
                mBottomSheetDialog = null
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    @SuppressLint("StaticFieldLeak")
    class LoadAdTask(private val context: Activity, private val frameLayout: FrameLayout) :
        AsyncTask<Void, Void, Unit>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Void?) {
            AdsManager.loadAdmobNativeAdAsync(context, frameLayout)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == APP_UPDATE_REQUEST_CODE) {
            if (resultCode != Activity.RESULT_OK) {
                runOnUiThread {
                    iUtils.ShowToastError(this@MainActivity, resources.getString(R.string.updatefailed))
                }
            }
        }
    }

    private fun initIInAppBillingAcknologement() {
        try {
            billingClient = BillingClientSetup.getInstance(this@MainActivity) { _, list ->
                if (list != null) {
                    for (purchase in list) handlesAlreadyPurchased(purchase)
                }
            }
            billingClient!!.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(billingResult: BillingResult) {
                    try {
                        loadAllSubscribePackage()
                        billingClient!!.queryPurchasesAsync(
                            QueryPurchasesParams.newBuilder()
                                .setProductType(BillingClient.ProductType.SUBS)
                                .build()
                        ) { _: BillingResult, purchases: List<Purchase> ->
                            if (purchases.size > 0) {
                                iUtils.isSubactive = true
                                runOnUiThread {
                                    binding.subscriptionFab.visibility = View.GONE
                                }
                                for (purchase in purchases) handlesAlreadyPurchased(purchase)
                            } else {
                                iUtils.isSubactive = false
                                runOnUiThread {
                                    if (!Constants.show_subscription) {
                                        binding.subscriptionFab.visibility = View.GONE
                                    } else {
                                        if (!BuildConfig.ISPRO) {
                                            binding.subscriptionFab.visibility = View.VISIBLE
                                        } else {
                                            binding.subscriptionFab.visibility = View.GONE
                                        }
                                    }
                                }
                                SharedPrefsMainApp(this@MainActivity).preferencE_inappads = "nnn"
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                override fun onBillingServiceDisconnected() { }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadAllSubscribePackage() {
        try {
            if (billingClient!!.isReady) {
                val productList = listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium1month))
                        .setProductType(BillingClient.ProductType.SUBS).build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium3month))
                        .setProductType(BillingClient.ProductType.SUBS).build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium6months))
                        .setProductType(BillingClient.ProductType.SUBS).build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium12months))
                        .setProductType(BillingClient.ProductType.SUBS).build()
                )

                billingClient!!.queryProductDetailsAsync(
                    QueryProductDetailsParams.newBuilder().setProductList(productList).build()
                ) { _, productDetailsList ->
                    try {
                        iUtils.SkuDetailsList = productDetailsList.productDetailsList
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handlesAlreadyPurchased(purchases: Purchase) {
        if (purchases.purchaseState == Purchase.PurchaseState.PURCHASED) {
            iUtils.isSubactive = true
            runOnUiThread {
                binding.subscriptionFab.visibility = View.GONE
                binding.bannerContainer.visibility = View.GONE
            }
            SharedPrefsMainApp(this@MainActivity).preferencE_inappads = "ppp"
        }
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(base))
    }

    private fun restartApp() {
        try {
            val i = packageManager.getLaunchIntentForPackage(packageName)
            i!!.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        AdsManager.cleanup(this@MainActivity)
    }

    override fun onResume() {
        super.onResume()
        try {
            if (Constants.iSAdminAttached) {
                SplashScreen.getExistingAdminPanelData(this@MainActivity)
            }
            doAllBioMetricTasks()
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}