/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023 . All rights reserved.
 *
 */

package com.infusiblecoder.allinonevideodownloader.webservices;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;
import static android.content.Context.WINDOW_SERVICE;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.franmontiel.persistentcookiejar.ClearableCookieJar;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.infusiblecoder.allinonevideodownloader.R;
import com.infusiblecoder.allinonevideodownloader.activities.GetLinkThroughWebView;
import com.infusiblecoder.allinonevideodownloader.adapters.QualityBottomsheetAdapter;
import com.infusiblecoder.allinonevideodownloader.interfaces.DataCallBackNewJetApi;
import com.infusiblecoder.allinonevideodownloader.models.dlapismodels.DLDataParser;
import com.infusiblecoder.allinonevideodownloader.models.dlapismodels.Format;
import com.infusiblecoder.allinonevideodownloader.models.dlapismodels.Video;
import com.infusiblecoder.allinonevideodownloader.tiktok_methods.FacebookDownloadCloudBypassWebview_method_0_new;
import com.infusiblecoder.allinonevideodownloader.tiktok_methods.FacebookDownloadCloudBypassWebview_method_1;
import com.infusiblecoder.allinonevideodownloader.tiktok_methods.FacebookDownloadCloudBypassWebview_method_3;
import com.infusiblecoder.allinonevideodownloader.utils.Constants;
import com.infusiblecoder.allinonevideodownloader.utils.DownloadFileMain;
import com.infusiblecoder.allinonevideodownloader.utils.GlideApp;
import com.infusiblecoder.allinonevideodownloader.utils.iUtils;
import com.libs.androidnetworking.AndroidNetworking;
import com.libs.androidnetworking.common.Priority;
import com.libs.androidnetworking.error.ANError;
import com.libs.androidnetworking.interfaces.JSONObjectRequestListener;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.mapper.VideoFormat;
import com.yausername.youtubedl_android.mapper.VideoInfo;

import org.apache.commons.text.StringEscapeUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

@SuppressLint("all")
public class DownloadVideosMain {

    private static final int DOWNLOAD_NOTIFICATION_ID = 231;

    public static Activity Mcontext;
    public static ProgressDialog pd;
    public static Dialog dialog;
    public static SharedPreferences prefs;
    public static Boolean fromService;
    public static String VideoUrl;
    static String Title;
    static LinearLayout mainLayout;
    static WindowManager windowManager2;
    static WindowManager.LayoutParams params;
    static View mChatHeadView;
    static ImageView img_dialog;
    static String myURLIS = "";
    static Dialog dialog_quality_allvids;
    static VideoInfo streamInfo;
    static String newddurl = "";


    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    public static void Start(final Activity context, String websiteUrl, Boolean service) {
        try {

            Mcontext = context;
            fromService = service;
            Log.i("LOGClipboard111111 clip", "work 2");

            try {
                websiteUrl = iUtils.extractUrls(websiteUrl).get(0);
            } catch (Exception ignored) {
            }

            myURLIS = websiteUrl;
            if (!fromService) {
                pd = new ProgressDialog(context);
                pd.setMessage(Mcontext.getResources().getString(R.string.genarating_download_link));
                pd.setCancelable(false);
                pd.show();
            }

            // Only Proceed if it's Instagram or Facebook
            if (!(myURLIS.contains("instagram.com") || myURLIS.contains("facebook.com") || myURLIS.contains("fb.watch"))) {
                dismissMyDialogErrorToastForBlockedWebsitePanel();
                return;
            }


            getDataFromNewJetApi(websiteUrl, result -> {
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(() -> {

                    if (!result) {

                        if ((myURLIS.contains("facebook.com") || myURLIS.contains("fb.watch"))) {

                            if (!iUtils.isSocialMediaOn("facebook.com") || !iUtils.isSocialMediaOn("fb.watch")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            if (!((Activity) Mcontext).isFinishing()) {
                                Dialog dialog = new Dialog(Mcontext);
                                dialog.setContentView(R.layout.tiktok_optionselect_dialog);

                                Button methode0 = dialog.findViewById(R.id.dig_btn_met0);
                                Button methode1 = dialog.findViewById(R.id.dig_btn_met1);
                                Button methode2 = dialog.findViewById(R.id.dig_btn_met2);
                                Button methode3 = dialog.findViewById(R.id.dig_btn_met3);
                                Button methode4 = dialog.findViewById(R.id.dig_btn_met4);
                                Button methode5 = dialog.findViewById(R.id.dig_btn_met5);
                                Button methode6 = dialog.findViewById(R.id.dig_btn_met6);

                                methode5.setVisibility(View.VISIBLE);
                                methode6.setVisibility(View.VISIBLE);

                                Button dig_btn_cancel = dialog.findViewById(R.id.dig_btn_cancel);

                                methode0.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    dismissMyDialog();
                                    Intent intent = new Intent(Mcontext, FacebookDownloadCloudBypassWebview_method_0_new.class);
                                    intent.putExtra("myvidurl", myURLIS);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    ((Activity) Mcontext).startActivity(intent);

                                });

                                methode1.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    dismissMyDialog();
                                    Intent intent = new Intent(Mcontext, GetLinkThroughWebView.class);
                                    intent.putExtra("myurlis", myURLIS);
                                    ((Activity) Mcontext).startActivityForResult(intent, 2);

                                });

                                methode2.setOnClickListener(v -> {
                                    dialog.dismiss();

                                    AndroidNetworking.get("https://s4.downloadfacebook.net/ajax/getLinks.php?video=" + myURLIS + "&rand=PNSQNPOPRTTUOLP")
                                            .setPriority(Priority.MEDIUM)
                                            .addHeaders("Content-type", "application/x-www-form-urlencoded")
                                            .addHeaders("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36")
                                            .build()
                                            .getAsJSONObject(new JSONObjectRequestListener() {
                                                @Override
                                                public void onResponse(JSONObject response) {
                                                    String matag;
                                                    try {
                                                        dismissMyDialog();
                                                        JSONObject jsonObject = new JSONObject(response.toString());

                                                        JSONArray jsonaaa = jsonObject.getJSONObject("data").getJSONArray("av");
                                                        matag = jsonaaa.getJSONObject(0).getString("url");

                                                        DownloadFileMain.startDownloading(context, matag, "Facebook_" + System.currentTimeMillis(), ".mp4");

                                                    } catch (Exception e) {
                                                        dismissMyDialogErrortoast();
                                                    }
                                                }

                                                @Override
                                                public void onError(ANError error) {
                                                    dismissMyDialogErrortoast();
                                                }
                                            });

                                });

                                methode3.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    dismissMyDialog();
                                    Intent intent = new Intent(Mcontext, FacebookDownloadCloudBypassWebview_method_1.class);
                                    intent.putExtra("myvidurl", myURLIS);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    Mcontext.startActivity(intent);
                                });
                                methode4.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    dismissMyDialog();
                                    Intent intent = new Intent(Mcontext, FacebookDownloadCloudBypassWebview_method_3.class);
                                    intent.putExtra("myvidurl", myURLIS);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                                    Mcontext.startActivity(intent);
                                });

                                methode5.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    callDlApiNew(myURLIS);
                                });


                                methode6.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    try {
                                        Executors.newSingleThreadExecutor().submit(() -> {
                                            try {
                                                Looper.prepare();

                                                ClearableCookieJar cookieJar =
                                                        new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(Mcontext));

                                                HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
                                                logging.setLevel(HttpLoggingInterceptor.Level.BODY);

                                                OkHttpClient client = new OkHttpClient.Builder()
                                                        .cookieJar(cookieJar)
                                                        .addInterceptor(logging)
                                                        .connectTimeout(10, TimeUnit.SECONDS)
                                                        .writeTimeout(10, TimeUnit.SECONDS)
                                                        .readTimeout(30, TimeUnit.SECONDS)
                                                        .build();

                                                RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                                                        .addFormDataPart("q", myURLIS)
                                                        .addFormDataPart("p", "home")
                                                        .addFormDataPart("lang", "en")
                                                        .addFormDataPart("w", "")
                                                        .build();
                                                Request request = new Request.Builder()
                                                        .url("https://x2download.com/api/ajaxSearch")
                                                        .header("Cookie", "")
                                                        .method("POST", body)
                                                        .build();
                                                Response response = client.newCall(request).execute();

                                                String ressff = Objects.requireNonNull(response.body()).string();
                                                JSONObject document = new JSONObject(ressff);
                                                dismissMyDialog();

                                                if (document.has("data") && !document.getString("data").equals("")) {
                                                    String nametitle = "Facebook_" + System.currentTimeMillis();
                                                    String inputString = document.getString("data");
                                                    try {
                                                        String decodedHtml = StringEscapeUtils.unescapeHtml4(inputString);
                                                        List<String> allurls = iUtils.extractUrlsWithVideo(decodedHtml);
                                                        DownloadFileMain.startDownloading(Mcontext, allurls.get(0), nametitle, ".mp4");
                                                    } catch (Exception e) {
                                                        dismissMyDialogErrortoast();
                                                        e.printStackTrace();
                                                    }
                                                } else {
                                                    dismissMyDialogErrortoast();
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                                dismissMyDialogErrortoast();
                                            }
                                        });

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        dismissMyDialogErrortoast();
                                    }

                                });

                                dig_btn_cancel.setOnClickListener(v -> {
                                    dialog.dismiss();
                                    dismissMyDialog();
                                });

                                dialog.setCancelable(false);
                                dialog.show();
                            }

                        } else if (myURLIS.contains("instagram.com")) {
                            if (!iUtils.isSocialMediaOn("instagram.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            callDlApiNew(myURLIS);

                        } else {
                            dismissMyDialogErrorToastForBlockedWebsitePanel();
                        }
                        prefs = Mcontext.getSharedPreferences("AppConfig", MODE_PRIVATE);
                    } else {
                        dismissMyDialog();
                    }

                });
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void getDataFromNewJetApi(String videoUrl, DataCallBackNewJetApi callBackNewJetApi) {

        if (!NewJetApi.isAllowedDomain(videoUrl)) {
            Log.d("isAllowedDomain: ", "unsupported domain " + videoUrl);
            callBackNewJetApi.onResult(false);
            return;
        }

        NewJetApi.sendNewJetApiDataRequest(Mcontext, videoUrl, encryptedData -> {
            try {
                if (encryptedData != null) {
                    JSONObject jsonObject = new JSONObject(encryptedData);

                    if (jsonObject.has("error") && jsonObject.getBoolean("error")) {
                        String errorMessage = jsonObject.getString("message");
                        throw new IllegalArgumentException(errorMessage);
                    }

                    JSONArray mymedias = jsonObject.getJSONArray("medias");
                    String source = jsonObject.getString("source");
                    String nametitle = source + "_" + jsonObject.getString("author") + "_" +
                            System.currentTimeMillis();

                    Handler mainHandler = new Handler(Looper.getMainLooper());
                    Runnable runnable = () -> {
                        boolean isTikTokVideoDownloaded = false;

                        try {
                            for (int i = 0; i < mymedias.length(); i++) {
                                var mediaItem = mymedias.getJSONObject(i);
                                var mediaType = mediaItem.getString("type");
                                var mediaUrl = mediaItem.getString("url");

                                if (source.contains("tiktok") && mediaType.equals("video")) {
                                    if (isTikTokVideoDownloaded) {
                                        continue;
                                    }
                                    isTikTokVideoDownloaded = true;
                                }

                                switch (mediaType) {
                                    case "video":
                                        DownloadFileMain.startDownloading(Mcontext, mediaUrl, nametitle, ".mp4");
                                        break;
                                    case "image":
                                        DownloadFileMain.startDownloading(Mcontext, mediaUrl, nametitle, ".jpg");
                                        break;
                                }
                            }
                            callBackNewJetApi.onResult(true);
                        } catch (Exception e) {
                            e.printStackTrace();
                            callBackNewJetApi.onResult(false);
                        }
                    };
                    mainHandler.post(runnable);
                } else {
                    Handler mainHandler = new Handler(Looper.getMainLooper());
                    mainHandler.post(() -> {
                        callBackNewJetApi.onResult(false);
                    });
                }
            } catch (Exception e) {
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(() -> {
                    callBackNewJetApi.onResult(false);
                    e.printStackTrace();
                });
            }
        });
    }

    private static void showdownload_progress(int timeelipsed, long filesize) {
        Thread thread = new Thread() {
            @Override
            public void run() {

                String filesize2 = iUtils.getStringSizeLengthFile(filesize);
                NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(Mcontext);
                String contentTitle = "Downloaded";
                Intent notifyIntent = new Intent();
                PendingIntent notifyPendingIntent = PendingIntent.getActivity(Mcontext, DOWNLOAD_NOTIFICATION_ID, notifyIntent, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationCompat.Builder notificationBuilder = createNotificationBuilder("downloader_channel");
                notificationBuilder.setContentIntent(notifyPendingIntent);
                notificationBuilder.setTicker("Start downloading from the server");
                notificationBuilder.setOngoing(true);
                notificationBuilder.setAutoCancel(false);
                notificationBuilder.setSmallIcon(android.R.drawable.stat_sys_download);
                notificationBuilder.setContentTitle(contentTitle);
                notificationManagerCompat.notify(DOWNLOAD_NOTIFICATION_ID, notificationBuilder.build());

                notificationBuilder.setContentText("time elipsed: " + iUtils.formatDuration(timeelipsed) + " downloaded : " + filesize2);
                notificationBuilder.setProgress(100, timeelipsed, false);
                notificationManagerCompat.notify(DOWNLOAD_NOTIFICATION_ID, notificationBuilder.build());

                notificationBuilder.setContentTitle(contentTitle);
                notificationBuilder.setSmallIcon(android.R.drawable.stat_sys_download_done);
                notificationBuilder.setOngoing(false);
                notificationBuilder.setAutoCancel(true);
                notificationManagerCompat.notify(DOWNLOAD_NOTIFICATION_ID, notificationBuilder.build());
            }
        };

        thread.start();
    }

    private static NotificationCompat.Builder createNotificationBuilder(String channelId) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String channelName = Mcontext.getString(R.string.app_name);
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setLightColor(Color.BLUE);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager notificationManager = (NotificationManager) Mcontext.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        return new NotificationCompat.Builder(Mcontext, channelId);
    }

    public static void dismissMyDialog() {

        if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
        }
    }

    public static void dismissMyDialogErrortoast() {

        if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
            Mcontext.runOnUiThread(() -> {
                iUtils.ShowToastError(Mcontext,
                        Mcontext.getResources().getString(R.string.somthing)
                );
            });
        }
    }

    public static void dismissMyDialogErrorToastForBlockedWebsitePanel() {
        if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
            Mcontext.runOnUiThread(() -> {
                iUtils.ShowToastError(Mcontext,
                        "Only Instagram and Facebook are supported."
                );
            });
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private static void addButtonToMainLayouttest_allvideo(final String videoTitle, String ytfile, String video_title) {
        try {
            Button btn = new Button(Mcontext);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(8, 8, 8, 8);
            btn.setLayoutParams(params);
            btn.setBackground(Mcontext.getResources().getDrawable(R.drawable.btn_bg_download_screen));
            btn.setTextColor(Color.WHITE);
            btn.setText(videoTitle);
            btn.setOnClickListener(v -> {

                if (windowManager2 != null) {
                    try {
                        windowManager2.removeView(mChatHeadView);
                    } catch (Exception e) {
                    }
                }

                if (videoTitle.equals("audio/mp4")) {
                    DownloadFileMain.startDownloading(Mcontext, ytfile, video_title + "_" + videoTitle, ".mp3");
                } else {
                    DownloadFileMain.startDownloading(Mcontext, ytfile, video_title + "_" + videoTitle, ".mp4");

                }
                dialog_quality_allvids.dismiss();
            });
            mainLayout.addView(btn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static void splitDataToVideoAndAudio_video(List<Video> videoList, RecyclerView recyclerView_video, RecyclerView recyclerView_audio, QualityBottomsheetAdapter qualityBottomsheetAdapter, String extractor) {

        List<Video> videoList_sub = new ArrayList<>();
        List<Video> videoList_sub_video = new ArrayList<>();
        for (int i = 0; i < videoList.size(); i++) {

            if (videoList.get(i).getProtocol().contains("http") && !videoList.get(i).getProtocol().contains("http_dash_segments") && !videoList.get(i).getURL().contains(".m3u8") && !videoList.get(i).getProtocol().contains("m3u8_native")) {

                if (videoList.get(i).getEXT().equals("m4a") ||
                        videoList.get(i).getEXT().equals("mp3") ||
                        videoList.get(i).getEXT().equals("wav")) {
                    videoList_sub.add(videoList.get(i));
                } else if (videoList.get(i).getEXT().equals("mp4") || videoList.get(i).getEXT().equals("mpeg")) {

                    videoList_sub_video.add(videoList.get(i));

                }
            }
        }

        Collections.reverse(videoList_sub_video);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, videoList_sub_video.get(0).getExtractor(), false, videoList_sub_video, true);
        recyclerView_video.setAdapter(qualityBottomsheetAdapter);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, videoList_sub.get(0).getExtractor(), false, videoList_sub, true);
        recyclerView_audio.setAdapter(qualityBottomsheetAdapter);

    }

    private static void splitDataToVideoAndAudio_format(List<Format> formatList, RecyclerView recyclerView_video, RecyclerView recyclerView_audio, QualityBottomsheetAdapter qualityBottomsheetAdapter, String extractor) {

        List<Format> formatList_sub = new ArrayList<>();
        List<Format> formatList_sub_video = new ArrayList<>();
        for (int i = 0; i < formatList.size(); i++) {

            if (formatList.get(i).getProtocol().contains("http") && !formatList.get(i).getProtocol().contains("http_dash_segments") && !formatList.get(i).getURL().contains(".m3u8") && !formatList.get(i).getProtocol().contains("m3u8_native")) {

                if (formatList.get(i).getAcodec() != null && !formatList.get(i).getAcodec().equals("none")) {

                    if (formatList.get(i).getEXT().equals("m4a") ||
                            formatList.get(i).getEXT().equals("mp3") ||
                            formatList.get(i).getEXT().equals("wav")) {
                        formatList_sub.add(formatList.get(i));
                    } else if (formatList.get(i).getEXT().equals("mp4") || formatList.get(i).getEXT().equals("unknown_video") || formatList.get(i).getEXT().equals("mpeg")) {

                        formatList_sub_video.add(formatList.get(i));

                    }
                } else {

                    if (formatList.get(i).getEXT().equals("m4a") ||
                            formatList.get(i).getEXT().equals("mp3") ||
                            formatList.get(i).getEXT().equals("wav")) {
                        formatList_sub.add(formatList.get(i));
                    } else if (formatList.get(i).getEXT().equals("mp4") || formatList.get(i).getEXT().equals("unknown_video") || formatList.get(i).getEXT().equals("mpeg")) {
                        formatList_sub_video.add(formatList.get(i));

                    }
                    formatList.get(i).setFormat("" + formatList.get(i).getFormat());

                }

            }
        }

        Collections.reverse(formatList_sub_video);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, formatList_sub_video, extractor, false);
        recyclerView_video.setAdapter(qualityBottomsheetAdapter);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, formatList_sub, extractor, false);
        recyclerView_audio.setAdapter(qualityBottomsheetAdapter);

    }

    @Keep
    public static void CalldlApisDataData(String url, boolean hasQualityOption) {
        callDlApiNew(url);
    }

    static void callM3u8Backup(String url) {
        AndroidNetworking.get("https://api.m3u8-downloader.com/api/parse?url=" + url)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject obj = new JSONObject();
                            JSONArray jsonArray = new JSONArray();
                            jsonArray.put(0, response);
                            obj.put("url", "" + url);
                            obj.put("videos", jsonArray);
                            parseCalldlApisDataData(obj, url, true);
                        } catch (Exception e) {
                            dismissMyDialogErrortoast();
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onError(ANError error) {
                        dismissMyDialogErrortoast();
                    }
                });
    }

    static void callBackup(String url) {
        AndroidNetworking.get("http://199.192.20.82:9191/api/info?url=" + url + "&flatten=True")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        parseCalldlApisDataData(response, url, true);
                    }

                    @Override
                    public void onError(ANError error) {
                        dismissMyDialogErrortoast();
                    }
                });
    }

    static void callDlApiNew(String url) {
        Executors.newSingleThreadExecutor().submit(() -> {
            try {
                streamInfo = YoutubeDL.getInstance().getInfo(url);
                Mcontext.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        parseCalldlApisLocalDataData(streamInfo, url);
                    }
                });

            } catch (Throwable e) {
                callBackup(url);
            }
        });

    }


    @Keep
    public static void parseCalldlApisLocalDataData(VideoInfo response, String url) {
        try {
            dismissMyDialog();

            View view = LayoutInflater.from(Mcontext).inflate(R.layout.bottomsheet_quality_layout, null);
            String[] dataSize;
            Button btncancel_bottomsheet = view.findViewById(R.id.btncancel_bottomsheet);
            Button btnopen_bottomsheet = view.findViewById(R.id.btnopen_bottomsheet);
            TextView source_bottomsheet = view.findViewById(R.id.source_bottomsheet);
            TextView title_bottomsheet = view.findViewById(R.id.bottomsheet_title);
            TextView duration_bottomsheet = view.findViewById(R.id.bottomsheet_duration);
            ImageView thumb_bottomsheet = view.findViewById(R.id.bottomsheet_thumbnail);
            TextView bottomsheet_description = view.findViewById(R.id.bottomsheet_description);

            // TabLayout and ViewPager
            TabLayout tabLayout = view.findViewById(R.id.tab_layout);
            ViewPager viewPager = view.findViewById(R.id.view_pager);

            tabLayout.setTabTextColors(ContextCompat.getColor(Mcontext, R.color.tab_unselected_text_color),
                    ContextCompat.getColor(Mcontext, R.color.tab_selected_text_color));

            QualityPagerAdapter pagerAdapter = new QualityPagerAdapter(
                    Mcontext,
                    response.getExtractor(),
                    response.getTitle(),
                    response.getId(),
                    url
            );

            viewPager.setAdapter(pagerAdapter);

            // Link TabLayout with ViewPager
            tabLayout.setupWithViewPager(viewPager);

            // Set tab titles
            tabLayout.getTabAt(0).setText("Video");
            tabLayout.getTabAt(1).setText("Audio");

            // Populate data into the adapter
            if (response.getFormats().size() > 0) {
                dataSize = splitDataToVideoAndAudio_dlapiformat(response.getFormats(), pagerAdapter, response.getExtractor(), response.getTitle(), response.getId(), url);
            }

            BottomSheetDialog dialog = new BottomSheetDialog(Mcontext);

            if (!TextUtils.isEmpty(response.getDescription())) {
                String descriptiontext = "Description: " + String.format("%s", response.getDescription());
                bottomsheet_description.setText(Html.fromHtml(descriptiontext), TextView.BufferType.SPANNABLE);
            }
            if (!TextUtils.isEmpty(response.getExtractor())) {
                String styledText = "";
                switch (response.getExtractor()) {
                    case "youtube":
                        styledText = "Source: <font color='red'>YTD</font>";
                        break;
                    case "soundcloud":
                        styledText = "Source: <font color='red'>SCloud</font>";
                        break;
                    case "facebook":
                        styledText = "Source: <font color='red'>SocialF</font>";
                        break;
                    default:
                        styledText = "Source: <font color='red'>" + response.getExtractor() + "</font>";
                        break;
                }
                source_bottomsheet.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);
            }

            if (response.getDuration() > 0) {
                String mystring = response.getDuration() + "";
                String[] correctstring = mystring.split("\\.");
                long hours = Long.parseLong(correctstring[0]) / 3600;
                long minutes = (Long.parseLong(correctstring[0]) % 3600) / 60;
                long seconds = Long.parseLong(correctstring[0]) % 60;
                String durationStyledText = "Duration: <font color='red'>" + String.format("%02d:%02d:%02d", hours, minutes, seconds) + "</font>";
                duration_bottomsheet.setText(Html.fromHtml(durationStyledText), TextView.BufferType.SPANNABLE);
            }

            if (!TextUtils.isEmpty(response.getTitle())) {
                String titleStyledText = "Title: <font color='red'>" + String.format("%s", response.getTitle()) + "</font>";
                title_bottomsheet.setText(Html.fromHtml(titleStyledText), TextView.BufferType.SPANNABLE);
            }

            if (!TextUtils.isEmpty(response.getThumbnail())) {
                GlideApp.with(Mcontext)
                        .load(response.getThumbnail())
                        .placeholder(R.drawable.ic_appicon_pro)
                        .into(thumb_bottomsheet);
            }

            btncancel_bottomsheet.setOnClickListener(v -> dialog.cancel());

            btnopen_bottomsheet.setOnClickListener(v -> {
                if (dialog.getBehavior().getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    dialog.getBehavior().setState(BottomSheetBehavior.STATE_COLLAPSED);
                    dialog.getBehavior().setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);
                    btnopen_bottomsheet.animate().rotationBy(180f).start();
                } else {
                    dialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
                    dialog.getBehavior().setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);
                    btnopen_bottomsheet.animate().rotationBy(180f).start();
                }
            });

            dialog.setContentView(view);
            dialog.show();

            dismissMyDialog();

        } catch (Exception str2) {
            dismissMyDialogErrortoast();
        }
    }

    private static String[] splitDataToVideoAndAudio_dlapiformat(ArrayList<VideoFormat> videoList, QualityPagerAdapter pagerAdapter, String extractor, String title, String id, String url) {
        List<VideoFormat> videoList_sub = new ArrayList<>(); // Audio formats
        List<VideoFormat> videoList_sub_video = new ArrayList<>(); // Video formats

        for (int i = 0; i < videoList.size(); i++) {
            String myext = videoList.get(i).getExt();
            if (myext.equals("m4a") || myext.equals("mp3") || myext.equals("wav") ||
                    (myext.equals("webm") && !videoList.get(i).getAcodec().equals("none"))) {
                videoList_sub.add(videoList.get(i));
            } else if (myext.equals("mp4") || myext.equals("mpeg") ||
                    (myext.equals("webm") && videoList.get(i).getAcodec().equals("none"))) {
                videoList_sub_video.add(videoList.get(i));
            }
        }

        Collections.reverse(videoList_sub_video);

        // Set data in the adapter
        pagerAdapter.setVideoData(videoList_sub_video);
        pagerAdapter.setAudioData(videoList_sub);

        String[] dataSize = {"n", "n"};
        if (videoList_sub_video.size() > 0) {
            dataSize[0] = "y";
        }
        if (videoList_sub.size() > 0) {
            dataSize[1] = "y";
        }
        return dataSize;
    }

    @Keep
    public static void parseCalldlApisDataData(JSONObject response, String url, boolean isFromBackup) {
        try {
            try {
                if (!response.getString("error").equals("")) {
                    if (isFromBackup) {
                        dismissMyDialogErrortoast();
                    } else {
                        callBackup(url);
                    }
                }

            } catch (Exception e) {

                Gson gson = new Gson();

                DLDataParser gsonObj = gson.fromJson(response.toString(), DLDataParser.class);
                View view = LayoutInflater.from(Mcontext).inflate(R.layout.bottomsheet_quality_layout, null);

                Button btncancel_bottomsheet = view.findViewById(R.id.btncancel_bottomsheet);
                Button btnopen_bottomsheet = view.findViewById(R.id.btnopen_bottomsheet);
                TextView source_bottomsheet = view.findViewById(R.id.source_bottomsheet);
                TextView title_bottomsheet = view.findViewById(R.id.bottomsheet_title);
                TextView duration_bottomsheet = view.findViewById(R.id.bottomsheet_duration);
                ImageView thumb_bottomsheet = view.findViewById(R.id.bottomsheet_thumbnail);

                RecyclerView recyclerView = view.findViewById(R.id.recqualitybottomsheet);

                recyclerView.setLayoutManager(new LinearLayoutManager(Mcontext));

                RecyclerView recyclerView_audio = view.findViewById(R.id.recqualitybottomsheet_aud);
                recyclerView_audio.setHasFixedSize(true);
                recyclerView_audio.setLayoutManager(new LinearLayoutManager(Mcontext));

                QualityBottomsheetAdapter qualityBottomsheetAdapter = null;

                if (response.getJSONArray("videos").length() > 1) {

                    if (response.getJSONArray("videos").getJSONObject(0).has("protocol")) {
                        splitDataToVideoAndAudio_video(gsonObj.getVideos(), recyclerView, recyclerView_audio, qualityBottomsheetAdapter, gsonObj.getVideos().get(0).getExtractor());
                    }

                    BottomSheetDialog dialog = new BottomSheetDialog(Mcontext);

                    if (response.getJSONArray("videos").getJSONObject(0).has("extractor")) {
                        String styledText = "";

                        switch (gsonObj.getVideos().get(0).getExtractor()) {
                            case "youtube": {
                                styledText = "Source: <font color='red'>" + "YTD" + "</font>";

                                break;
                            }
                            case "soundcloud": {
                                styledText = "Source: <font color='red'>" + "SCloud" + "</font>";

                                break;
                            }
                            case "facebook": {
                                styledText = "Source: <font color='red'>" + "SocialF" + "</font>";

                                break;
                            }

                            default: {
                                styledText = "Source: <font color='red'>" + gsonObj.getVideos().get(0).getExtractor() + "</font>";

                                break;
                            }

                        }
                        source_bottomsheet.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);
                    }

                    if (response.getJSONArray("videos").getJSONObject(0).has("duration")) {

                        String mystring = gsonObj.getVideos().get(0).getDuration() + "";
                        String[] correctstring = mystring.split("\\.");

                        long hours = Long.parseLong(correctstring[0]) / 3600;
                        long minutes = (Long.parseLong(correctstring[0]) % 3600) / 60;
                        long seconds = Long.parseLong(correctstring[0]) % 60;

                        String DurationstyledText = "Duration: <font color='red'>" + String.format("%02d:%02d:%02d", hours, minutes, seconds) + "</font>";
                        duration_bottomsheet.setText(Html.fromHtml(DurationstyledText), TextView.BufferType.SPANNABLE);
                    }

                    if (response.getJSONArray("videos").getJSONObject(0).has("title")) {
                        String titletyledText = "Title: <font color='red'>" + String.format("%s", gsonObj.getVideos().get(0).getTitle()) + "</font>";
                        title_bottomsheet.setText(Html.fromHtml(titletyledText), TextView.BufferType.SPANNABLE);
                    }

                    if (response.getJSONArray("videos").getJSONObject(0).has("thumbnail")) {

                        GlideApp.with(Mcontext)
                                .load(gsonObj.getVideos().get(0).getThumbnail())
                                .placeholder(R.drawable.ic_appicon_pro).into(thumb_bottomsheet);

                    }
                    btncancel_bottomsheet.setOnClickListener(v -> dialog.cancel());

                    btnopen_bottomsheet.setOnClickListener(v -> {
                        dialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
                        dialog.getBehavior().setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);
                    });

                    dialog.setContentView(view);
                    dialog.show();

                    dismissMyDialog();

                } else {

                    if (response.getJSONArray("videos").getJSONObject(0).has("formats")) {

                        splitDataToVideoAndAudio_format(gsonObj.getVideos().get(0).getFormats(), recyclerView, recyclerView_audio, qualityBottomsheetAdapter, gsonObj.getVideos().get(0).getExtractor());

                    } else {
                        if (response.getJSONArray("videos").getJSONObject(0).has("protocol")) {

                            String ishttp = response.getJSONArray("videos").getJSONObject(0).getString("protocol");
                            if (ishttp.contains("http")) {
                                qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, gsonObj.getVideos().get(0).getURL(), gsonObj.getVideos().get(0).getExtractor(), true);
                                recyclerView.setAdapter(qualityBottomsheetAdapter);
                            }
                        }
                    }

                    if (!((Activity) Mcontext).isFinishing()) {

                        BottomSheetDialog dialog = new BottomSheetDialog(Mcontext);

                        if (response.getJSONArray("videos").getJSONObject(0).has("extractor")) {
                            String styledText = "";

                            switch (gsonObj.getVideos().get(0).getExtractor()) {
                                case "youtube": {
                                    styledText = "Source: <font color='red'>" + "YTD" + "</font>";
                                    break;
                                }
                                case "soundcloud": {
                                    styledText = "Source: <font color='red'>" + "SCloud" + "</font>";
                                    break;
                                }
                                case "facebook": {
                                    styledText = "Source: <font color='red'>" + "SocialF" + "</font>";
                                    break;
                                }

                                default: {
                                    styledText = "Source: <font color='red'>" + gsonObj.getVideos().get(0).getExtractor() + "</font>";
                                    break;
                                }

                            }
                            source_bottomsheet.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);
                        }

                        if (response.getJSONArray("videos").getJSONObject(0).has("duration")) {
                            String mystring = gsonObj.getVideos().get(0).getDuration() + "";
                            String[] correctstring = mystring.split("\\.");

                            long hours = Long.parseLong(correctstring[0]) / 3600;
                            long minutes = (Long.parseLong(correctstring[0]) % 3600) / 60;
                            long seconds = Long.parseLong(correctstring[0]) % 60;

                            String DurationstyledText = "Duration: <font color='red'>" + String.format("%02d:%02d:%02d", hours, minutes, seconds) + "</font>";
                            duration_bottomsheet.setText(Html.fromHtml(DurationstyledText), TextView.BufferType.SPANNABLE);
                        }

                        if (response.getJSONArray("videos").getJSONObject(0).has("title")) {
                            String titletyledText = "Title: <font color='red'>" + String.format("%s", gsonObj.getVideos().get(0).getTitle()) + "</font>";
                            title_bottomsheet.setText(Html.fromHtml(titletyledText), TextView.BufferType.SPANNABLE);
                        }

                        if (response.getJSONArray("videos").getJSONObject(0).has("thumbnail")) {
                            GlideApp.with(Mcontext)
                                    .load(gsonObj.getVideos().get(0).getThumbnail())
                                    .placeholder(R.drawable.ic_appicon_pro).into(thumb_bottomsheet);
                        }
                        btncancel_bottomsheet.setOnClickListener(v -> dialog.cancel());

                        dialog.setContentView(view);
                        dialog.show();
                    }
                    dismissMyDialog();
                }
            }
        } catch (Exception str2) {
            dismissMyDialogErrortoast();
        }

    }

    static class QualityPagerAdapter extends PagerAdapter {
        private List<VideoFormat> videoData = new ArrayList<>();
        private List<VideoFormat> audioData = new ArrayList<>();

        private Context context;
        private String extractor;
        private String title;
        private String id;
        private String url;

        public QualityPagerAdapter(Context context, String extractor, String title, String id, String url) {
            this.context = context;
            this.extractor = extractor;
            this.title = title;
            this.id = id;
            this.url = url;
        }

        public void setVideoData(List<VideoFormat> videoData) {
            this.videoData = videoData;
        }

        public void setAudioData(List<VideoFormat> audioData) {
            this.audioData = audioData;
        }

        @Override
        public int getCount() {
            return 2;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view;
            if (position == 0) { // Video tab
                view = inflater.inflate(R.layout.video_quality_layout, container, false);
                RecyclerView recyclerView = view.findViewById(R.id.recqualitybottomsheet);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                QualityBottomsheetAdapter adapter = new QualityBottomsheetAdapter(
                        (Activity) context, extractor, false, videoData, true, title, id, url, false);
                recyclerView.setAdapter(adapter);
            } else { // Audio tab
                view = inflater.inflate(R.layout.audio_quality_layout, container, false);
                RecyclerView recyclerView = view.findViewById(R.id.recqualitybottomsheet_aud);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                QualityBottomsheetAdapter adapter = new QualityBottomsheetAdapter(
                        (Activity) context, extractor, false, audioData, true, title, id, url, true);
                recyclerView.setAdapter(adapter);
            }
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }
    }
}