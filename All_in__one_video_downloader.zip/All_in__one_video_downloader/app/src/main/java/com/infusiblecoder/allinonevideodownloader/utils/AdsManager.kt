/*
 * *
 * * Created by Syed Usama Ahmad on 3/4/23, 8:29 PM
 * * Copyright (c) 2023 . All rights reserved.
 * * Last modified 3/4/23, 8:04 PM
 *
 */
@file:OptIn(DelicateCoroutinesApi::class)

package com.infusiblecoder.allinonevideodownloader.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import com.infusiblecoder.allinonevideodownloader.BuildConfig
import com.infusiblecoder.allinonevideodownloader.R
import com.infusiblecoder.allinonevideodownloader.adapters.AdapterBannerAdsSliderRecyclerView
import com.infusiblecoder.allinonevideodownloader.utils.iUtils.isNetworkAvailable
import com.libs.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType
import com.libs.smarteist.autoimageslider.SliderAnimations
import com.libs.smarteist.autoimageslider.SliderView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Objects
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException


object AdsManager {
    //TODO change this if you want to limit interstishal ads
    @JvmField
    var NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION: Int = 150

    //TODO dont touch this
    var NUMBER_OF_INTERSTISHAL_ADS_SHOWN: Int = 0


    //TODO change this if you want to limit banner ads
    private var NUMBER_OF_BANNER_ADS_PER_SESSION: Int = 150

    //TODO dont touch this
    private var NUMBER_OF_BANNER_ADS_SHOWN: Int = 0


    //ALL Ads Ids
    @JvmField
    var videoapp_AdmobAppId: String? = null

    @JvmField
    var videoapp_AdmobBanner: String? = null

    @JvmField
    var videoapp_AdmobInterstitial: String? = null
    private var videoapp_AdmobRewardedInterstitial: String? = null

    @JvmField
    var videoapp_AdmobRewardVideoExtraFeatures: String? = null

    @JvmField
    var videoapp_AdmobRewardID: String? = null

    @JvmField
    var videoapp_AdmobNativeID: String? = null


    @JvmField
    var status_AdmobBanner: Boolean = true

    @JvmField
    var status_AdmobInterstitial: Boolean = true

    @JvmField
    var status_AdmobRewardID: Boolean = true

    @JvmField
    var status_AdmobNativeID: Boolean = true


    private var mInterstitialAd: InterstitialAd? = null
    var mRewardedAd: RewardedAd? = null
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null

    @JvmField
    var adView: AdView? = null

    // Minimum time between ad requests (in milliseconds)
    private const val MIN_TIME_BETWEEN_ADS = 30000L // 30 seconds
    private var lastAdRequestTime = 0L

    // Network status
    private var isNetworkAvailable = AtomicBoolean(false)
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    // Global variable for retry count and max retries
    var retryCount = 0
    val maxRetries = 2 // Maximum retries limit set to 2
    private const val RETRY_DELAY_MS = 5000L // 5 seconds delay for retries


    // Flag to ensure only one ad load operation is active at a time
    private var isInterstitialAdLoading = AtomicBoolean(false)
    private var isRewardedAdLoading = AtomicBoolean(false)
    private var isNativeAdLoading = AtomicBoolean(false)
    private var isRewardedInterstitialAdLoading = AtomicBoolean(false)


    // Initialize network monitoring
    @JvmStatic
    fun initNetworkMonitoring(context: Context) {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                isNetworkAvailable.set(true)
                Log.d("AdsManager", "Network is available.")
                // Optionally, trigger a preload of ads when network becomes available
                // For example:
                // GlobalScope.launch(Dispatchers.Main) { loadInterstitialAd(context as Activity) }
            }

            override fun onLost(network: Network) {
                isNetworkAvailable.set(false)
                Log.d("AdsManager", "Network is lost.")
            }
        }

        val networkRequest = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        connectivityManager.registerNetworkCallback(networkRequest, networkCallback!!)

        // Initial network check
        isNetworkAvailable.set(checkNetworkAvailability(context))
    }

    private fun checkNetworkAvailability(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = connectivityManager.getNetworkCapabilities(network)
        return capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    private fun canShowAd(): Boolean {
        val currentTime = System.currentTimeMillis()
        return isNetworkAvailable.get() && (currentTime - lastAdRequestTime >= MIN_TIME_BETWEEN_ADS)
    }


    @JvmStatic
    fun setDefaults(activity: Application) {
        if (videoapp_AdmobInterstitial == null || videoapp_AdmobInterstitial == "") {
            videoapp_AdmobNativeID = activity.resources.getString(R.string.AdmobNativeID)
            videoapp_AdmobRewardID = activity.resources.getString(R.string.AdmobRewardID)
            videoapp_AdmobRewardVideoExtraFeatures =
                activity.resources.getString(R.string.AdmobRewardID)
            videoapp_AdmobInterstitial = activity.resources.getString(R.string.AdmobInterstitial)
            videoapp_AdmobRewardedInterstitial =
                activity.resources.getString(R.string.AdmobRewardedInterstitial)
            videoapp_AdmobBanner = activity.resources.getString(R.string.AdmobBanner)
            videoapp_AdmobAppId = activity.resources.getString(R.string.AdmobAppId)
        }
    }


    // Define a suspend function to perform the background work
    private suspend fun loadBannerAdsAdapter(context: Activity?, sliderView: SliderView) {
        withContext(Dispatchers.IO) {
            try {
                if (status_AdmobBanner && isNetworkAvailable.get()) {
                    try {
                        val adapterBannerAdsRecyclerView =
                            AdapterBannerAdsSliderRecyclerView(context!!)
                        withContext(Dispatchers.Main) {
                            sliderView.setSliderAdapter(adapterBannerAdsRecyclerView)
                            sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM)
                            sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION)
                            sliderView.startAutoCycle()
                            sliderView.visibility = View.VISIBLE // Make sure it's visible if loaded
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            sliderView.visibility = View.GONE
                            destroyAdview()
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        destroyAdview()
                        sliderView.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    destroyAdview()
                    sliderView.visibility = View.GONE
                    e.printStackTrace()
                }
            }
        }
    }

    // Launch coroutine from an Activity or other CoroutineScope
    fun loadBannerAdAdapter(activity: Activity?, sliderView: SliderView) {
        // Ensure to use a valid CoroutineScope
        CoroutineScope(Dispatchers.Main).launch {
            loadBannerAdsAdapter(activity, sliderView)
        }
    }

    @JvmStatic
    fun destroyAdview() {
        try {
            if (adView != null) adView!!.destroy()
        } catch (e: Exception) {
            Log.d("error", "Error destroying AdView: " + e.localizedMessage)
        }
    }


    fun showAdmobRewardedInterstitialAd(
        context: Activity?,
        contentCallback: FullScreenContentCallback?,
        userEarnedRewardListener: OnUserEarnedRewardListener?,
        onAdShowed: (() -> Unit)? = null
    ) {
        try {
            if (status_AdmobInterstitial && isNetworkAvailable.get()) {
                if (rewardedInterstitialAd != null) {
                    rewardedInterstitialAd!!.show(context!!, userEarnedRewardListener!!)
                    rewardedInterstitialAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent()
                            contentCallback?.onAdDismissedFullScreenContent()
                            // Preload next ad after dismissal
                            GlobalScope.launch(Dispatchers.Main) {
                                loadRewardedInterstitialAd(context)
                            }
                        }

                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            super.onAdFailedToShowFullScreenContent(p0)
                            contentCallback?.onAdFailedToShowFullScreenContent(p0)
                            Log.e("AdsManager", "Failed to show rewarded interstitial ad: ${p0.message}")
                            // Attempt to reload if show fails
                            GlobalScope.launch(Dispatchers.Main) {
                                loadRewardedInterstitialAd(context)
                            }
                        }

                        override fun onAdShowedFullScreenContent() {
                            super.onAdShowedFullScreenContent()
                            contentCallback?.onAdShowedFullScreenContent()
                            onAdShowed?.invoke()
                        }
                    }
                    rewardedInterstitialAd = null // Invalidate after showing
                } else {
                    Log.d("AdsManager", "The rewarded interstitial ad wasn't ready yet. Attempting to load.")
                    // Attempt to load if not ready
                    GlobalScope.launch(Dispatchers.Main) {
                        loadRewardedInterstitialAd(context!!)
                    }
                }
            } else {
                Log.d("AdsManager", "Rewarded interstitial ad not shown: Network not available or ad status disabled.")
            }
        } catch (ignored: Exception) {
            Log.e("AdsManager", "Error showing rewarded interstitial ad: ${ignored.message}")
        }
    }

    @JvmStatic
    fun showAdmobInterstitialAd(
        context: Activity?,
        contentCallback: FullScreenContentCallback?,
        isFromCoins: Boolean = false,
    ) {
        if (context == null) return

        try {
            if (status_AdmobInterstitial && isNetworkAvailable.get() &&
                NUMBER_OF_INTERSTISHAL_ADS_SHOWN < NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION
            ) {

                val shouldShowAd = if (isFromCoins) true else iUtils.getRandomNumber(2) != 0

                if (shouldShowAd) {
                    mInterstitialAd?.let { ad ->
                        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                                contentCallback?.onAdDismissedFullScreenContent()
                                mInterstitialAd = null // Invalidate ad after dismissal
                                // Preload next ad
                                CoroutineScope(Dispatchers.Main).launch {
                                    loadInterstitialAd(context)
                                }
                            }

                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                super.onAdFailedToShowFullScreenContent(p0)
                                contentCallback?.onAdFailedToShowFullScreenContent(p0)
                                Log.e("AdsManager", "Failed to show interstitial ad: ${p0.message}")
                                // Attempt to reload if show fails
                                CoroutineScope(Dispatchers.Main).launch {
                                    loadInterstitialAd(context)
                                }
                            }

                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                                contentCallback?.onAdShowedFullScreenContent()
                                NUMBER_OF_INTERSTISHAL_ADS_SHOWN++
                                lastAdRequestTime = System.currentTimeMillis()
                                Log.d("AdsManager", "Interstitial Ad shown. Total: $NUMBER_OF_INTERSTISHAL_ADS_SHOWN")
                            }
                        }
                        ad.show(context)
                    } ?: run {
                        Log.d("AdsManager", "The interstitial ad wasn't ready yet. Attempting to load.")
                        // Attempt to load if not ready
                        CoroutineScope(Dispatchers.Main).launch {
                            loadInterstitialAd(context)
                        }
                    }
                } else {
                    Log.d("AdsManager", "Interstitial ad skipped due to random number.")
                    // Even if skipped by random number, ensure next ad is preloaded
                    CoroutineScope(Dispatchers.Main).launch {
                        loadInterstitialAd(context)
                    }
                }
            } else {
                Log.d("AdsManager", "Interstitial ad not shown: Network not available, ad status disabled, or limit reached.")
                if (status_AdmobInterstitial && isNetworkAvailable.get() &&
                    NUMBER_OF_INTERSTISHAL_ADS_SHOWN < NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION && mInterstitialAd == null
                ) {
                    // If not shown due to not ready, and conditions are met, try to load
                    CoroutineScope(Dispatchers.Main).launch {
                        loadInterstitialAd(context)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("AdsManager", "Error showing interstitial ad: ${e.message}")
        }
    }

    // Coroutine function to load interstitial ad
    private suspend fun loadInterstitialAd(context: Activity) {
        if (!status_AdmobInterstitial || !isNetworkAvailable.get() || isInterstitialAdLoading.get() ||
            NUMBER_OF_INTERSTISHAL_ADS_SHOWN >= NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION) {
            Log.d("AdsManager", "Interstitial ad load skipped: conditions not met or already loading.")
            return
        }
        isInterstitialAdLoading.set(true)
        withContext(Dispatchers.Main) {
            try {
                val adRequest = AdRequest.Builder().build()
                InterstitialAd.load(
                    context, videoapp_AdmobInterstitial!!, adRequest,
                    object : InterstitialAdLoadCallback() {
                        override fun onAdLoaded(interstitialAd: InterstitialAd) {
                            mInterstitialAd = interstitialAd
                            isInterstitialAdLoading.set(false)
                            Log.d("AdsManager", "Interstitial Ad was loaded successfully.")
                        }

                        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                            mInterstitialAd = null
                            isInterstitialAdLoading.set(false)
                            Log.d(
                                "AdsManager",
                                "Failed to load interstitial ad: ${loadAdError.message}. Retrying..."
                            )
                            // Implement retry logic for loading here, but with a delay to avoid hammering
                            if (retryCount < maxRetries) {
                                retryCount++
                                CoroutineScope(Dispatchers.Main).launch {
                                    delay(RETRY_DELAY_MS)
                                    loadInterstitialAd(context) // Retry loading
                                }
                            } else {
                                Log.d("AdsManager", "Max retries for interstitial ad reached.")
                                retryCount = 0 // Reset for next time
                            }
                        }
                    })
            } catch (e: Exception) {
                mInterstitialAd = null
                isInterstitialAdLoading.set(false)
                e.printStackTrace()
                Log.e("AdsManager", "Error in loadInterstitialAd: ${e.message}")
            }
        }
    }

    private suspend fun loadBannerAd(activity: Activity, adContainer: ViewGroup) {
        if (!canShowAd() || !status_AdmobBanner || !isNetworkAvailable.get() ||
            NUMBER_OF_BANNER_ADS_SHOWN >= NUMBER_OF_BANNER_ADS_PER_SESSION) {
            withContext(Dispatchers.Main) {
                adContainer.visibility = View.GONE
                adContainer.removeAllViews() // Clear any existing ad views
            }
            Log.d("AdsManager", "Banner ad load skipped: conditions not met.")
            return
        }

        withContext(Dispatchers.Main) {
            try {
                NUMBER_OF_BANNER_ADS_SHOWN++
                lastAdRequestTime = System.currentTimeMillis()

                val adView = AdView(activity).apply {
                    setAdSize(AdSize.BANNER)
                    adUnitId = videoapp_AdmobBanner!!
                    adListener = createBannerAdListener(adContainer)
                }

                // Ensure only one ad is in the container
                adContainer.removeAllViews()
                adContainer.addView(adView)
                adView.loadAd(AdRequest.Builder().build())
                Log.d("AdsManager", "Banner Ad loaded. Total: $NUMBER_OF_BANNER_ADS_SHOWN")

            } catch (e: Exception) {
                destroyAdview()
                adContainer.visibility = View.GONE
                adContainer.removeAllViews()
                e.printStackTrace()
                Log.e("AdsManager", "Error in loadBannerAd: ${e.message}")
            }
        }
    }

    private fun createBannerAdListener(adContainer: ViewGroup) = object : AdListener() {
        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
            super.onAdFailedToLoad(loadAdError)
            CoroutineScope(Dispatchers.Main).launch {
                adContainer.visibility = View.GONE
                adContainer.removeAllViews()
                Log.e("AdsManager", "Banner ad failed to load: ${loadAdError.message}")
            }
        }

        override fun onAdLoaded() {
            super.onAdLoaded()
            CoroutineScope(Dispatchers.Main).launch {
                adContainer.visibility = View.VISIBLE
                Log.d("AdsManager", "Banner ad loaded successfully.")
            }
        }
    }

    @JvmStatic
    fun cleanup(context: Context) {
        try {
            networkCallback?.let {
                val connectivityManager =
                    context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                connectivityManager.unregisterNetworkCallback(it)
                networkCallback = null
            }
            destroyAdview()
            mInterstitialAd = null
            mRewardedAd = null
            rewardedInterstitialAd = null
            Log.d("AdsManager", "AdsManager cleaned up.")
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("AdsManager", "Error during cleanup: ${e.message}")
        }

    }


    // Function to start loading the ad asynchronously
    @JvmStatic
    fun loadBannerAdAsync(activity: Activity, adContainer: ViewGroup) {
        GlobalScope.launch(Dispatchers.Main) {
            try {
                loadBannerAd(activity, adContainer)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("AdsManager", "Error in loadBannerAdAsync: ${e.message}")
            }
        }
    }

    private suspend fun loadRewardedInterstitialAd(context: Activity): RewardedInterstitialAd? {
        if (!status_AdmobInterstitial || !isNetworkAvailable.get() || isRewardedInterstitialAdLoading.get()) {
            Log.d("AdsManager", "Rewarded interstitial ad load skipped: conditions not met or already loading.")
            return null
        }
        isRewardedInterstitialAdLoading.set(true)
        return suspendCancellableCoroutine { continuation ->
            try {
                RewardedInterstitialAd.load(
                    context, videoapp_AdmobRewardedInterstitial!!,
                    AdRequest.Builder().build(), object : RewardedInterstitialAdLoadCallback() {
                        override fun onAdLoaded(ad: RewardedInterstitialAd) {
                            rewardedInterstitialAd = ad
                            isRewardedInterstitialAdLoading.set(false)
                            Log.d("AdsManager", "Rewarded interstitial Ad was loaded successfully.")
                            continuation.resume(ad)
                        }

                        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                            rewardedInterstitialAd = null
                            isRewardedInterstitialAdLoading.set(false)
                            Log.d("AdsManager", "Failed to load rewarded interstitial ad: ${loadAdError.message}. Retrying...")
                            if (retryCount < maxRetries) {
                                retryCount++
                                CoroutineScope(Dispatchers.Main).launch {
                                    delay(RETRY_DELAY_MS)
                                    loadRewardedInterstitialAd(context)
                                }
                            } else {
                                Log.d("AdsManager", "Max retries for rewarded interstitial ad reached.")
                                retryCount = 0
                                continuation.resumeWithException(Exception(loadAdError.message))
                            }
                        }
                    }
                )
            } catch (e: Exception) {
                isRewardedInterstitialAdLoading.set(false)
                continuation.resumeWithException(e)
                Log.e("AdsManager", "Error in loadRewardedInterstitialAd: ${e.message}")
            }
        }
    }


    @JvmStatic
    fun loadInterstitialAdAsync(context: Activity) {
        GlobalScope.launch(Dispatchers.Main) {
            loadInterstitialAd(context)
        }
    }


    @JvmStatic
    fun loadRewardedInterstitialAdAsync(context: Activity) {
        GlobalScope.launch(Dispatchers.Main) {
            try {
                rewardedInterstitialAd = loadRewardedInterstitialAd(context)
            } catch (e: Exception) {
                rewardedInterstitialAd = null
                e.printStackTrace()
                Log.e("AdsManager", "Error in loadRewardedInterstitialAdAsync: ${e.message}")
            }
        }
    }


    @JvmStatic
    fun loadAdmobNativeAdAsync(context: Activity, frameLayout: FrameLayout) {
        GlobalScope.launch(Dispatchers.Main) {
            loadAdmobNativeAd(context, frameLayout)
        }
    }


    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        try {
            adView.mediaView = adView.findViewById(R.id.ad_media)
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)
            adView.priceView = adView.findViewById(R.id.ad_price)
            adView.starRatingView = adView.findViewById(R.id.ad_stars)
            adView.storeView = adView.findViewById(R.id.ad_store)
            adView.advertiserView = adView.findViewById(R.id.ad_advertiser)

            (Objects.requireNonNull(adView.headlineView) as TextView).text = nativeAd.headline
            Objects.requireNonNull(adView.mediaView!!).mediaContent =
                Objects.requireNonNull(nativeAd.mediaContent)

            if (nativeAd.body == null) {
                Objects.requireNonNull(adView.bodyView!!).visibility = View.INVISIBLE
            } else {
                Objects.requireNonNull(adView.bodyView!!).visibility = View.VISIBLE
                (adView.bodyView as TextView?)!!.text = nativeAd.body
            }

            if (nativeAd.callToAction == null) {
                Objects.requireNonNull(adView.callToActionView!!).visibility = View.INVISIBLE
            } else {
                Objects.requireNonNull(adView.callToActionView!!).visibility = View.VISIBLE
                (adView.callToActionView as TextView?)!!.text = nativeAd.callToAction
            }

            if (nativeAd.icon == null) {
                Objects.requireNonNull(adView.iconView!!).visibility = View.GONE
            } else {
                (Objects.requireNonNull(adView.iconView) as ImageView).setImageDrawable(
                    nativeAd.icon!!.drawable
                )
                adView.iconView!!.visibility = View.VISIBLE
            }

            if (nativeAd.price == null) {
                Objects.requireNonNull(adView.priceView!!).visibility = View.INVISIBLE
            } else {
                Objects.requireNonNull(adView.priceView!!).visibility = View.VISIBLE
                (adView.priceView as TextView?)!!.text = nativeAd.price
            }

            if (nativeAd.store == null) {
                Objects.requireNonNull(adView.storeView!!).visibility = View.INVISIBLE
            } else {
                Objects.requireNonNull(adView.storeView!!).visibility = View.VISIBLE
                (adView.storeView as TextView?)!!.text = nativeAd.store
            }

            if (nativeAd.starRating == null) {
                Objects.requireNonNull(adView.starRatingView!!).visibility = View.INVISIBLE
            } else {
                (Objects.requireNonNull(adView.starRatingView) as RatingBar).rating =
                    nativeAd.starRating!!.toFloat()

                adView.starRatingView!!.visibility = View.VISIBLE
            }

            if (nativeAd.advertiser == null) {
                Objects.requireNonNull(adView.advertiserView!!).visibility = View.INVISIBLE
            } else {
                (Objects.requireNonNull(adView.advertiserView) as TextView).text =
                    nativeAd.advertiser
                adView.advertiserView!!.visibility = View.VISIBLE
            }

            adView.setNativeAd(nativeAd)

            val vc = nativeAd.mediaContent!!.videoController

            if (vc.hasVideoContent()) {
                vc.videoLifecycleCallbacks = object : VideoLifecycleCallbacks() {
                    override fun onVideoStart() { Log.d("AdsManager", "Native Video Started") }
                    override fun onVideoPlay() { Log.d("AdsManager", "Native Video Played") }
                    override fun onVideoPause() { Log.d("AdsManager", "Native Video Paused") }
                    override fun onVideoEnd() { Log.d("AdsManager", "Native Video Ended") }
                    override fun onVideoMute(p0: Boolean) { Log.d("AdsManager", "Native Video Muted") }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("AdsManager", "Error populating native ad view: ${e.message}")
        }
    }


    @SuppressLint("MissingPermission")
    fun loadAdmobNativeAd(context: Activity, frameLayout: FrameLayout) {
        if (!status_AdmobNativeID || !isNetworkAvailable.get() || isNativeAdLoading.get()) {
            Log.d("AdsManager", "Native ad load skipped: conditions not met or already loading.")
            return
        }
        isNativeAdLoading.set(true)
        try {
            val adLoader = AdLoader.Builder(context, videoapp_AdmobNativeID!!)
                .forNativeAd { nativeAd ->
                    val adView = context.layoutInflater.inflate(
                        R.layout.layout_native_ads,
                        null
                    ) as NativeAdView
                    populateNativeAdView(nativeAd, adView)

                    GlobalScope.launch(Dispatchers.Main) {
                        frameLayout.removeAllViews()
                        frameLayout.addView(adView)
                        frameLayout.visibility = View.VISIBLE // Ensure visibility
                        isNativeAdLoading.set(false)
                    }
                }
                .withNativeAdOptions(
                    NativeAdOptions.Builder()
                        .setVideoOptions(VideoOptions.Builder().setStartMuted(true).build())
                        .build()
                )
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        super.onAdFailedToLoad(loadAdError)
                        isNativeAdLoading.set(false)
                        Log.e("AdsManager", "Native ad load failed: ${loadAdError.message}")

                        if (retryCount < maxRetries) {
                            retryCount++
                            Log.e("AdsManager", "Retrying native ad... Attempt $retryCount")
                            GlobalScope.launch(Dispatchers.Main) {
                                delay(RETRY_DELAY_MS)
                                loadAdmobNativeAd(context, frameLayout)  // Retry loading ad
                            }
                        } else {
                            Log.e("AdsManager", "Max retry limit reached for native ad.")
                            retryCount = 0  // Reset retry count if exceeded
                            GlobalScope.launch(Dispatchers.Main) {
                                frameLayout.visibility = View.GONE
                                frameLayout.removeAllViews()
                            }
                        }
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.d("AdsManager", "NativeAd loaded successfully.")
                        retryCount = 0 // Reset retry count when ad is successfully loaded
                    }
                })
                .build()

            adLoader.loadAd(AdRequest.Builder().build())

        } catch (e: Exception) {
            isNativeAdLoading.set(false)
            e.printStackTrace()
            Log.e("AdsManager", "Error loading native ad: ${e.message}")
            GlobalScope.launch(Dispatchers.Main) {
                frameLayout.visibility = View.GONE
                frameLayout.removeAllViews()
            }
        }
    }

    @JvmStatic
    fun loadVideoAdAdmobAsync(
        activity: Activity,
        fullScreenContentCallback: FullScreenContentCallback?
    ) {
        GlobalScope.launch(Dispatchers.Main) {
            try {
                loadVideoAdAdmob(activity, fullScreenContentCallback)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("AdsManager", "Error in loadVideoAdAdmobAsync: ${e.message}")
            }
        }
    }


    @JvmStatic
    fun loadVideoAdAdmob(
        activity: Activity,
        fullScreenContentCallback: FullScreenContentCallback?
    ) {
        if (!status_AdmobRewardID || !isNetworkAvailable.get() || isRewardedAdLoading.get() || activity.isFinishing) {
            Log.d("AdsManager", "Rewarded video ad load skipped: conditions not met or already loading.")
            return
        }
        val nn = SharedPrefsMainApp(activity).preferencE_inappads
        if (nn != null && nn == "nnn" && Constants.show_Ads && !BuildConfig.ISPRO) {
            isRewardedAdLoading.set(true)
            try {
                val adRequest = AdRequest.Builder().build()
                val rewardAdId =
                    if (iUtils.getRandomNumber(2) == 0) videoapp_AdmobRewardID else videoapp_AdmobRewardVideoExtraFeatures

                RewardedAd.load(
                    activity,
                    rewardAdId!!,
                    adRequest,
                    object : RewardedAdLoadCallback() {
                        override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                            Log.d("AdsManager", "Rewarded video ad failed to load: ${loadAdError.message}")
                            mRewardedAd = null
                            isRewardedAdLoading.set(false)
                            if (retryCount < maxRetries) {
                                retryCount++
                                CoroutineScope(Dispatchers.Main).launch {
                                    delay(RETRY_DELAY_MS)
                                    loadVideoAdAdmob(activity, fullScreenContentCallback)
                                }
                            } else {
                                Log.d("AdsManager", "Max retries for rewarded video ad reached.")
                                retryCount = 0
                            }
                        }

                        override fun onAdLoaded(rewardedAd: RewardedAd) {
                            mRewardedAd = rewardedAd
                            isRewardedAdLoading.set(false)
                            Log.d("AdsManager", "Rewarded Video Ad was loaded successfully.")
                            mRewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                                override fun onAdDismissedFullScreenContent() {
                                    super.onAdDismissedFullScreenContent()
                                    fullScreenContentCallback?.onAdDismissedFullScreenContent()
                                    mRewardedAd = null // Invalidate after dismissal
                                    // Preload next ad after dismissal
                                    GlobalScope.launch(Dispatchers.Main) {
                                        loadVideoAdAdmob(activity, null)
                                    }
                                }

                                override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                    super.onAdFailedToShowFullScreenContent(p0)
                                    fullScreenContentCallback?.onAdFailedToShowFullScreenContent(p0)
                                    Log.e("AdsManager", "Failed to show rewarded video ad: ${p0.message}")
                                    // Attempt to reload if show fails
                                    GlobalScope.launch(Dispatchers.Main) {
                                        loadVideoAdAdmob(activity, null)
                                    }
                                }

                                override fun onAdShowedFullScreenContent() {
                                    super.onAdShowedFullScreenContent()
                                    fullScreenContentCallback?.onAdShowedFullScreenContent()
                                    Log.d("AdsManager", "Rewarded video ad showed.")
                                }
                            }
                            retryCount = 0 // Reset retry count on successful load
                        }
                    })
            } catch (e: Exception) {
                mRewardedAd = null
                isRewardedAdLoading.set(false)
                e.printStackTrace()
                Log.e("AdsManager", "Error in loadVideoAdAdmob: ${e.message}")
            }
        } else {
            Log.d("AdsManager", "Rewarded video ad not loaded: In-app ads disabled or pro version.")
        }
    }

    @JvmStatic
    fun showVideoAdAdmobAsync(
        activity: Activity,
        onUserEarnedRewardListener: OnUserEarnedRewardListener?,
        isFromCoins: Boolean = false,
    ) {
        GlobalScope.launch(Dispatchers.Main) {
            try {
                showVideoAdAdmob(activity, onUserEarnedRewardListener, isFromCoins)
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("AdsManager", "Error in showVideoAdAdmobAsync: ${e.message}")
            }
        }
    }

    @JvmStatic
    suspend fun showVideoAdAdmob(
        activity: Activity,
        onUserEarnedRewardListener: OnUserEarnedRewardListener?,
        isFromCoins: Boolean = false,
    ) {
        if (!status_AdmobRewardID || !isNetworkAvailable.get() || activity.isFinishing) {
            Log.d("AdsManager", "Rewarded video ad not shown: conditions not met.")
            return
        }
        val nn = SharedPrefsMainApp(activity).preferencE_inappads
        if (nn != null && nn == "nnn" && Constants.show_Ads && !BuildConfig.ISPRO) {
            try {
                val randomNumber = if (isFromCoins) 2 else iUtils.getRandomNumber(4)
                if (randomNumber == 2) {
                    if (mRewardedAd != null) {
                        withContext(Dispatchers.Main) {
                            mRewardedAd?.show(activity, onUserEarnedRewardListener!!)
                            Log.d("AdsManager", "Rewarded video ad shown.")
                            mRewardedAd = null // Invalidate after showing
                            // Preload the next ad
                            loadVideoAdAdmob(activity, null)
                        }
                    } else {
                        Log.d("AdsManager", "The rewarded ad wasn't ready yet. Attempting to load.")
                        // If the ad is not ready, try to load it immediately
                        loadVideoAdAdmob(activity, null)
                    }
                } else {
                    Log.d("AdsManager", "Rewarded video ad skipped due to random number.")
                    // Even if skipped by random number, ensure next ad is preloaded
                    loadVideoAdAdmob(activity, null)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Log.e("AdsManager", "Error showing rewarded video ad: ${e.message}")
            }
        } else {
            Log.d("AdsManager", "Rewarded video ad not shown: In-app ads disabled or pro version.")
        }
    }

}












//    if (AdsManager.mInterstitialAd != null){
//            AdsManager.showAdmobInterstitialAd(HomeActivity.this, new FullScreenContentCallback() {
//@Override
//public void onAdDismissedFullScreenContent() {
//        super.onAdDismissedFullScreenContent();
//        Intent intent = new Intent(HomeActivity.this, SecondActivity.class);
//        intent.putExtra("fragment", "textToPdf");
//        startActivity(intent);
//        }
//@Override
//public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
//        super.onAdFailedToShowFullScreenContent(adError);
//        Intent intent = new Intent(HomeActivity.this, SecondActivity.class);
//        intent.putExtra("fragment", "textToPdf");
//        startActivity(intent);
//        }
//        });
//        } else {
//        Intent intent = new Intent(HomeActivity.this, SecondActivity.class);
//        intent.putExtra("fragment", "textToPdf");
//        startActivity(intent);
//        }

//TODO adsmanager fb ads
//public class AdsManager {
//
//    //TODO change this if you want to limit interstishal ads
//    public static int NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION = 12;
//    //TODO dont touch this
//    public static int NUMBER_OF_INTERSTISHAL_ADS_SHOWN = 0;
//
//
//    //TODO change this if you want to limit banner ads
//    public static int NUMBER_OF_BANNER_ADS_PER_SESSION = 5;
//    //TODO dont touch this
//    public static int NUMBER_OF_BANNER_ADS_SHOWN = 0;
//    static com.facebook.ads.AdView fanAdView;
//
//    static com.facebook.ads.NativeAd nativeAd;
//
//    static com.facebook.ads.InterstitialAd fanInterstitialAd;
//    private int retryAttempt;
//    private int counter = 1;
//
//    //Manage Ads ID - FACEBOOK
//    public static final String FACEBOOK_BANNER_ID = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
//    public static final String FACEBOOK_INTER_ID = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
//    public static final String FACEBOOK_NATIVE_ID = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
//
//    @SuppressLint("MissingPermission")
//    public static void loadBannerAd(final Activity activity, final ViewGroup adContainer) {
//        if (AdsManager.NUMBER_OF_BANNER_ADS_SHOWN < AdsManager.NUMBER_OF_BANNER_ADS_PER_SESSION) {
//            AdsManager.NUMBER_OF_BANNER_ADS_SHOWN++;
//
//
//            fanAdView = new com.facebook.ads.AdView(activity, FACEBOOK_BANNER_ID, AdSize.BANNER_HEIGHT_50);
//            // Add the ad view to your activity layout
//            adContainer.addView(fanAdView);
//            com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
//                @Override
//                public void onError(Ad ad, AdError adError) {
//                    adContainer.setVisibility(View.GONE);
//                    Log.d("adload", "Failed to load Audience Network : " + adError.getErrorMessage() + " "  + adError.getErrorCode());
//                }
//
//                @Override
//                public void onAdLoaded(Ad ad) {
//                    adContainer.setVisibility(View.VISIBLE);
//                }
//
//                @Override
//                public void onAdClicked(Ad ad) {
//
//                }
//
//                @Override
//                public void onLoggingImpression(Ad ad) {
//
//                }
//            };
//            com.facebook.ads.AdView.AdViewLoadConfig loadAdConfig = fanAdView.buildLoadAdConfig().withAdListener(adListener).build();
//            fanAdView.loadAd(loadAdConfig);
//
//        } else {
//            adContainer.setVisibility(View.GONE);
//        }
//    }
//
//
//
//    public static void showFacebookInterstitialAd(final Context context) {
//
//        try {
//            if (fanInterstitialAd != null && fanInterstitialAd.isAdLoaded()) {
//                if (AdsManager.NUMBER_OF_INTERSTISHAL_ADS_SHOWN < AdsManager.NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION) {
//                    fanInterstitialAd.show();
//                }
//            }
//        } catch (Exception ignored) {
//        }
//    }
//
//
//    public static void loadFacebookInterstitialAd(final Context context) {
//
//        fanInterstitialAd = new com.facebook.ads.InterstitialAd(context, FACEBOOK_INTER_ID);
//        InterstitialAdListener adListener = new InterstitialAdListener() {
//            @Override
//            public void onError(Ad ad, AdError adError) {
//
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                Log.d("adload", "FAN Interstitial Ad loaded...");
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//                fanInterstitialAd.loadAd();
//            }
//        };
//
//        com.facebook.ads.InterstitialAd.InterstitialLoadAdConfig loadAdConfig = fanInterstitialAd.buildLoadAdConfig().withAdListener(adListener).build();
//        fanInterstitialAd.loadAd(loadAdConfig);
//
//
//    }
//
//
//    @SuppressLint("MissingPermission")
//    public static void loadFacebookNativeAd(Context context, LinearLayout frameLayout) {
//        try {
//
//            nativeAd = new com.facebook.ads.NativeAd(context, FACEBOOK_NATIVE_ID);
//
//
//            NativeAdListener nativeAdListener = new NativeAdListener() {
//                @Override
//                public void onMediaDownloaded(Ad ad) {
//
//                }
//
//                @Override
//                public void onError(Ad ad, AdError adError) {
//
//                }
//
//                @Override
//                public void onAdLoaded(Ad ad) {
//                    // Render the Native Ad Template
//                    View adView = com.facebook.ads.NativeAdView.render(context, nativeAd);
//
//                    // Add the Native Ad View to your ad container.
//                    // The recommended dimensions for the ad container are:
//                    // Width: 280dp - 500dp
//                    // Height: 250dp - 500dp
//                    // The template, however, will adapt to the supplied dimensions.
//                    frameLayout.addView(adView, new LinearLayout.LayoutParams(MATCH_PARENT, 800));
//                }
//
//                @Override
//                public void onAdClicked(Ad ad) {
//
//                }
//
//                @Override
//                public void onLoggingImpression(Ad ad) {
//
//                }
//            };
//
//            // Initiate a request to load an ad.
//            nativeAd.loadAd(
//                    nativeAd.buildLoadAdConfig()
//                            .withAdListener(nativeAdListener)
//                            .withMediaCacheFlag(NativeAdBase.MediaCacheFlag.ALL)
//                            .build());
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//
//}
//todo applovin ads
//public class AdsManager {
//
//    //TODO change this if you want to limit interstishal ads
//    public static int NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION = 12;
//    //TODO dont touch this
//    public static int NUMBER_OF_INTERSTISHAL_ADS_SHOWN = 0;
//
//
//    //TODO change this if you want to limit banner ads
//    public static int NUMBER_OF_BANNER_ADS_PER_SESSION = 5;
//    //TODO dont touch this
//    public static int NUMBER_OF_BANNER_ADS_SHOWN = 0;
//
//
//    public static MaxAdView adView;
//    public static MaxInterstitialAd interstitialAd;
//    public static int retryAttempt;
//
//
//    public static MaxRewardedAd rewardedAd;
//    public static int retryAttemptvideo;
//
//    public static MaxNativeAdLoader nativeAdLoader;
//    public static MaxAd nativeAd;
//
//
//    @SuppressLint("MissingPermission")
//    public static void loadBannerAd(final Activity activity, final ViewGroup adContainer, boolean slamm) {
//        if (AdsManager.NUMBER_OF_BANNER_ADS_SHOWN < AdsManager.NUMBER_OF_BANNER_ADS_PER_SESSION) {
//            AdsManager.NUMBER_OF_BANNER_ADS_SHOWN++;
//
//            adView = new MaxAdView("4fce746e596e78a4", activity);
//            adView.setListener(new MaxAdViewAdListener() {
//                @Override
//                public void onAdExpanded(MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdCollapsed(MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdLoaded(MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdDisplayed(MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdHidden(MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdClicked(MaxAd ad) {
//
//                }
//
//                @Override
//                public void onAdLoadFailed(String adUnitId, MaxError error) {
//
//                }
//
//                @Override
//                public void onAdDisplayFailed(MaxAd ad, MaxError error) {
//
//                }
//            });
//
//            // Stretch to the width of the screen for banners to be fully functional
//            int width = ViewGroup.LayoutParams.MATCH_PARENT;
//
//            // Get the adaptive banner height.
//            int heightDp = MaxAdFormat.BANNER.getAdaptiveSize(activity).getHeight();
//            int heightPx = AppLovinSdkUtils.dpToPx(activity, heightDp);
//
//            adView.setLayoutParams(new FrameLayout.LayoutParams(width, heightPx));
//            adView.setExtraParameter("adaptive_banner", "true");
//            adContainer.addView(adView);
//
//            // Load the ad
//            adView.loadAd();
//
//
//        } else {
//            adContainer.setVisibility(View.GONE);
//        }
//    }
//
//
//    public static void loadInterstitialAd(final Context context) {
//
//
//        if (AdsManager.NUMBER_OF_INTERSTISHAL_ADS_SHOWN < AdsManager.NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION) {
//
//            interstitialAd = new MaxInterstitialAd("793894cce69278b7", (Activity) context);
//            interstitialAd.setListener(new MaxAdListener() {
//                @Override
//                public void onAdLoaded(MaxAd ad) {
//                    // Reset retry attempt
//                    retryAttempt = 0;
//
//                }
//
//                @Override
//                public void onAdLoadFailed(final String adUnitId, final MaxError error) {
//                    // Interstitial ad failed to load
//                    // AppLovin recommends that you retry with exponentially higher delays up to a maximum delay (in this case 64 seconds)
//
//                    retryAttempt++;
//                    long delayMillis = TimeUnit.SECONDS.toMillis((long) Math.pow(2, Math.min(6, retryAttempt)));
//
//                    new Handler().postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            interstitialAd.loadAd();
//                        }
//                    }, delayMillis);
//                }
//
//                @Override
//                public void onAdDisplayFailed(final MaxAd maxAd, final MaxError error) {
//                    // Interstitial ad failed to display. AppLovin recommends that you load the next ad.
//                    interstitialAd.loadAd();
//                }
//
//                @Override
//                public void onAdDisplayed(final MaxAd maxAd) {
//                }
//
//                @Override
//                public void onAdClicked(final MaxAd maxAd) {
//                }
//
//                @Override
//                public void onAdHidden(final MaxAd maxAd) {
//                    // Interstitial ad is hidden. Pre-load the next ad
//                    interstitialAd.loadAd();
//                }
//            });
//
//            // Load the first ad
//            interstitialAd.loadAd();
//        }
//
//    }
//    public static void showInterstitialAd(final Context context) {
//
//
//        if (AdsManager.NUMBER_OF_INTERSTISHAL_ADS_SHOWN < AdsManager.NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION) {
//
//
//            if (interstitialAd.isReady()) {
//                interstitialAd.showAd();
//            }
//
//        }
//
//    }
//
//
//    public static void loadVideoAdAdmob(final Activity activity) {
//        try {
//            SharedPreferences prefs = activity.getSharedPreferences("whatsapp_pref",
//                    Context.MODE_PRIVATE);
//            String nn = prefs.getString("inappads", "nnn");//"No name defined" is the default value.
//
//
//            if (nn != null && nn.equals("nnn") && Constants.show_Ads) {
//                System.out.println("ads working");
//
//
//                if (!activity.isFinishing()) {
//                    rewardedAd = MaxRewardedAd.getInstance("0d4dacca795e2e5f", activity);
//                    rewardedAd.setListener(new MaxRewardedAdListener() {
//                        // MAX Ad Listener
//                        @Override
//                        public void onAdLoaded(final MaxAd maxAd) {
//                            // Rewarded ad is ready to be shown. rewardedAd.isReady() will now return 'true'
//
//                            // Reset retry attempt
//                            retryAttemptvideo = 0;
//                        }
//
//                        @Override
//                        public void onAdLoadFailed(final String adUnitId, final MaxError error) {
//                            // Rewarded ad failed to load
//                            // We recommend retrying with exponentially higher delays up to a maximum delay (in this case 64 seconds)
//
//                            retryAttemptvideo++;
//                            long delayMillis = TimeUnit.SECONDS.toMillis((long) Math.pow(2, Math.min(6, retryAttemptvideo)));
//
//                            new Handler().postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    rewardedAd.loadAd();
//                                }
//                            }, delayMillis);
//                        }
//
//                        @Override
//                        public void onAdDisplayFailed(final MaxAd maxAd, final MaxError error) {
//                            // Rewarded ad failed to display. We recommend loading the next ad
//                            rewardedAd.loadAd();
//                        }
//
//                        @Override
//                        public void onAdDisplayed(final MaxAd maxAd) {
//                        }
//
//                        @Override
//                        public void onAdClicked(final MaxAd maxAd) {
//                        }
//
//                        @Override
//                        public void onAdHidden(final MaxAd maxAd) {
//                            // rewarded ad is hidden. Pre-load the next ad
//                            rewardedAd.loadAd();
//                        }
//
//                        @Override
//                        public void onRewardedVideoStarted(final MaxAd maxAd) {
//                        }
//
//                        @Override
//                        public void onRewardedVideoCompleted(final MaxAd maxAd) {
//                        }
//
//                        @Override
//                        public void onUserRewarded(final MaxAd maxAd, final MaxReward maxReward) {
//                            // Rewarded ad was displayed and user should receive the reward
//                        }
//                    });
//
//                    rewardedAd.loadAd();
//                }
//
//            }
//        } catch (Exception ignored) {
//        }
//
//    }
//
//    public static void showVideoAdAdmob(final Activity activity) {
//        try {
//            SharedPreferences prefs = activity.getSharedPreferences("whatsapp_pref",
//                    Context.MODE_PRIVATE);
//            String nn = prefs.getString("inappads", "nnn");//"No name defined" is the default value.
//
//
//            if (nn != null && nn.equals("nnn") && Constants.show_Ads) {
//
//                if (!activity.isFinishing()) {
//
//                    if (rewardedAd.isReady()) {
//                        rewardedAd.showAd();
//                    }
//                } else {
//                    Log.d("adload", "The rewarded ad wasn't ready yet.");
//                    Toast.makeText(activity, activity.getResources().getString(R.string.videonotavaliabl), Toast.LENGTH_SHORT).show();
//
//                }
//
//            }
//        } catch (Exception ignored) {
//        }
//    }
//
//    public static void loadNativeAds(final Activity activity, final FrameLayout adContainer) {
//        try {
//            SharedPreferences prefs = activity.getSharedPreferences("whatsapp_pref",
//                    Context.MODE_PRIVATE);
//            String nn = prefs.getString("inappads", "nnn");//"No name defined" is the default value.
//
//
//            if (nn != null && nn.equals("nnn") && Constants.show_Ads) {
//
//                if (!activity.isFinishing()) {
//
//                    nativeAdLoader = new MaxNativeAdLoader("0d4dacca795e2e5f", activity);
//                    nativeAdLoader.setNativeAdListener(new MaxNativeAdListener() {
//                        @Override
//                        public void onNativeAdLoaded(final MaxNativeAdView nativeAdView, final MaxAd ad) {
//                            // Clean up any pre-existing native ad to prevent memory leaks.
//                            if (nativeAd != null) {
//                                nativeAdLoader.destroy(nativeAd);
//                            }
//
//                            // Save ad for cleanup.
//                            nativeAd = ad;
//
//                            // Add ad view to view.
//                            adContainer.removeAllViews();
//                            adContainer.addView(nativeAdView);
//                        }
//
//                        @Override
//                        public void onNativeAdLoadFailed(final String adUnitId, final MaxError error) {
//                            // We recommend retrying with exponentially higher delays up to a maximum delay
//                        }
//
//                        @Override
//                        public void onNativeAdClicked(final MaxAd ad) {
//                            // Optional click callback
//                        }
//                    });
//
//                    nativeAdLoader.loadAd();
//
//
//                } else {
//                    Log.d("adload", "The rewarded ad wasn't ready yet.");
//                    Toast.makeText(activity, activity.getResources().getString(R.string.videonotavaliabl), Toast.LENGTH_SHORT).show();
//
//                }
//
//            }
//        } catch (Exception ignored) {
//        }
//    }
//
//
//}


