package com.infusiblecoder.allinonevideodownloader.interfaces;

public interface DataCallBackNewJetApi {

    void onResult(boolean result);
}
