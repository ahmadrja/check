/*
 * *
 * * Updated by Gemini
 * * Optimized for Super-Lite (Option 1) - Removed YoutubeDL & FFmpeg
 * *
 */

package com.infusiblecoder.allinonevideodownloader.activities;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.Keep;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.ConfigurationCompat;

import com.google.android.gms.tasks.Task;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.infusiblecoder.allinonevideodownloader.BuildConfig;
import com.infusiblecoder.allinonevideodownloader.R;
import com.infusiblecoder.allinonevideodownloader.databinding.ActivitySplashScreenBinding;
import com.infusiblecoder.allinonevideodownloader.models.adminpanel.AdId;
import com.infusiblecoder.allinonevideodownloader.models.adminpanel.AppSettings;
import com.infusiblecoder.allinonevideodownloader.models.adminpanel.Setting;
import com.infusiblecoder.allinonevideodownloader.models.adminpanel.SocialMedia;
import com.infusiblecoder.allinonevideodownloader.onboarding.OnboardingActivity;
import com.infusiblecoder.allinonevideodownloader.utils.AdsManager;
import com.infusiblecoder.allinonevideodownloader.utils.Constants;
import com.infusiblecoder.allinonevideodownloader.utils.GlideApp;
import com.infusiblecoder.allinonevideodownloader.utils.LocaleHelper;
import com.infusiblecoder.allinonevideodownloader.utils.SharedPrefsMainApp;
import com.infusiblecoder.allinonevideodownloader.utils.iUtils;
import com.libs.androidnetworking.AndroidNetworking;
import com.libs.androidnetworking.common.Priority;
import com.libs.androidnetworking.error.ANError;
import com.libs.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.Executors;

public class SplashScreen extends AppCompatActivity {

    AppUpdateManager appUpdateManager;
    boolean isScreenShitStarted = false;
    androidx.core.splashscreen.SplashScreen splashScreen;

    InstallStateUpdatedListener installStateUpdatedListener = new
            InstallStateUpdatedListener() {
                @Override
                public void onStateUpdate(InstallState state) {
                    if (state.installStatus() == InstallStatus.DOWNLOADED) {
                        Log.i("SplashScreen", "InstallStateUpdatedListener: download complete");
                    } else if (state.installStatus() == InstallStatus.INSTALLED) {
                        if (appUpdateManager != null) {
                            appUpdateManager.unregisterListener(installStateUpdatedListener);
                        }
                        Log.i("SplashScreen", "InstallStateUpdatedListener: state: installed");

                    } else if (state.installStatus() == InstallStatus.FAILED) {
                        if (appUpdateManager != null) {
                            appUpdateManager.unregisterListener(installStateUpdatedListener);
                        }
                        Log.i("SplashScreen", "InstallStateUpdatedListener: state: failed " + state.installErrorCode());

                    }
                }
            };

    @Keep
    public static void getExistingAdminPanelData(Context context) {
        if (new SharedPrefsMainApp(context) != null && new SharedPrefsMainApp(context).getPREFERENCE_adminpanelapidata() != null && Constants.iSAdminAttached) {
            AppSettings appSettings = new SharedPrefsMainApp(context).getPREFERENCE_adminpanelapidata();

            if (appSettings.getAdIds() != null) {
                AdId adId = appSettings.getAdIds().get(0);
                AdsManager.status_AdmobBanner = adId.getBannerIDStatus();
                AdsManager.status_AdmobInterstitial = adId.getIntIDStatus();
                AdsManager.status_AdmobRewardID = adId.getRewardVideoIDStatus();
                AdsManager.status_AdmobNativeID = adId.getNativeAdIDStatus();
                AdsManager.NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION = adId.getIntClicks();

                if (Constants.enableTestAds) {
                    AdsManager.setDefaults((Application) context);
                } else {
                    AdsManager.videoapp_AdmobNativeID = adId.getNativeAdID();
                    AdsManager.videoapp_AdmobRewardID = adId.getRewardVideoID();
                    AdsManager.videoapp_AdmobRewardVideoExtraFeatures = adId.getRewardVideoID();
                    AdsManager.videoapp_AdmobInterstitial = adId.getIntID();
                    AdsManager.videoapp_AdmobBanner = adId.getBannerID();
                    AdsManager.videoapp_AdmobAppId = context.getResources().getString(R.string.AdmobAppId);
                }

                Setting setting = appSettings.getSettings().get(0);
                iUtils.isNewUi = setting.getNewUi();
                iUtils.myAppSettings = setting;
            }

            if (appSettings.getSocialMedias() != null) {
                if (iUtils.socialMediaList != null) {
                    iUtils.socialMediaList.clear();
                } else {
                    iUtils.socialMediaList = new ArrayList<>();
                }
                for (SocialMedia socialMedia : appSettings.getSocialMedias()) {
                    if (socialMedia.getStatus() == 1) {
                        iUtils.socialMediaList.add(socialMedia.getSource().toLowerCase());
                    }
                }
            }
        }
    }

    @Keep
    public static void checkExistingAppDataFromAdminPanelAndSetData(Context context) {
        AndroidNetworking.get(Constants.adminApiUrl + "/all")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response.toString());

                            if (jsonObject.getBoolean("status")) {
                                new SharedPrefsMainApp(context).setPREFERENCE_adminpanelapidata(response.toString());
                                getExistingAdminPanelData(context);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            getExistingAdminPanelData(context);
                        }
                    }

                    @Override
                    public void onError(ANError error) {
                        error.printStackTrace();
                        getExistingAdminPanelData(context);
                    }
                });
    }

    @Keep
    public static void uploadDownloadedUrl(String myUrl) {
        if (Constants.iSAdminAttached) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("download_url", myUrl);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            AndroidNetworking.post(Constants.adminApiUrl + "/downloadedurl")
                    .addJSONObjectBody(jsonObject)
                    .setPriority(Priority.MEDIUM)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // Do nothing
                        }

                        @Override
                        public void onError(ANError error) {
                            error.printStackTrace();
                        }
                    });
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT > 31) {
            splashScreen = androidx.core.splashscreen.SplashScreen.installSplashScreen(this);
        }
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ActivitySplashScreenBinding binding = ActivitySplashScreenBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        if (Build.VERSION.SDK_INT < 31) {
            setContentView(view);
        }

        isScreenShitStarted = false;

        try {
            appUpdateManager = AppUpdateManagerFactory.create(SplashScreen.this);
            appUpdateManager.registerListener(installStateUpdatedListener);

            binding.version.setText(String.format("%s %s\nBy: %s", getString(R.string.version), BuildConfig.VERSION_NAME, getString(R.string.developer_name)));
            if (com.infusiblecoder.allinonevideodownloader.BuildConfig.ISPRO) {
                GlideApp.with(SplashScreen.this)
                        .load(R.drawable.ic_appicon_pro)
                        .placeholder(R.drawable.ic_appicon_pro)
                        .into(binding.iconmain);
            }
            AdsManager.setDefaults(getApplication());

            Executors.newSingleThreadExecutor().submit(() -> {
                try {
                    iUtils.myInstagramTempCookies = iUtils.showCookies("https://www.instagram.com/");

                    if (Constants.iSAdminAttached) {
                        getAppDataFromAdminPanel();
                    }
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            });

            setDefaultLanguage();

            // Lite App Logic: Seedha update check karo aur aage badho (No Heavy Libs)
            if (!BuildConfig.DEBUG) {
                checkAppUpdate();
            } else {
                goToMainAndFinish();
            }

        } catch (Throwable e) {
            e.printStackTrace();
            Log.d("SplashScreen:Error", "onCreate: " + e.getMessage());
            goToMainAndFinish();
        }

        if (Build.VERSION.SDK_INT > 31) {
            if (splashScreen != null) {
                splashScreen.setKeepOnScreenCondition(() -> true);
            }
        }
    }

    void setDefaultLanguage() {
        try {
            SharedPreferences prefs = getSharedPreferences("lang_pref", MODE_PRIVATE);
            String deviceLang = Objects.requireNonNull(ConfigurationCompat.getLocales(Resources.getSystem().getConfiguration()).get(0)).getLanguage();
            String lang = prefs.getString("lang", deviceLang);

            if (!deviceLang.equals(lang)) {
                SharedPreferences sharedPreference = getSharedPreferences("lang_pref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreference.edit();
                editor.putString("lang", deviceLang);
                editor.apply();
                lang = deviceLang;
            }
            LocaleHelper.setLocale(getApplicationContext(), lang);
            if (lang.equals("ur") || lang.equals("ar")) {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            } else {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!BuildConfig.DEBUG) {
            appUpdateManager.getAppUpdateInfo().addOnSuccessListener(appUpdateInfo -> {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(
                                appUpdateInfo, AppUpdateType.IMMEDIATE, SplashScreen.this, 1009);
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();
                    }
                }
            });
        } else {
            goToMainAndFinish();
        }
    }

    private void goToMainAndFinish() {
        if (!isScreenShitStarted) {
            isScreenShitStarted = true;
            new Handler(Looper.getMainLooper()).postDelayed(() -> {

                boolean isFirstTime = new SharedPrefsMainApp(SplashScreen.this).getPREFERENCE_isFirstTime();

                if (isFirstTime) {
                    startActivity(new Intent(SplashScreen.this, OnboardingActivity.class));
                } else {
                    startActivity(new Intent(SplashScreen.this, MainActivity.class));
                }
                finish();

            }, 1500);
        }
    }

    public void checkAppUpdate() {
        try {
            Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
            appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(
                                appUpdateInfo, AppUpdateType.IMMEDIATE, SplashScreen.this, 1009);
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();
                    }
                } else {
                    goToMainAndFinish();
                }
            }).addOnFailureListener(e -> {
                e.printStackTrace();
                goToMainAndFinish();
            });

        } catch (Exception e) {
            e.printStackTrace();
            goToMainAndFinish();
        }
    }

    @Keep
    public void getAppDataFromAdminPanel() {
        JSONObject jsonObject = new JSONObject();
        try {
            @SuppressLint("HardwareIds") String android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wInfo = wifiManager.getConnectionInfo();
            @SuppressLint("HardwareIds") String macAddress = wInfo.getBSSID();

            jsonObject.put("macAddress", macAddress);
            jsonObject.put("deviceId", android_id);
            jsonObject.put("packageName", BuildConfig.APPLICATION_ID);
            jsonObject.put("appVersion", BuildConfig.VERSION_NAME);
            jsonObject.put("appBuildNo", BuildConfig.VERSION_CODE);
            if (new SharedPrefsMainApp(SplashScreen.this) != null && new SharedPrefsMainApp(SplashScreen.this).getPREFERENCE_adminpanelapidata() != null && Constants.iSAdminAttached) {
                jsonObject.put("isFirstBoolean", "0");
            } else {
                jsonObject.put("isFirstBoolean", "1");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        AndroidNetworking.post(Constants.adminApiUrl + "/storeanalytics")
                .addJSONObjectBody(jsonObject)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Do nothing
                    }

                    @Override
                    public void onError(ANError error) {
                        error.printStackTrace();
                    }
                });

        checkExistingAppDataFromAdminPanelAndSetData(SplashScreen.this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1009) {
            goToMainAndFinish();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        newBase = LocaleHelper.onAttach(newBase);
        super.attachBaseContext(newBase);
    }
}