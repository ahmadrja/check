/*
 * *
 * * Updated for com.infusiblecoder.allinonevideodownloader
 * * Optimized for Super-Lite (Option 1)
 * *
 */

package com.infusiblecoder.allinonevideodownloader.utils.work

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.work.WorkManager
import com.infusiblecoder.allinonevideodownloader.R

class CancelReceiver : BroadcastReceiver() {
    private val TAG = "CancelReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "Task Canceler called")
        try {
            if (context == null || intent == null) return

            val taskId = intent.getStringExtra("taskId")
            val notificationId = intent.getIntExtra("notificationId", 0)

            if (!taskId.isNullOrEmpty()) {
                // YoutubeDL delete hone ki wajah se sirf WorkManager tasks cancel honge
                WorkManager.getInstance(context).cancelAllWorkByTag(taskId)

                Log.d(TAG, "Task (id:$taskId) was cancelled.")

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?
                notificationManager?.cancel(notificationId)

                // User ko notification dene ke liye
                Toast.makeText(context, context.getString(R.string.taskcancel), Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in CancelReceiver: ${e.message}")
        }
    }
}