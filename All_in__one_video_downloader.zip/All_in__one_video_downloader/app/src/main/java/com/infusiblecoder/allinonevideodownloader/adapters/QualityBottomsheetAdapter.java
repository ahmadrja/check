/*
 * *
 * * Created by Syed Usama Ahmad on 3/23/25
 * * Copyright (c) 2025 . All rights reserved.
 * * Fixed for Lite App (Removed YoutubeDL dependencies)
 *
 */

package com.infusiblecoder.allinonevideodownloader.adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;

import com.infusiblecoder.allinonevideodownloader.R;
import com.infusiblecoder.allinonevideodownloader.models.dlapismodels.Format;
import com.infusiblecoder.allinonevideodownloader.models.dlapismodels.Video;
import com.infusiblecoder.allinonevideodownloader.utils.DownloadFileMain;
import com.infusiblecoder.allinonevideodownloader.utils.iUtils;
import com.infusiblecoder.allinonevideodownloader.utils.work.DownloadWorker;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QualityBottomsheetAdapter extends RecyclerView.Adapter<QualityBottomsheetAdapter.ViewHolder> {

    private final String vidSource;
    boolean isDLAPI = false;
    boolean issingle;
    boolean hasMultiAlbumb = false;
    private boolean isAudio = false;
    private String url, title, id;
    private Activity context;
    private Activity activity;
    private List<Format> filesList;
    private List<Video> filesVideoList;
    private List<VideoFormat> videoFormatList;
    private String vidurl;

    public QualityBottomsheetAdapter(Activity context, List<Format> filesList, String source, boolean issingle) {
        this.context = context;
        this.filesList = addtoarrayno_m3u8(filesList);
        this.issingle = issingle;
        this.vidSource = source;
    }

    public QualityBottomsheetAdapter(Activity context, String source, boolean issingle, List<Video> filesList, boolean hasMultiAlbumb) {
        this.context = context;
        this.filesVideoList = filesList;
        this.issingle = issingle;
        this.hasMultiAlbumb = hasMultiAlbumb;
        this.vidSource = source;

        removeRepeatedVideos();
    }

    public QualityBottomsheetAdapter(Activity context, String url, String source, boolean issingle) {
        this.context = context;
        this.vidurl = url;
        this.issingle = issingle;
        this.vidSource = source;
    }

    public QualityBottomsheetAdapter(Activity activity, String source, boolean issingle, List<VideoFormat> videoList_sub_video, boolean isDLAPI, String title, String id, String url, boolean isAudio) {
        this.activity = activity;
        this.videoFormatList = videoList_sub_video;
        this.issingle = issingle;
        this.vidSource = source;
        this.isDLAPI = isDLAPI;
        this.url = url;
        this.title = title;
        this.id = id;
        this.isAudio = isAudio;

        if (!isAudio) {
            removeRepeatedFormates();
        }
    }

    public static String extractQuality(String format) {
        Pattern parenthesesPattern = Pattern.compile("\\((\\d+p)\\)");
        Matcher parenthesesMatcher = parenthesesPattern.matcher(format);

        if (parenthesesMatcher.find()) {
            return parenthesesMatcher.group(1);
        }

        Pattern resolutionPattern = Pattern.compile("(\\d+)x\\d+");
        Matcher resolutionMatcher = resolutionPattern.matcher(format);

        if (resolutionMatcher.find()) {
            return resolutionMatcher.group(1) + "p";
        }

        return "unknown";
    }

    @NonNull
    @Override
    public QualityBottomsheetAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_quality_bottomfragment, parent, false);
        return new ViewHolder(view);
    }

    private int getMediaTypeIconResId(Object media) {
        if (media instanceof Video) {
            Video video = (Video) media;
            if (video.getURL() != null && video.getURL().contains("http") &&
                    !video.getURL().contains(".m3u8")) {
                if (video.getEXT().equals("m4a") ||
                        video.getEXT().equals("mp3") ||
                        video.getEXT().equals("wav")) {
                    return R.drawable.music_player;
                } else if (video.getEXT().equals("mp4") || video.getEXT().equals("mpeg")) {
                    return R.drawable.video_camera;
                }
            }
        } else if (media instanceof Format) {
            Format format = (Format) media;
            if (format.getURL() != null && format.getURL().contains("http") &&
                    !format.getURL().contains(".m3u8")) {
                if ((format.getAcodec() != null && !format.getAcodec().equals("none")) ||
                        format.getEXT().equals("m4a") ||
                        format.getEXT().equals("mp3") ||
                        format.getEXT().equals("wav")) {
                    return R.drawable.music_player;
                } else if (format.getEXT().equals("mp4") ||
                        format.getEXT().equals("unknown_video") ||
                        format.getEXT().equals("mpeg")) {
                    return R.drawable.video_camera;
                }
            }
        } else if (media instanceof VideoFormat) {
            VideoFormat videoFormat = (VideoFormat) media;
            if (videoFormat.getUrl() != null && videoFormat.getUrl().contains("http") &&
                    !videoFormat.getUrl().contains(".m3u8")) {
                if ((videoFormat.getAcodec() != null && !videoFormat.getAcodec().equals("none")) ||
                        videoFormat.getExt() != null && (
                                videoFormat.getExt().equals("m4a") ||
                                        videoFormat.getExt().equals("mp3") ||
                                        videoFormat.getExt().equals("wav"))) {
                    return R.drawable.music_player;
                } else if (videoFormat.getExt() != null && (
                        videoFormat.getExt().equals("mp4") ||
                                videoFormat.getExt().equals("unknown_video") ||
                                videoFormat.getExt().equals("mpeg"))) {
                    return R.drawable.video_camera;
                }
            }
        }
        return R.drawable.video_camera;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NotNull QualityBottomsheetAdapter.ViewHolder holder, final int position) {
        String resolution = "none";
        if (isDLAPI) {

            final VideoFormat videoFormatFiles = videoFormatList.get(position);
            System.out.println("reccccc VVKK working1111 06 " + videoFormatFiles.getFormat() + " >>>>> " + videoFormatFiles.getFormatId());
            holder.typeicon.setImageResource(getMediaTypeIconResId(videoFormatFiles));


            if (videoFormatFiles.getFormat().length() > 20 && videoFormatFiles.getFormatNote() != null) {
                if (videoFormatFiles.getFormat().contains("-")) {
                    String[] ccc = videoFormatFiles.getFormat().split("-");
                    resolution = (ccc.length > 2) ? ccc[2] : ccc[1];
                } else {
                    resolution = videoFormatFiles.getFormatNote();
                }

            } else {
                resolution = videoFormatFiles.getFormat();
            }

            String finalResolution = resolution;

            holder.resolution.setText(String.format("%s", resolution));
            holder.resolution.setSelected(true);
            holder.resolution.setSingleLine(true);

            String formatedsizew = "", newformatedsizew = "";
            newformatedsizew = iUtils.getStringSizeLengthFile(videoFormatFiles.getFileSize());
            if (newformatedsizew.contains("0.00")) {
                formatedsizew = iUtils.getStringSizeLengthFile(videoFormatFiles.getFileSizeApproximate());
            } else {
                formatedsizew = newformatedsizew;
            }
            formatedsizew = formatedsizew.replace(",", ".");
            holder.fileSize.setText(!formatedsizew.equals("") ? formatedsizew + "" : "undefined");
            holder.downloadbtnd.setOnClickListener(v -> {

                Data workData = new Data.Builder()
                        .putString(DownloadWorker.urlKey, url)
                        .putString(DownloadWorker.nameKey, title + finalResolution)
                        .putString(DownloadWorker.formatIdKey, videoFormatFiles.getFormatId())
                        .putString(DownloadWorker.acodecKey, videoFormatFiles.getAcodec())
                        .putString(DownloadWorker.vcodecKey, videoFormatFiles.getVcodec())
                        .putString(DownloadWorker.taskIdKey, id + "_" + finalResolution)
                        .putString(DownloadWorker.ext, videoFormatFiles.getExt())
                        .build();

                WorkRequest workRequest = new OneTimeWorkRequest.Builder(DownloadWorker.class)
                        .addTag(id)
                        .setInputData(workData)
                        .build();

                WorkManager.getInstance(activity).enqueueUniqueWork(
                        id,
                        ExistingWorkPolicy.KEEP,
                        (OneTimeWorkRequest) workRequest
                );

                activity.runOnUiThread(() -> iUtils.ShowToast(activity, activity.getResources().getString(R.string.don_start)));

            });

        } else {
            if (issingle) {
                System.out.println("reccccc VVKK working0000 ");
                holder.resolution.setText("HD");
                holder.fileSize.setText("undefined");
                holder.downloadbtnd.setOnClickListener(v -> DownloadFileMain.startDownloading(context, vidurl, vidSource + "_" + System.currentTimeMillis(), ".mp4"));
            } else {
                if (hasMultiAlbumb) {
                    final Video files = filesVideoList.get(position);
                    holder.typeicon.setImageResource(getMediaTypeIconResId(files));
                    if (!files.getURL().contains(".m3u8") && files.getProtocol().contains("http")) {

                        String finalResolution = extractQuality(String.format("%s", files.getFormat().length() > 20 && files.getFormatID() != null ? files.getFormatID() : files.getFormat()));
                        holder.resolution.setText(finalResolution);
                        String formatedsizew = "NaN";
                        holder.fileSize.setText(formatedsizew);

                        holder.downloadbtnd
                                .setOnClickListener(
                                        v -> {
                                            if (files.getEXT().equals("com") || files.getEXT().equals("")) {
                                                DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + files.getTitle(), ".mp4");
                                            } else if (files.getEXT().equals("gif")) {
                                                DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + files.getTitle(), "." + files.getEXT());
                                            } else {
                                                DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + files.getTitle(), "." + files.getEXT());
                                            }
                                        });
                    }

                } else {
                    final Format files = filesList.get(position);
                    System.out.println("reccccc VVKK working1111 06 " + files.getFormat() + files.getProtocol());

                    holder.typeicon.setImageResource(getMediaTypeIconResId(files));
                    if (!files.getURL().contains(".m3u8") && files.getProtocol().contains("http")) {

                        String finalResolution = extractQuality(String.format("%s", files.getFormat().length() > 20 && files.getFormatNote() != null ? files.getFormatNote() : files.getFormat()));
                        holder.resolution.setText(finalResolution);

                        String formatedsizew = iUtils.getStringSizeLengthFile(files.getFilesize());
                        formatedsizew = formatedsizew.replace(",", ".");
                        holder.fileSize.setText(!formatedsizew.equals("") ? formatedsizew + "" : "undefined");
                        holder.downloadbtnd.setOnClickListener(v -> {
                            if (files.getEXT().equals("com") || files.getEXT().equals("")) {
                                DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + System.currentTimeMillis(), ".mp4");
                            } else if (files.getEXT().equals("gif")) {
                                DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + System.currentTimeMillis(), "." + files.getEXT());
                            } else {
                                DownloadFileMain.startDownloading(context, files.getURL(), vidSource + "_" + System.currentTimeMillis(), "." + files.getEXT());
                            }
                        });
                    }
                }
            }
        }
    }

    String formet_size(long bytes) {
        System.out.println("fhsdjfsdjfsfsdfk addd long=" + bytes);
        try {
            if (bytes < 1024) {
                return bytes + "B";
            } else if (bytes < 1048576L) {
                return Math.round(bytes / 1024) + "KB";
            } else if (bytes < 1073741824) {
                return Math.round(bytes / 1048576) + "MB";
            } else if (bytes > 1073741824) {
                System.out.println("fhsdjfsdjfsfsdfk addd long=" + bytes);
                return Math.round(bytes / 1073741824) + "GB";
            }
        } catch (Exception e) {
            System.out.println("fhsdjfsdjfsfsdfk addd long eee=" + e.getMessage());
            return "NaN";
        }
        return "NaN";
    }

    @SuppressLint("NotifyDataSetChanged")
    void removeRepeatedVideos() {
        Map<String, Video> uniqueQualityVideos = new HashMap<>();

        for (Video video : filesVideoList) {
            String formatString = video.getFormat().length() > 20 && video.getFormatID() != null
                    ? video.getFormatID()
                    : video.getFormat();

            String quality = extractQuality(formatString);
            System.out.println("reccccc extractQuality " + quality);
            if (!uniqueQualityVideos.containsKey(quality)) {
                uniqueQualityVideos.put(quality, video);
            }
        }

        filesVideoList.clear();
        filesVideoList.addAll(uniqueQualityVideos.values());

        filesVideoList.sort((video1, video2) -> {
            String formatString1 = video1.getFormat().length() > 20 && video1.getFormatID() != null
                    ? video1.getFormatID()
                    : video1.getFormat();
            String formatString2 = video2.getFormat().length() > 20 && video2.getFormatID() != null
                    ? video2.getFormatID()
                    : video2.getFormat();

            String quality1 = extractQuality(formatString1);
            String quality2 = extractQuality(formatString2);

            int qualityValue1 = parseQualityValue(quality1);
            int qualityValue2 = parseQualityValue(quality2);

            return Integer.compare(qualityValue2, qualityValue1);
        });

        notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    void removeRepeatedFormates() {
        Map<String, VideoFormat> uniqueQualityFormats = new HashMap<>();

        for (VideoFormat format : videoFormatList) {
            String formatString = format.getFormat().length() > 20 && format.getFormatNote() != null
                    ? format.getFormatNote()
                    : format.getFormat();

            String quality = extractQuality(formatString);
            System.out.println("reccccc extractQuality " + quality);
            if (!uniqueQualityFormats.containsKey(quality)) {
                uniqueQualityFormats.put(quality, format);
            }
        }

        videoFormatList.clear();
        videoFormatList.addAll(uniqueQualityFormats.values());

        videoFormatList.sort((format1, format2) -> {
            String quality1 = extractQuality(format1.getFormat());
            String quality2 = extractQuality(format2.getFormat());

            int qualityValue1 = parseQualityValue(quality1);
            int qualityValue2 = parseQualityValue(quality2);

            return Integer.compare(qualityValue2, qualityValue1);
        });

        notifyDataSetChanged();
    }

    private int parseQualityValue(String quality) {
        try {
            if (quality != null && quality.contains("p")) {
                return Integer.parseInt(quality.substring(0, quality.indexOf("p")));
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public int getItemCount() {
        if (isDLAPI) {
            return videoFormatList.size();
        }
        if (hasMultiAlbumb) {
            return filesVideoList.size();
        }
        return issingle ? 1 : filesList.size();
    }

    List<Format> addtoarrayno_m3u8(List<Format> fromList) {
        if (fromList != null) {
            List<Format> toList = new ArrayList<>();
            for (int i = 0; i < fromList.size(); i++) {
                System.out.println("fhsdjfsdjfk " + fromList.get(i).getURL());
                if (!fromList.get(i).getURL().contains(".m3u8")) {
                    System.out.println("fhsdjfsdjfk addd" + fromList.get(i).getURL());
                    toList.add(fromList.get(i));
                }
            }
            return toList;
        }
        return new ArrayList<>();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView resolution;
        TextView fileSize;
        ImageView downloadbtnd, typeicon;

        public ViewHolder(View itemView) {
            super(itemView);
            resolution = itemView.findViewById(R.id.resolution);
            typeicon = itemView.findViewById(R.id.typeicon);
            fileSize = itemView.findViewById(R.id.file_size);
            downloadbtnd = itemView.findViewById(R.id.download_button);
        }
    }
}

// 🚀 DUMMY CLASS ADDED HERE TO FIX "Cannot find symbol class VideoFormat" 🚀
// यह क्लास YoutubeDL के VideoFormat को रिप्लेस करेगी ताकि कोड में एरर ना आये।
class VideoFormat {
    private String format = "";
    private String formatId = "";
    private String formatNote = "";
    private long fileSize = 0L;
    private long fileSizeApproximate = 0L;
    private String acodec = "";
    private String vcodec = "";
    private String ext = "";
    private String url = "";

    public String getFormat() { return format; }
    public String getFormatId() { return formatId; }
    public String getFormatNote() { return formatNote; }
    public long getFileSize() { return fileSize; }
    public long getFileSizeApproximate() { return fileSizeApproximate; }
    public String getAcodec() { return acodec; }
    public String getVcodec() { return vcodec; }
    public String getExt() { return ext; }
    public String getUrl() { return url; }
}