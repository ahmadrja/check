package com.allvideodown.socialdownloader.onboarding

import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.activities.MainActivity
import com.allvideodown.socialdownloader.activities.newUi.MainActivityNewUi
import com.allvideodown.socialdownloader.databinding.ActivityOnboardingBinding
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp
import com.allvideodown.socialdownloader.utils.iUtils
import com.libs.jaeger.StatusBarUtil
import com.permissionx.guolindev.PermissionX

class OnboardingActivity : AppCompatActivity() {

    private val requiredPermissions = arrayOf(
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
    )

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val requiredPermissionsTIRAMISU = arrayOf(
        android.Manifest.permission.READ_MEDIA_IMAGES,
        android.Manifest.permission.READ_MEDIA_VIDEO,
        android.Manifest.permission.READ_MEDIA_AUDIO
    )

    private lateinit var mViewPager: ViewPager2
    private lateinit var textEnd: TextView
    private lateinit var textAllowPermission: TextView
    private lateinit var btnNextStep: ImageButton

    private lateinit var binding: ActivityOnboardingBinding
    private var curPosition = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mViewPager = binding.viewPager
        textEnd = binding.textEnd
        textAllowPermission = binding.textAllowPermission
        btnNextStep = binding.btnNextStep

        mViewPager.adapter = OnboardingViewPagerAdapter(this, this)
        mViewPager.offscreenPageLimit = 1
        TabLayoutMediator(binding.pageIndicator, mViewPager) { _, _ -> }.attach()

        disableTabLayoutClicks(binding.pageIndicator)
        mViewPager.isUserInputEnabled = false

        mViewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                curPosition = position
                updateUIForPosition(position)
            }
        })

        StatusBarUtil.setTranslucentForImageViewInFragment(this, null)

        textEnd.setOnClickListener {
            if (checkAllPermissionsGranted()) {
                SharedPrefsMainApp(this@OnboardingActivity).preferencE_isFirstTime = false
                goToMain()
            } else {
                showPermissionRequiredDialog()
            }
        }

        btnNextStep.setOnClickListener {
            if (curPosition in 0..3) {
                moveToNextPage()
            }
        }

        textAllowPermission.setOnClickListener {
            when (curPosition) {
                1 -> askForStoragePermission()
                2 -> askForNotificationPermission()
            }
        }
    }

    private fun checkAllPermissionsGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }
        } else {
            requiredPermissions.all { isPermissionGranted(it) }
        }
    }

    private fun showPermissionRequiredDialog() {
        when (curPosition) {
            1 -> askForStoragePermission()
            2 -> askForNotificationPermission()
        }
    }

    private fun disableTabLayoutClicks(tabLayout: TabLayout) {
        for (i in 0 until tabLayout.tabCount) {
            val tabView = (tabLayout.getChildAt(0) as ViewGroup).getChildAt(i)
            tabView.isClickable = false
            tabView.isFocusable = false
        }
    }

    private fun updateUIForPosition(position: Int) {
        textAllowPermission.visibility = if (position in 1..2) View.VISIBLE else View.GONE
        btnNextStep.visibility = if (position == 0) View.VISIBLE else View.GONE
        textEnd.visibility = if (position == 3) View.VISIBLE else View.GONE
    }

    private fun moveToNextPage() {
        if (!checkRequiredPermissionsForCurrentPage()) {
            showPermissionRequiredDialog()
        } else {
            val nextItem = getItem() + 1
            if (nextItem < (mViewPager.adapter?.itemCount ?: 0)) {
                mViewPager.setCurrentItem(nextItem, true)
            } else {
                goToMain()
            }
        }
    }

    private fun checkRequiredPermissionsForCurrentPage(): Boolean {
        return when (curPosition) {
            1 -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }
            } else {
                requiredPermissions.all { isPermissionGranted(it) }
            }

            2 -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val manager = getSystemService(NotificationManager::class.java)
                manager.areNotificationsEnabled()
            } else {
                true
            }

            else -> true
        }
    }

    private fun goToMain() {
        if (!checkAllPermissionsGranted()) {
            showPermissionRequiredDialog()
            return
        }

        val intent = if (iUtils.isNewUi) {
            Intent(this, MainActivityNewUi::class.java)
        } else {
            Intent(this, MainActivity::class.java)
        }
        startActivity(intent)
        finish()
    }

    private fun getItem(): Int {
        return mViewPager.currentItem
    }

    private fun isPermissionGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun showStoragePermissionRationale() {
        val permissionsToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requiredPermissionsTIRAMISU
        } else {
            requiredPermissions
        }

        PermissionX.init(this)
            .permissions(*permissionsToRequest)
            .request { allGranted, _, de ->
                if (allGranted) {
                    moveToNextPage()
                } else {
                    showSettingsAlertDialog(de)
                }
            }
    }


    private fun showSettingsAlertDialog(deniedList: List<String>) {
        val message = if (deniedList.isNotEmpty()) {
            getString(R.string.permissions_denied_with_list, deniedList.joinToString(", "))
        } else {
            getString(R.string.permissions_denied_generic)
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.permissions_required_title)
            .setMessage(message)
            .setPositiveButton(R.string.go_to_settings) { dialog, _ ->
                dialog.dismiss()
                openAppSettings()
            }
            .show()
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }


    private fun askForStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val allPermissionsGranted = requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }
            if (allPermissionsGranted) {
                moveToNextPage()
            } else {
                showStoragePermissionRationale()
            }
        } else {
            val allPermissionsGranted = requiredPermissions.all { isPermissionGranted(it) }
            if (allPermissionsGranted) {
                moveToNextPage()
            } else {
                showStoragePermissionRationale()
            }
        }
    }

    private fun askForNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val manager = getSystemService(NotificationManager::class.java)
            if (!manager.areNotificationsEnabled()) {
                showNotificationPermissionRationale()
            } else {
                moveToNextPage()
            }
        } else {
            moveToNextPage()
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                moveToNextPage()
            } else {
                showNotificationPermissionRationale()
            }
        }


    private fun showNotificationPermissionRationale() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PermissionX.init(this)
                .permissions(android.Manifest.permission.POST_NOTIFICATIONS)
                .request { allGranted, _, de ->
                    if (allGranted) {
                        moveToNextPage()
                    } else {
                        showSettingsAlertDialog(de)
                    }
                }
        } else {
            moveToNextPage()
        }

    }


}