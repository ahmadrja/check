/*
 * *
 * * Created by Syed Usama Ahmad
 * * Master Updated with Auto Layout Sanitizer (Crash Shield)
 *
 */
@file:OptIn(DelicateCoroutinesApi::class)

package com.allvideodown.socialdownloader.utils

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.allvideodown.socialdownloader.BuildConfig
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.adapters.AdapterBannerAdsSliderRecyclerView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.libs.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType
import com.libs.smarteist.autoimageslider.SliderAnimations
import com.libs.smarteist.autoimageslider.SliderView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Objects
import java.util.concurrent.atomic.AtomicBoolean

object AdsManager {
    @JvmField var NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION: Int = 150
    var NUMBER_OF_INTERSTISHAL_ADS_SHOWN: Int = 0

    private var NUMBER_OF_BANNER_ADS_PER_SESSION: Int = 150
    private var NUMBER_OF_BANNER_ADS_SHOWN: Int = 0

    @JvmField var videoapp_AdmobAppId: String? = null
    @JvmField var videoapp_AdmobBanner: String? = null
    @JvmField var videoapp_AdmobInterstitial: String? = null
    private var videoapp_AdmobRewardedInterstitial: String? = null
    @JvmField var videoapp_AdmobRewardVideoExtraFeatures: String? = null
    @JvmField var videoapp_AdmobRewardID: String? = null
    @JvmField var videoapp_AdmobNativeID: String? = null

    @JvmField var status_AdmobBanner: Boolean = true
    @JvmField var status_AdmobInterstitial: Boolean = true
    @JvmField var status_AdmobRewardID: Boolean = true
    @JvmField var status_AdmobNativeID: Boolean = true

    private var mInterstitialAd: InterstitialAd? = null
    var mRewardedAd: RewardedAd? = null
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null

    @JvmField
    var adView: AdView? = null

    private const val MIN_TIME_BETWEEN_ADS = 30000L
    private var lastAdRequestTime = 0L

    private var isNetworkAvailable = AtomicBoolean(false)
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    var retryCount = 0
    val maxRetries = 2
    private const val RETRY_DELAY_MS = 5000L

    private var isInterstitialAdLoading = AtomicBoolean(false)
    private var isRewardedAdLoading = AtomicBoolean(false)
    private var isNativeAdLoading = AtomicBoolean(false)
    private var isRewardedInterstitialAdLoading = AtomicBoolean(false)

    @JvmStatic
    fun initNetworkMonitoring(context: Context) {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { isNetworkAvailable.set(true) }
            override fun onLost(network: Network) { isNetworkAvailable.set(false) }
        }
        val networkRequest = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        connectivityManager.registerNetworkCallback(networkRequest, networkCallback!!)
        isNetworkAvailable.set(checkNetworkAvailability(context))
    }

    private fun checkNetworkAvailability(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities = connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        return capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    private fun canShowAd(): Boolean = isNetworkAvailable.get() && (System.currentTimeMillis() - lastAdRequestTime >= MIN_TIME_BETWEEN_ADS)

    @JvmStatic
    fun setDefaults(activity: Application) {
        if (videoapp_AdmobInterstitial.isNullOrEmpty()) {
            videoapp_AdmobNativeID = activity.resources.getString(R.string.AdmobNativeID)
            videoapp_AdmobRewardID = activity.resources.getString(R.string.AdmobRewardID)
            videoapp_AdmobRewardVideoExtraFeatures = activity.resources.getString(R.string.AdmobRewardID)
            videoapp_AdmobInterstitial = activity.resources.getString(R.string.AdmobInterstitial)
            videoapp_AdmobRewardedInterstitial = activity.resources.getString(R.string.AdmobRewardedInterstitial)
            videoapp_AdmobBanner = activity.resources.getString(R.string.AdmobBanner)
            videoapp_AdmobAppId = activity.resources.getString(R.string.AdmobAppId)
        }
    }

    // 🚨 THIS IS THE ULTIMATE SHIELD: It forces all ad XML layouts to follow strict rules, preventing any ClassCastExceptions!
    private fun sanitizeLayoutParams(view: View) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val child = view.getChildAt(i)
                try {
                    if (view is FrameLayout || view is androidx.cardview.widget.CardView) {
                        if (child.layoutParams !is FrameLayout.LayoutParams) {
                            child.layoutParams = FrameLayout.LayoutParams(child.layoutParams.width, child.layoutParams.height)
                        }
                    } else if (view is android.widget.RelativeLayout) {
                        if (child.layoutParams !is android.widget.RelativeLayout.LayoutParams) {
                            child.layoutParams = android.widget.RelativeLayout.LayoutParams(child.layoutParams.width, child.layoutParams.height)
                        }
                    } else if (view is android.widget.LinearLayout) {
                        if (child.layoutParams !is android.widget.LinearLayout.LayoutParams) {
                            child.layoutParams = android.widget.LinearLayout.LayoutParams(child.layoutParams.width, child.layoutParams.height)
                        }
                    }
                } catch (e: Exception) { e.printStackTrace() }
                sanitizeLayoutParams(child) // Check deeply nested views
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun loadAdmobNativeAd(context: Activity, frameLayout: FrameLayout) {
        if (!status_AdmobNativeID || !isNetworkAvailable.get() || isNativeAdLoading.get()) return
        isNativeAdLoading.set(true)
        try {
            val adLoader = AdLoader.Builder(context, videoapp_AdmobNativeID!!)
                .forNativeAd { nativeAd ->
                    val adView = context.layoutInflater.inflate(R.layout.layout_native_ads, null) as NativeAdView

                    // 🚨 RUNNING THE SHIELD: Fixes any bad code inside layout_native_ads.xml automatically
                    sanitizeLayoutParams(adView)

                    populateNativeAdView(nativeAd, adView)

                    GlobalScope.launch(Dispatchers.Main) {
                        try {
                            frameLayout.removeAllViews()
                            adView.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
                            frameLayout.addView(adView)
                            frameLayout.visibility = View.VISIBLE
                        } catch (e: Exception) { e.printStackTrace() }
                        isNativeAdLoading.set(false)
                    }
                }
                .withNativeAdOptions(NativeAdOptions.Builder().setVideoOptions(VideoOptions.Builder().setStartMuted(true).build()).build())
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        isNativeAdLoading.set(false)
                        if (retryCount < maxRetries) {
                            retryCount++
                            GlobalScope.launch(Dispatchers.Main) { delay(RETRY_DELAY_MS); loadAdmobNativeAd(context, frameLayout) }
                        } else {
                            retryCount = 0
                            GlobalScope.launch(Dispatchers.Main) { frameLayout.visibility = View.GONE; frameLayout.removeAllViews() }
                        }
                    }
                    override fun onAdLoaded() { retryCount = 0 }
                }).build()

            adLoader.loadAd(AdRequest.Builder().build())
        } catch (e: Exception) {
            isNativeAdLoading.set(false)
            GlobalScope.launch(Dispatchers.Main) { frameLayout.visibility = View.GONE; frameLayout.removeAllViews() }
        }
    }

    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        try {
            adView.mediaView = adView.findViewById(R.id.ad_media)
            adView.headlineView = adView.findViewById(R.id.ad_headline)
            adView.bodyView = adView.findViewById(R.id.ad_body)
            adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
            adView.iconView = adView.findViewById(R.id.ad_app_icon)

            (Objects.requireNonNull(adView.headlineView) as TextView).text = nativeAd.headline
            Objects.requireNonNull(adView.mediaView!!).mediaContent = Objects.requireNonNull(nativeAd.mediaContent)

            if (nativeAd.body == null) adView.bodyView!!.visibility = View.INVISIBLE
            else { adView.bodyView!!.visibility = View.VISIBLE; (adView.bodyView as TextView?)!!.text = nativeAd.body }

            if (nativeAd.callToAction == null) adView.callToActionView!!.visibility = View.INVISIBLE
            else { adView.callToActionView!!.visibility = View.VISIBLE; (adView.callToActionView as TextView?)!!.text = nativeAd.callToAction }

            if (nativeAd.icon == null) adView.iconView!!.visibility = View.GONE
            else { (adView.iconView as ImageView).setImageDrawable(nativeAd.icon!!.drawable); adView.iconView!!.visibility = View.VISIBLE }

            adView.setNativeAd(nativeAd)
        } catch (e: Exception) { }
    }

    @JvmStatic
    fun loadAdmobNativeAdAsync(context: Activity, frameLayout: FrameLayout) {
        GlobalScope.launch(Dispatchers.Main) { loadAdmobNativeAd(context, frameLayout) }
    }

    // --- BANNER AND INTERSTITIAL ADS BELOW (Clean & Safe) ---

    private suspend fun loadBannerAdsAdapter(context: Activity?, sliderView: SliderView) {
        withContext(Dispatchers.IO) {
            try {
                if (status_AdmobBanner && isNetworkAvailable.get()) {
                    val adapterBannerAdsRecyclerView = AdapterBannerAdsSliderRecyclerView(context!!)
                    withContext(Dispatchers.Main) {
                        sliderView.setSliderAdapter(adapterBannerAdsRecyclerView)
                        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM)
                        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION)
                        sliderView.startAutoCycle()
                        sliderView.visibility = View.VISIBLE
                    }
                } else {
                    withContext(Dispatchers.Main) { destroyAdview(); sliderView.visibility = View.GONE }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { destroyAdview(); sliderView.visibility = View.GONE }
            }
        }
    }

    fun loadBannerAdAdapter(activity: Activity?, sliderView: SliderView) {
        CoroutineScope(Dispatchers.Main).launch { loadBannerAdsAdapter(activity, sliderView) }
    }

    private suspend fun loadBannerAd(activity: Activity, adContainer: ViewGroup) {
        if (!canShowAd() || !status_AdmobBanner || !isNetworkAvailable.get() || NUMBER_OF_BANNER_ADS_SHOWN >= NUMBER_OF_BANNER_ADS_PER_SESSION) {
            withContext(Dispatchers.Main) { adContainer.visibility = View.GONE; adContainer.removeAllViews() }
            return
        }
        withContext(Dispatchers.Main) {
            try {
                NUMBER_OF_BANNER_ADS_SHOWN++
                lastAdRequestTime = System.currentTimeMillis()

                val localAdView = AdView(activity).apply {
                    setAdSize(AdSize.BANNER)
                    adUnitId = videoapp_AdmobBanner!!
                    adListener = object : AdListener() {
                        override fun onAdFailedToLoad(loadAdError: LoadAdError) { adContainer.visibility = View.GONE; adContainer.removeAllViews() }
                        override fun onAdLoaded() { adContainer.visibility = View.VISIBLE }
                    }
                }
                adView = localAdView

                // 🚨 CRASH FIX FOR BANNER CONTAINER 🚨
                if (adContainer is FrameLayout) {
                    localAdView.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
                }

                adContainer.removeAllViews()
                adContainer.addView(localAdView)
                localAdView.loadAd(AdRequest.Builder().build())

            } catch (e: Exception) {
                destroyAdview()
                adContainer.visibility = View.GONE
                adContainer.removeAllViews()
            }
        }
    }

    @JvmStatic
    fun loadBannerAdAsync(activity: Activity, adContainer: ViewGroup) {
        GlobalScope.launch(Dispatchers.Main) { loadBannerAd(activity, adContainer) }
    }

    @JvmStatic
    fun showAdmobInterstitialAd(context: Activity?, contentCallback: FullScreenContentCallback?, isFromCoins: Boolean = false) {
        if (context == null) return
        try {
            if (status_AdmobInterstitial && isNetworkAvailable.get() && NUMBER_OF_INTERSTISHAL_ADS_SHOWN < NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION) {
                val shouldShowAd = if (isFromCoins) true else iUtils.getRandomNumber(2) != 0
                if (shouldShowAd) {
                    mInterstitialAd?.let { ad ->
                        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                                contentCallback?.onAdDismissedFullScreenContent()
                                mInterstitialAd = null
                                CoroutineScope(Dispatchers.Main).launch { loadInterstitialAd(context) }
                            }
                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                super.onAdFailedToShowFullScreenContent(p0)
                                contentCallback?.onAdFailedToShowFullScreenContent(p0)
                                CoroutineScope(Dispatchers.Main).launch { loadInterstitialAd(context) }
                            }
                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                                contentCallback?.onAdShowedFullScreenContent()
                                NUMBER_OF_INTERSTISHAL_ADS_SHOWN++
                                lastAdRequestTime = System.currentTimeMillis()
                            }
                        }
                        ad.show(context)
                    } ?: run { CoroutineScope(Dispatchers.Main).launch { loadInterstitialAd(context) } }
                } else { CoroutineScope(Dispatchers.Main).launch { loadInterstitialAd(context) } }
            } else {
                if (status_AdmobInterstitial && isNetworkAvailable.get() && mInterstitialAd == null) {
                    CoroutineScope(Dispatchers.Main).launch { loadInterstitialAd(context) }
                }
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private suspend fun loadInterstitialAd(context: Activity) {
        if (!status_AdmobInterstitial || !isNetworkAvailable.get() || isInterstitialAdLoading.get() || NUMBER_OF_INTERSTISHAL_ADS_SHOWN >= NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION) return
        isInterstitialAdLoading.set(true)
        withContext(Dispatchers.Main) {
            try {
                InterstitialAd.load(context, videoapp_AdmobInterstitial!!, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) { mInterstitialAd = ad; isInterstitialAdLoading.set(false) }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        mInterstitialAd = null
                        isInterstitialAdLoading.set(false)
                        if (retryCount < maxRetries) {
                            retryCount++
                            CoroutineScope(Dispatchers.Main).launch { delay(RETRY_DELAY_MS); loadInterstitialAd(context) }
                        } else { retryCount = 0 }
                    }
                })
            } catch (e: Exception) { mInterstitialAd = null; isInterstitialAdLoading.set(false) }
        }
    }

    @JvmStatic
    fun loadInterstitialAdAsync(context: Activity) { GlobalScope.launch(Dispatchers.Main) { loadInterstitialAd(context) } }

    @JvmStatic
    fun loadVideoAdAdmobAsync(activity: Activity, fullScreenContentCallback: FullScreenContentCallback?) {
        GlobalScope.launch(Dispatchers.Main) { loadVideoAdAdmob(activity, fullScreenContentCallback) }
    }

    @JvmStatic
    fun loadVideoAdAdmob(activity: Activity, fullScreenContentCallback: FullScreenContentCallback?) {
        if (!status_AdmobRewardID || !isNetworkAvailable.get() || isRewardedAdLoading.get() || activity.isFinishing) return
        if (SharedPrefsMainApp(activity).preferencE_inappads == "nnn" && Constants.show_Ads && !BuildConfig.ISPRO) {
            isRewardedAdLoading.set(true)
            try {
                val rewardAdId = if (iUtils.getRandomNumber(2) == 0) videoapp_AdmobRewardID else videoapp_AdmobRewardVideoExtraFeatures
                RewardedAd.load(activity, rewardAdId!!, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        mRewardedAd = null
                        isRewardedAdLoading.set(false)
                        if (retryCount < maxRetries) {
                            retryCount++
                            CoroutineScope(Dispatchers.Main).launch { delay(RETRY_DELAY_MS); loadVideoAdAdmob(activity, fullScreenContentCallback) }
                        } else { retryCount = 0 }
                    }
                    override fun onAdLoaded(ad: RewardedAd) {
                        mRewardedAd = ad
                        isRewardedAdLoading.set(false)
                        retryCount = 0
                        mRewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                fullScreenContentCallback?.onAdDismissedFullScreenContent()
                                mRewardedAd = null
                                GlobalScope.launch(Dispatchers.Main) { loadVideoAdAdmob(activity, null) }
                            }
                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                fullScreenContentCallback?.onAdFailedToShowFullScreenContent(p0)
                                GlobalScope.launch(Dispatchers.Main) { loadVideoAdAdmob(activity, null) }
                            }
                            override fun onAdShowedFullScreenContent() { fullScreenContentCallback?.onAdShowedFullScreenContent() }
                        }
                    }
                })
            } catch (e: Exception) { mRewardedAd = null; isRewardedAdLoading.set(false) }
        }
    }

    @JvmStatic
    fun showVideoAdAdmobAsync(activity: Activity, onUserEarnedRewardListener: OnUserEarnedRewardListener?, isFromCoins: Boolean = false) {
        GlobalScope.launch(Dispatchers.Main) { showVideoAdAdmob(activity, onUserEarnedRewardListener, isFromCoins) }
    }

    @JvmStatic
    suspend fun showVideoAdAdmob(activity: Activity, onUserEarnedRewardListener: OnUserEarnedRewardListener?, isFromCoins: Boolean = false) {
        if (!status_AdmobRewardID || !isNetworkAvailable.get() || activity.isFinishing) return
        if (SharedPrefsMainApp(activity).preferencE_inappads == "nnn" && Constants.show_Ads && !BuildConfig.ISPRO) {
            val randomNumber = if (isFromCoins) 2 else iUtils.getRandomNumber(4)
            if (randomNumber == 2) {
                if (mRewardedAd != null) {
                    withContext(Dispatchers.Main) {
                        mRewardedAd?.show(activity, onUserEarnedRewardListener!!)
                        mRewardedAd = null
                        loadVideoAdAdmob(activity, null)
                    }
                } else { loadVideoAdAdmob(activity, null) }
            } else { loadVideoAdAdmob(activity, null) }
        }
    }

    @JvmStatic
    fun destroyAdview() { try { adView?.destroy() } catch (e: Exception) {} }

    @JvmStatic
    fun cleanup(context: Context) {
        try {
            networkCallback?.let {
                val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                connectivityManager.unregisterNetworkCallback(it)
                networkCallback = null
            }
            destroyAdview()
            mInterstitialAd = null
            mRewardedAd = null
            rewardedInterstitialAd = null
        } catch (e: Exception) { }
    }
}