package com.allvideodown.socialdownloader.models.bulkdownloader;

import androidx.annotation.Keep;

@Keep
public class EdgeMediaPreviewLike {
    int count;

    public int getCount() {
        return this.count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
