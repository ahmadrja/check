package com.allvideodown.socialdownloader.models.dlapismodels.mapper;


import androidx.annotation.Keep;

@Keep
public class VideoSubtitle {
}

