/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2010-2014 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * http://glassfish.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 *
 */
/*
 *
 * This file incorporates work covered by the following copyright and
 * permission notice:
 *
 * Copyright 2010 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.allvideodown.socialdownloader.utils;

public final class AES_Base64 {
    static final int[] base64;
    private static final int TWENTYFOURBITGROUP = 24;
    private static final int EIGHTBIT = 8;
    private static final int SIXTEENBIT = 16;
    private static final int FOURBYTE = 4;
    private static final int SIGN = -128;
    private static final byte PAD = 61;
    private static final int BASELENGTH = 256;
    private static final int LOOKUPLENGTH = 64;
    private static byte[] base64Alphabet = new byte[BASELENGTH];
    private static byte[] lookUpBase64Alphabet = new byte[LOOKUPLENGTH];

    static {
        for (int i = 0; i < BASELENGTH; i++) {
            base64Alphabet[i] = -1;
        }
        for (int i2 = 90; i2 >= 65; i2--) {
            base64Alphabet[i2] = (byte) (i2 - 65);
        }
        for (int i3 = 122; i3 >= 97; i3--) {
            base64Alphabet[i3] = (byte) ((i3 - 97) + 26);
        }
        for (int i4 = 57; i4 >= 48; i4--) {
            base64Alphabet[i4] = (byte) ((i4 - 48) + 52);
        }
        base64Alphabet[43] = 62;
        base64Alphabet[47] = 63;
        for (int i5 = 0; i5 <= 25; i5++) {
            lookUpBase64Alphabet[i5] = (byte) (65 + i5);
        }
        int i6 = 26;
        int j = 0;
        while (i6 <= 51) {
            lookUpBase64Alphabet[i6] = (byte) (97 + j);
            i6++;
            j++;
        }
        int i7 = 52;
        int j2 = 0;
        while (i7 <= PAD) {
            lookUpBase64Alphabet[i7] = (byte) (48 + j2);
            i7++;
            j2++;
        }
        lookUpBase64Alphabet[62] = 43;
        lookUpBase64Alphabet[63] = 47;
        base64 = new int[]{LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, 62, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, PAD, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, 0, 1, 2, 3, 4, 5, 6, 7, EIGHTBIT, 9, 10, 11, 12, 13, 14, 15, SIXTEENBIT, 17, 18, 19, 20, 21, 22, 23, TWENTYFOURBITGROUP, 25, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH, LOOKUPLENGTH};
    }

    public static boolean isBase64(String isValidString) {
        return isArrayByteBase64(isValidString.getBytes());
    }

    public static boolean isBase64(byte octet) {
        return octet == PAD || base64Alphabet[(octet & 15) + (octet & 240)] != -1;
    }

    public static boolean isArrayByteBase64(byte[] arrayOctect) {
        int length = arrayOctect.length;
        if (length == 0) {
            return true;
        }
        for (byte b : arrayOctect) {
            if (!isBase64(b)) {
                return false;
            }
        }
        return true;
    }

    public static byte[] encode(byte[] binaryData) {
        byte[] encodedData;
        int lengthDataBits = binaryData.length * EIGHTBIT;
        int fewerThan24bits = lengthDataBits % TWENTYFOURBITGROUP;
        int numberTriplets = lengthDataBits / TWENTYFOURBITGROUP;
        if (fewerThan24bits != 0) {
            encodedData = new byte[(numberTriplets + 1) * 4];
        } else {
            encodedData = new byte[numberTriplets * 4];
        }
        int i = 0;
        while (i < numberTriplets) {
            int dataIndex = i * 3;
            byte b1 = binaryData[dataIndex];
            byte b2 = binaryData[dataIndex + 1];
            byte b3 = binaryData[dataIndex + 2];
            byte l = (byte) (b2 & 15);
            byte k = (byte) (b1 & 3);
            int encodedIndex = i * 4;
            byte val1 = (b1 & SIGN) == 0 ? (byte) (b1 >> 2) : (byte) ((b1 >> 2) ^ 192);
            byte val2 = (b2 & SIGN) == 0 ? (byte) (b2 >> 4) : (byte) ((b2 >> 4) ^ 240);
            byte val3 = (byte) ((b3 & SIGN) == 0 ? b3 >> 6 : (b3 >> 6) ^ 252);
            encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
            encodedData[encodedIndex + 1] = lookUpBase64Alphabet[val2 | (k << 4)];
            encodedData[encodedIndex + 2] = lookUpBase64Alphabet[(l << 2) | val3];
            encodedData[encodedIndex + 3] = lookUpBase64Alphabet[b3 & 63];
            i++;
        }
        int dataIndex2 = i * 3;
        int encodedIndex2 = i * 4;
        if (fewerThan24bits == EIGHTBIT) {
            byte b12 = binaryData[dataIndex2];
            byte k2 = (byte) (b12 & 3);
            byte val12 = (b12 & SIGN) == 0 ? (byte) (b12 >> 2) : (byte) ((b12 >> 2) ^ 192);
            encodedData[encodedIndex2] = lookUpBase64Alphabet[val12];
            encodedData[encodedIndex2 + 1] = lookUpBase64Alphabet[k2 << 4];
            encodedData[encodedIndex2 + 2] = PAD;
            encodedData[encodedIndex2 + 3] = PAD;
        } else if (fewerThan24bits == SIXTEENBIT) {
            byte b13 = binaryData[dataIndex2];
            byte b22 = binaryData[dataIndex2 + 1];
            byte l2 = (byte) (b22 & 15);
            byte k3 = (byte) (b13 & 3);
            byte val13 = (b13 & SIGN) == 0 ? (byte) (b13 >> 2) : (byte) ((b13 >> 2) ^ 192);
            byte val22 = (b22 & SIGN) == 0 ? (byte) (b22 >> 4) : (byte) ((b22 >> 4) ^ 240);
            encodedData[encodedIndex2] = lookUpBase64Alphabet[val13];
            encodedData[encodedIndex2 + 1] = lookUpBase64Alphabet[val22 | (k3 << 4)];
            encodedData[encodedIndex2 + 2] = lookUpBase64Alphabet[l2 << 2];
            encodedData[encodedIndex2 + 3] = PAD;
        }
        return encodedData;
    }

    public static byte[] decode(byte[] base64Data) {
        if (base64Data.length == 0) {
            return new byte[0];
        }
        int numberQuadruple = base64Data.length / 4;
        int encodedIndex = 0;
        int lastData = base64Data.length;
        while (base64Data[lastData - 1] == PAD) {
            lastData--;
            if (lastData == 0) {
                return new byte[0];
            }
        }
        byte[] decodedData = new byte[lastData - numberQuadruple];
        for (int i = 0; i < numberQuadruple; i++) {
            int dataIndex = i * 4;
            byte marker0 = base64Data[dataIndex + 2];
            byte marker1 = base64Data[dataIndex + 3];
            byte b1 = base64Alphabet[base64Data[dataIndex]];
            byte b2 = base64Alphabet[base64Data[dataIndex + 1]];
            if (marker0 != PAD && marker1 != PAD) {
                byte b3 = base64Alphabet[marker0];
                byte b4 = base64Alphabet[marker1];
                decodedData[encodedIndex] = (byte) ((b1 << 2) | (b2 >> 4));
                decodedData[encodedIndex + 1] = (byte) (((b2 & 15) << 4) | ((b3 >> 2) & 15));
                decodedData[encodedIndex + 2] = (byte) ((b3 << 6) | b4);
            } else if (marker0 == PAD) {
                decodedData[encodedIndex] = (byte) ((b1 << 2) | (b2 >> 4));
            } else if (marker1 == PAD) {
                byte b32 = base64Alphabet[marker0];
                decodedData[encodedIndex] = (byte) ((b1 << 2) | (b2 >> 4));
                decodedData[encodedIndex + 1] = (byte) (((b2 & 15) << 4) | ((b32 >> 2) & 15));
            }
            encodedIndex += 3;
        }
        return decodedData;
    }

    public static byte[] encode(String data) {
        return encode(data.getBytes());
    }

    public static byte[] decode(String data) {
        return decode(data.getBytes());
    }

    public static String base64Decode(String orig) {
        char[] chars = orig.toCharArray();
        StringBuilder sb = new StringBuilder();
        int shift = 0;
        int acc = 0;
        for (char c : chars) {
            int v = base64[c & 255];
            if (v < LOOKUPLENGTH) {
                acc = (acc << 6) | v;
                shift += 6;
                if (shift >= EIGHTBIT) {
                    shift -= 8;
                    sb.append((char) ((acc >> shift) & 255));
                }
            }
        }
        return sb.toString();
    }

}
