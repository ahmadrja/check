/*
 * *
 * * Created by Syed Usama Ahmad
 * * Master Final Update - Compilation Error Fixed & Crash Shield Active
 * * Copyright (c) 2023-2026 . All rights reserved.
 *
 */

@file:Suppress("DEPRECATION")

package com.allvideodown.socialdownloader.activities

import android.app.AlertDialog
import android.app.Dialog
import android.app.NotificationManager
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.Keep
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.allvideodown.socialdownloader.BuildConfig
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.activities.newUi.GalleryActivityNewUi
import com.allvideodown.socialdownloader.databinding.ActivityMainBinding
import com.allvideodown.socialdownloader.extraFeatures.ExtraFeaturesFragment
import com.allvideodown.socialdownloader.fragments.DownloadMainFragment
import com.allvideodown.socialdownloader.inappbilling.BillingClientSetup
import com.allvideodown.socialdownloader.models.adminpanel.Setting
import com.allvideodown.socialdownloader.snapchatstorysaver.SnapChatBulkStoryDownloader
import com.allvideodown.socialdownloader.statussaver.StatusSaverMainFragOld
import com.allvideodown.socialdownloader.statussaver.StatusSaverMainFragment
import com.allvideodown.socialdownloader.utils.AdsManager
import com.allvideodown.socialdownloader.utils.Constants
import com.allvideodown.socialdownloader.utils.LocaleHelper
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp
import com.allvideodown.socialdownloader.utils.iUtils
import com.allvideodown.socialdownloader.webservices.DownloadVideosMain
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.ump.ConsentForm
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.suddenh4x.ratingdialog.AppRating
import com.suddenh4x.ratingdialog.preferences.RatingThreshold
import java.util.concurrent.Executor
import kotlin.system.exitProcess

@Keep
class MainActivity : AppCompatActivity() {

    private var mBottomSheetDialog: BottomSheetDialog? = null
    private var nn: String? = "nnn"
    private var myString: String? = ""
    private val REQUEST_PERMISSION_CODE = 1001

    private val requiredPermissions = arrayOf(
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
        android.Manifest.permission.READ_EXTERNAL_STORAGE,
    )

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private val requiredPermissionsTIRAMISU = arrayOf(
        android.Manifest.permission.READ_MEDIA_IMAGES,
        android.Manifest.permission.READ_MEDIA_VIDEO,
        android.Manifest.permission.READ_MEDIA_AUDIO
    )

    private lateinit var progressDralogGenaratinglink: ProgressDialog
    private val APP_UPDATE_REQUEST_CODE = 261
    private var billingClient: BillingClient? = null

    var fragment: Fragment? = null
    private lateinit var binding: ActivityMainBinding
    private var biometricPrompt: BiometricPrompt? = null
    private var promptInfo: BiometricPrompt.PromptInfo? = null
    private lateinit var requestPermissionsLauncher: ActivityResultLauncher<Array<String>>
    private var hasNotificationPermissionGranted = false

    private lateinit var consentInformation: ConsentInformation
    private lateinit var consentForm: ConsentForm

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            val view = binding.root
            view.keepScreenOn = true
            enableEdgeToEdge()
            setContentView(view)

            // 🚨 CRASH SHIELD: Automatically fix any XML Layout conflicts in the background
            forceFixLayoutBugs()

        } catch (e: Throwable) {
            e.printStackTrace()
            finish()
            return
        }

        try {
            requestPermissionsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                if (SDK_INT >= 33 && requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }) {
                    val manager = getSystemService(NotificationManager::class.java)
                    if (!manager.areNotificationsEnabled()) {
                        showNotificationPermissionRationale()
                    }
                } else {
                    hasNotificationPermissionGranted = true
                }
                setLayout()
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (requiredPermissionsTIRAMISU.all { isPermissionGranted(it) }) {
                    val manager = getSystemService(NotificationManager::class.java)
                    if (!manager.areNotificationsEnabled()) {
                        showNotificationPermissionRationale()
                    }
                    setLayout()
                } else {
                    showStoragePermissionRationale()
                }
            } else {
                if (requiredPermissions.all { isPermissionGranted(it) }) {
                    setLayout()
                } else {
                    showStoragePermissionRationale()
                    runpermissioncheck()
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            progressDralogGenaratinglink = ProgressDialog(this@MainActivity)
            progressDralogGenaratinglink.setMessage(resources.getString(R.string.genarating_download_link))
            progressDralogGenaratinglink.setCancelable(false)

            if (Intent.ACTION_SEND == intent.action && intent.type != null) {
                if ("text/plain" == intent.type) {
                    SplashScreen.initDlLibs(this@MainActivity, false)
                    handleSendText(intent)
                }
            }

            if (SDK_INT > 27) {
                AppRating.Builder(this)
                    .setMinimumLaunchTimes(5)
                    .setMinimumDays(5)
                    .setRatingThreshold(RatingThreshold.FOUR)
                    .showIfMeetsConditions()
            }

            doAllBioMetricTasks()
            initIInAppBillingAcknologement()

            if (::binding.isInitialized) {
                if (!Constants.show_subscription) {
                    binding.subscriptionFab.visibility = View.GONE
                } else {
                    if (!BuildConfig.ISPRO) {
                        openAdsConsentDialog()
                        binding.subscriptionFab.visibility = View.VISIBLE
                        binding.subscriptionFab.setOnClickListener {
                            try {
                                if (iUtils.isSubactive) {
                                    runOnUiThread { iUtils.ShowToast(this@MainActivity, resources.getString(R.string.youhavealready)) }
                                } else {
                                    startActivity(Intent(this@MainActivity, SubscriptionActivity::class.java))
                                }
                            } catch (e: Exception) { e.printStackTrace() }
                        }
                    } else {
                        binding.subscriptionFab.visibility = View.GONE
                    }
                }

                if (Constants.show_Ads && !BuildConfig.ISPRO && AdsManager.status_AdmobBanner) {
                    val pp = SharedPrefsMainApp(this@MainActivity).preferencE_inappads
                    if (pp == "nnn") {
                        MobileAds.initialize(this@MainActivity) {
                            if (::binding.isInitialized) {
                                AdsManager.loadBannerAdAsync(this@MainActivity, binding.bannerContainer)
                            }
                        }
                    } else {
                        binding.bannerContainer.visibility = View.GONE
                    }
                } else {
                    binding.bannerContainer.visibility = View.GONE
                }
            }

        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    // 🚀 THE ULTIMATE SHIELD: This function intercepts bad XML layouts and corrects them instantly.
    private fun forceFixLayoutBugs() {
        try {
            val container = binding.bannerContainer
            val parent = container.parent

            if (parent is FrameLayout || parent is androidx.cardview.widget.CardView) {
                if (container.layoutParams !is FrameLayout.LayoutParams) {
                    val lp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
                    lp.gravity = android.view.Gravity.CENTER
                    container.layoutParams = lp
                }
            } else if (parent is android.widget.RelativeLayout) {
                if (container.layoutParams !is android.widget.RelativeLayout.LayoutParams) {
                    val lp = android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.MATCH_PARENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT)
                    lp.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT)
                    container.layoutParams = lp
                }
            }
        } catch (e: Exception) {
            // Ignored, fallback if views are missing
        }
    }

    private fun openAdsConsentDialog() {
        val params = ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build()
        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        consentInformation.requestConsentInfoUpdate(this, params, {
            if (consentInformation.isConsentFormAvailable) loadForm()
        }, { })
    }

    private fun runpermissioncheck() {
        try {
            if (!BuildConfig.DEBUG) verifyAppInstall(iUtils.verifyInstallerId(this@MainActivity))
        } catch (e: Throwable) { e.printStackTrace() }
    }

    private fun loadForm() {
        UserMessagingPlatform.loadConsentForm(this, {
            this.consentForm = it
            if (consentInformation.consentStatus == ConsentInformation.ConsentStatus.REQUIRED) {
                consentForm.show(this) { loadForm() }
            }
        }, { })
    }

    private fun doAllBioMetricTasks() {
        try {
            val biometricManager: BiometricManager = BiometricManager.from(this@MainActivity)
            when (biometricManager.canAuthenticate()) {
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE,
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE,
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                    getSharedPreferences("whatsapp_pref", MODE_PRIVATE).edit().putBoolean("isBio", false).apply()
                }
            }

            val executor: Executor = ContextCompat.getMainExecutor(this@MainActivity)
            biometricPrompt = BiometricPrompt(this@MainActivity, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    runOnUiThread { iUtils.ShowToastError(this@MainActivity, "Error in Authentication $errString") }
                }
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    startActivity(Intent(this@MainActivity, GalleryActivity::class.java))
                }
            })

            promptInfo = BiometricPrompt.PromptInfo.Builder().setTitle("Verify Identity")
                .setDescription("Use your fingerprint or device credentials to Access Gallery")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build()

            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (!isFinishing) showBottomSheetExitDialog()
                }
            })

        } catch (e: Throwable) { e.printStackTrace() }
    }

    private fun getBinding(): ActivityMainBinding? {
        return if (::binding.isInitialized) binding else null
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        hasNotificationPermissionGranted = isGranted
        if (!isGranted && SDK_INT >= 33) showNotificationPermissionRationale()
    }

    private fun showNotificationPermissionRationale() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermissionGranted && !isFinishing) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(getString(R.string.alert))
                .setMessage(getString(R.string.notificationpermission))
                .setPositiveButton(R.string.yes) { _, _ -> notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS) }
                .setNegativeButton(getString(R.string.cancel), null).show()
        } else {
            hasNotificationPermissionGranted = true
        }
    }

    private fun showStoragePermissionRationale() {
        if (!isFinishing) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(getString(R.string.alert))
                .setMessage(getString(R.string.write_neesory))
                .setPositiveButton(R.string.yes) { _, _ ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) requestPermissionsLauncher.launch(requiredPermissionsTIRAMISU)
                    else requestPermissionsLauncher.launch(requiredPermissions)
                }
                .setNegativeButton(getString(R.string.cancel), null).show()
        }
    }

    fun getMyData(): String? = myString
    fun setmydata(mysa: String) { this.myString = mysa }

    private fun verifyAppInstall(isinatll: Boolean) {
        if (!isinatll && !isFinishing) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(getString(R.string.please_install)).setCancelable(false)
                .setMessage(getString(R.string.isappfromplaystore))
                .setPositiveButton(resources.getString(R.string.installapp)) { d, _ ->
                    d.dismiss()
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
                }.setNegativeButton(resources.getString(R.string.useanyway)) { d, _ -> d.dismiss() }.show()
        }
    }

    private fun handleSendText(intent: Intent) {
        try {
            this.intent = null
            var url = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            if (url.isEmpty()) return

            val extractedUrl = try { iUtils.extractUrls(url)[0] } catch (_: Exception) { url }

            when {
                extractedUrl.contains("snapchat.com") -> {
                    startActivity(Intent(this@MainActivity, SnapChatBulkStoryDownloader::class.java).putExtra("urlsnap", extractedUrl.trim()))
                }
                extractedUrl.contains("instagram.com") -> {
                    setmydata(extractedUrl)
                    binding.viewpager.currentItem = 0 // Force move to download tab
                }
                else -> {
                    DownloadVideosMain.Start(this@MainActivity, extractedUrl.trim(), false)
                }
            }
        } catch (_: Exception) { }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        try {
            if (fragment is DownloadMainFragment) {
                val my = fragment as DownloadMainFragment
                val text = intent.getStringExtra(Intent.EXTRA_TEXT).toString()
                my.requireView().findViewById<EditText>(R.id.etURL)?.setText(text)
                my.DownloadVideo(text)
            } else {
                handleSendText(intent)
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun setLayout() {
        try {
            runpermissioncheck()
            if (::binding.isInitialized) {
                setupViewPager(binding.viewpager)

                val navBar = if (iUtils.isNonPlayStoreApp) binding.bottomNavBar else binding.bottomNavBarNonPlay
                if (iUtils.isNonPlayStoreApp) {
                    binding.bottomNavBarNonPlay.visibility = View.GONE
                    binding.bottomNavBar.visibility = View.VISIBLE
                } else {
                    binding.bottomNavBar.visibility = View.GONE
                    binding.bottomNavBarNonPlay.visibility = View.VISIBLE
                }

                navBar.onItemSelected = { binding.viewpager.currentItem = it }
                binding.viewpager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
                    override fun onPageSelected(position: Int) { navBar.itemActiveIndex = position }
                })
                binding.viewpager.offscreenPageLimit = 1
            }
        } catch (e: Throwable) { e.printStackTrace() }
    }

    private fun setupViewPager(viewPager: ViewPager2) {
        try {
            val adapter = ViewPagerAdapter(supportFragmentManager, lifecycle)
            adapter.addFragment(DownloadMainFragment(), getString(R.string.download_fragment))
            adapter.addFragment(ExtraFeaturesFragment(), getString(R.string.extrafeatures))
            if (iUtils.isNonPlayStoreApp) {
                adapter.addFragment(if (SDK_INT >= 29) StatusSaverMainFragment() else StatusSaverMainFragOld(), getString(R.string.StatusSaver))
            }
            viewPager.adapter = adapter
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun isPermissionGranted(permission: String) = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            setLayout()
            restartApp()
        }
    }

    private class ViewPagerAdapter(fm: FragmentManager, lc: Lifecycle) : FragmentStateAdapter(fm, lc) {
        private val mFragmentList = ArrayList<Fragment>()
        fun addFragment(f: Fragment, t: String) { mFragmentList.add(f) }
        override fun createFragment(position: Int) = mFragmentList[position]
        override fun getItemCount() = mFragmentList.size
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        val pp = SharedPrefsMainApp(this@MainActivity).preferencE_inappads
        menu.findItem(R.id.action_removeads).isVisible = (pp == "nnn") && Constants.show_subscription && !BuildConfig.ISPRO
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_privacy -> { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Setting.getPrivacyPolicy(this, Constants.iSAdminAttached)))); true }
            R.id.action_downloadtiktok -> { startActivity(Intent(this, TikTokDownloadWebview::class.java)); true }
            R.id.action_share -> { iUtils.shareApp(this); true }
            R.id.ic_whatapp -> {
                val intent = packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (intent != null) startActivity(intent) else iUtils.ShowToast(this, getString(R.string.appnotinstalled))
                true
            }
            R.id.action_language -> {
                val dialog = Dialog(this)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setContentView(R.layout.dialog_change_language)
                // Implement language clicks...
                dialog.show()
                true
            }
            R.id.action_removeads -> {
                if (iUtils.isSubactive) iUtils.ShowToast(this, getString(R.string.youhavealready))
                else startActivity(Intent(this, SubscriptionActivity::class.java))
                true
            }
            R.id.action_opengallery -> {
                if (getSharedPreferences("whatsapp_pref", MODE_PRIVATE).getBoolean("isBio", false)) biometricPrompt!!.authenticate(promptInfo!!)
                else startActivity(Intent(this, if (iUtils.isNewUi) GalleryActivityNewUi::class.java else GalleryActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showBottomSheetExitDialog() {
        try {
            val view = layoutInflater.inflate(R.layout.dialog_exit, null)
            val sheet = view.findViewById<FrameLayout>(R.id.bottom_sheet)
            sheet.background = ContextCompat.getDrawable(this, R.drawable.bg_rounded_light)

            val frameAd = view.findViewById<FrameLayout>(R.id.fl_adplaceholder)
            frameAd.visibility = View.VISIBLE
            AdsManager.loadAdmobNativeAdAsync(this@MainActivity, frameAd)

            view.findViewById<Button>(R.id.btn_rate).setOnClickListener { iUtils.rateApp(this); mBottomSheetDialog?.dismiss() }
            view.findViewById<Button>(R.id.btn_share).setOnClickListener { iUtils.shareApp(this); mBottomSheetDialog?.dismiss() }
            view.findViewById<Button>(R.id.btn_exit).setOnClickListener {
                mBottomSheetDialog?.dismiss()
                finishAndRemoveTask()
                exitProcess(0)
            }

            mBottomSheetDialog = BottomSheetDialog(this, R.style.SheetDialogLight)
            mBottomSheetDialog!!.setContentView(view)
            mBottomSheetDialog!!.show()
        } catch (e: Throwable) { e.printStackTrace() }
    }

    // 🚨 ORIGINAL BILLING CODE RESTORED TO FIX COMPILATION ERROR 🚨
    private fun initIInAppBillingAcknologement() {
        try {
            billingClient = BillingClientSetup.getInstance(this@MainActivity) { _, list ->
                if (list != null) {
                    for (purchase in list) handlesAlreadyPurchased(purchase)
                }
            }
            billingClient!!.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(billingResult: BillingResult) {
                    try {
                        loadAllSubscribePackage()
                        billingClient!!.queryPurchasesAsync(
                            QueryPurchasesParams.newBuilder()
                                .setProductType(BillingClient.ProductType.SUBS)
                                .build()
                        ) { _: BillingResult, purchases: List<Purchase> ->
                            if (purchases.isNotEmpty()) {
                                iUtils.isSubactive = true
                                runOnUiThread {
                                    if (::binding.isInitialized) {
                                        binding.subscriptionFab.visibility = View.GONE
                                    }
                                }
                                for (purchase in purchases) handlesAlreadyPurchased(purchase)
                            } else {
                                iUtils.isSubactive = false
                                runOnUiThread {
                                    if (::binding.isInitialized) {
                                        if (!Constants.show_subscription) {
                                            binding.subscriptionFab.visibility = View.GONE
                                        } else {
                                            if (!BuildConfig.ISPRO) {
                                                binding.subscriptionFab.visibility = View.VISIBLE
                                            } else {
                                                binding.subscriptionFab.visibility = View.GONE
                                            }
                                        }
                                    }
                                }
                                SharedPrefsMainApp(this@MainActivity).preferencE_inappads = "nnn"
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                override fun onBillingServiceDisconnected() { }
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // 🚨 ORIGINAL BILLING CODE RESTORED TO FIX COMPILATION ERROR 🚨
    private fun loadAllSubscribePackage() {
        try {
            if (billingClient!!.isReady) {
                val productList = listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium1month))
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium3month))
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium6months))
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build(),
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(getString(R.string.playstoresubscription_premium12months))
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                )

                billingClient!!.queryProductDetailsAsync(
                    QueryProductDetailsParams.newBuilder().setProductList(productList).build()
                ) { _, productDetailsList ->
                    try {
                        iUtils.SkuDetailsList = productDetailsList.productDetailsList
                    } catch (e: java.lang.Exception) {
                        e.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handlesAlreadyPurchased(purchases: Purchase) {
        if (purchases.purchaseState == Purchase.PurchaseState.PURCHASED) {
            iUtils.isSubactive = true
            SharedPrefsMainApp(this@MainActivity).preferencE_inappads = "ppp"
            runOnUiThread {
                if (::binding.isInitialized) {
                    binding.subscriptionFab.visibility = View.GONE
                    binding.bannerContainer.visibility = View.GONE
                }
            }
        }
    }

    override fun attachBaseContext(base: Context) { super.attachBaseContext(LocaleHelper.onAttach(base)) }

    private fun restartApp() {
        val i = packageManager.getLaunchIntentForPackage(packageName)
        i?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    override fun onDestroy() {
        super.onDestroy()
        AdsManager.cleanup(this@MainActivity)
    }

    override fun onResume() {
        super.onResume()
        if (Constants.iSAdminAttached) SplashScreen.getExistingAdminPanelData(this)
        doAllBioMetricTasks()
    }
}