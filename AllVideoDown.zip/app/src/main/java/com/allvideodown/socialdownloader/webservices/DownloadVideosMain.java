/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023-2026 . All rights reserved.
 *
 */

package com.allvideodown.socialdownloader.webservices;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Context.WINDOW_SERVICE;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Html;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.franmontiel.persistentcookiejar.ClearableCookieJar;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.adapters.QualityBottomsheetAdapter;
import com.allvideodown.socialdownloader.interfaces.DataCallBackNewJetApi;
import com.allvideodown.socialdownloader.models.dlapismodels.DLDataParser;
import com.allvideodown.socialdownloader.models.dlapismodels.Format;
import com.allvideodown.socialdownloader.models.dlapismodels.Video;
import com.allvideodown.socialdownloader.snapchatstorysaver.SnapChatBulkStoryDownloader;
import com.allvideodown.socialdownloader.tiktok_methods.FacebookDownloadCloudBypassWebview_method_0_new;
import com.allvideodown.socialdownloader.tiktok_methods.TikTokDownloadCloudBypassWebview_method_6;
import com.allvideodown.socialdownloader.utils.Constants;
import com.allvideodown.socialdownloader.utils.DownloadFileMain;
import com.allvideodown.socialdownloader.utils.GlideApp;
import com.allvideodown.socialdownloader.utils.iUtils;
import com.allvideodown.socialdownloader.webservices.api.RetrofitApiInterface;
import com.allvideodown.socialdownloader.webservices.api.RetrofitClient;
import com.libs.androidnetworking.AndroidNetworking;
import com.libs.androidnetworking.common.Priority;
import com.libs.androidnetworking.error.ANError;
import com.libs.androidnetworking.interfaces.JSONObjectRequestListener;
import com.libs.htetznaing.lowcostvideo.LowCostVideo;
import com.libs.htetznaing.lowcostvideo.Model.XModel;
import com.libs.yxcorp.gifshow.util.CPU;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.mapper.VideoFormat;
import com.yausername.youtubedl_android.mapper.VideoInfo;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;

@SuppressLint("all")
public class DownloadVideosMain {

    private static final int DOWNLOAD_NOTIFICATION_ID = 231;

    public static Activity Mcontext;
    public static ProgressDialog pd;
    public static Dialog dialog;
    public static SharedPreferences prefs;
    public static Boolean fromService;
    public static String VideoUrl;
    static String Title;
    static LinearLayout mainLayout;
    static WindowManager windowManager2;
    static WindowManager.LayoutParams params;
    static View mChatHeadView;
    static ImageView img_dialog;
    static String myURLIS = "";
    static Dialog dialog_quality_allvids;
    static VideoInfo streamInfo;
    static String newddurl = "";
    private static String newurl;

    // --- PREVIEW DIALOG GENERATOR FOR ALL DIRECT LINKS ---
    public static void showMultiMediaPreviewDialog(List<String> urls, List<String> exts, String baseName) {
        if (Mcontext == null || ((Activity) Mcontext).isFinishing() || urls.isEmpty()) return;
        ((Activity) Mcontext).runOnUiThread(() -> {
            Dialog dialog = new Dialog(Mcontext);
            dialog.setCancelable(true);

            LinearLayout layout = new LinearLayout(Mcontext);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(60, 60, 60, 60);
            layout.setGravity(Gravity.CENTER);
            layout.setBackgroundColor(Color.WHITE);

            TextView titleView = new TextView(Mcontext);
            titleView.setText(urls.size() > 1 ? "Preview (1 of " + urls.size() + " items)" : "Media Preview");
            titleView.setTextSize(18f);
            titleView.setTypeface(null, android.graphics.Typeface.BOLD);
            titleView.setTextColor(Color.BLACK);
            titleView.setPadding(0, 0, 0, 30);

            ImageView imageView = new ImageView(Mcontext);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            ((Activity) Mcontext).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int width = displayMetrics.widthPixels - 150;
            LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(width, 800);
            imageView.setLayoutParams(imgParams);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);

            GlideApp.with(Mcontext).load(urls.get(0)).into(imageView);

            Button downloadBtn = new Button(Mcontext);
            downloadBtn.setText(urls.size() > 1 ? "Download All (" + urls.size() + ")" : "Download Now");
            downloadBtn.setBackgroundResource(R.drawable.btn_bg_download_screen);
            downloadBtn.setTextColor(Color.WHITE);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            btnParams.topMargin = 50;
            downloadBtn.setLayoutParams(btnParams);

            layout.addView(titleView);
            layout.addView(imageView);
            layout.addView(downloadBtn);
            dialog.setContentView(layout);

            downloadBtn.setOnClickListener(v -> {
                dialog.dismiss();
                for (int i = 0; i < urls.size(); i++) {
                    String finalName = urls.size() > 1 ? baseName + "_" + i : baseName;
                    DownloadFileMain.startDownloading(Mcontext, urls.get(i), finalName, exts.get(i));
                }
                iUtils.ShowToast(Mcontext, "Downloading Started...");
            });

            dialog.show();
        });
    }

    public static void startDownloadWithPreview(String url, String fileName, String ext) {
        List<String> u = new ArrayList<>(); u.add(url);
        List<String> e = new ArrayList<>(); e.add(ext);
        showMultiMediaPreviewDialog(u, e, fileName);
    }


    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    public static void Start(final Activity context, String websiteUrl, Boolean service) {
        try {

            Mcontext = context;
            fromService = service;
            Log.i("LOGClipboard111111 clip", "work 2");

            try {
                websiteUrl = iUtils.extractUrls(websiteUrl).get(0);
            } catch (Exception ignored) {

            }

            myURLIS = websiteUrl;
            if (!fromService) {
                pd = new ProgressDialog(context);
                pd.setMessage(Mcontext.getResources().getString(R.string.genarating_download_link));
                pd.setCancelable(false);
                pd.show();
            }
            getDataFromNewJetApi(websiteUrl, result -> {
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(() -> {


                    Log.i("LOGClipboard111111 websiteUrl", result + "");

                    if (!result) {

                        if (myURLIS.contains("tiktok")) {

                            if (!iUtils.isSocialMediaOn("tiktok")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            if (!((Activity) Mcontext).isFinishing()) {
                                Executors.newSingleThreadExecutor().submit(() -> {
                                    try {
                                        HttpURLConnection con = (HttpURLConnection) (new URL(myURLIS).openConnection());
                                        con.setInstanceFollowRedirects(false);
                                        con.connect();
                                        String location = con.getHeaderField("Location");
                                        if (location == null) location = myURLIS;

                                        String username = location.split("/")[5].split("\\?")[0];
                                        newddurl = "https://tikcdn.io/ssstik/" + username;

                                        ((Activity) Mcontext).runOnUiThread(() -> {
                                            dismissMyDialog();
                                            startDownloadWithPreview(newddurl, "Tiktok_" + username + "_" + System.currentTimeMillis(), ".mp4");
                                        });
                                    } catch (Exception e) {
                                        // Fallback to Webview Method Silent
                                        ((Activity) Mcontext).runOnUiThread(() -> {
                                            dismissMyDialog();
                                            Intent intent = new Intent(Mcontext, TikTokDownloadCloudBypassWebview_method_6.class);
                                            intent.putExtra("myvidurl", myURLIS);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                            Mcontext.startActivity(intent);
                                        });
                                    }
                                });
                            }

                        } else if (myURLIS.contains("snapchat.com")) {

                            if (!iUtils.isSocialMediaOn("snapchat.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            try {
                                myURLIS = iUtils.extractUrls(myURLIS).get(0);

                                URI uri = new URI(myURLIS);
                                String urlwi = new URI(
                                        uri.getScheme(),
                                        uri.getAuthority(),
                                        uri.getPath(),
                                        null, // Ignore the query part of the input url
                                        uri.getFragment()
                                ).toString();

                                dismissMyDialog();
                                if (urlwi.split("/").length > 5) {
                                    Mcontext.startActivity(new Intent(Mcontext, SnapChatBulkStoryDownloader.class).putExtra("urlsnap", urlwi.substring(0, urlwi.lastIndexOf("/")).trim()));
                                } else {
                                    Mcontext.startActivity(new Intent(Mcontext, SnapChatBulkStoryDownloader.class).putExtra("urlsnap", urlwi.trim()));
                                }

                            } catch (Exception e) {
                                dismissMyDialogErrortoast();
                            }

                        } else if (myURLIS.contains("popcornflix")) {
                            if (!iUtils.isSocialMediaOn("popcornflix")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            myURLIS = myURLIS.substring(myURLIS.lastIndexOf("/") + 1);

                            AndroidNetworking.get("https://api.unreel.me/v2/sites/popcornflix/videos/" + myURLIS + "/play-url?__site=popcornflix&__source=web&embed=false&protocol=https&tv=false")
                                    .addHeaders("User-Agent", "Mozilla/5.0 (Linux; Android 10;TXY567) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/8399.0.9993.96 Mobile Safari/599.36")
                                    .setPriority(Priority.MEDIUM)
                                    .build()
                                    .getAsJSONObject(new JSONObjectRequestListener() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            dismissMyDialog();
                                            String matag;
                                            try {
                                                JSONObject jsonObject = new JSONObject(response.toString());
                                                matag = jsonObject.getString("url");
                                                startDownloadWithPreview(matag, "Popcornflex_" + System.currentTimeMillis(), ".mp4");
                                            } catch (Exception e) {
                                                dismissMyDialog();
                                                e.printStackTrace();
                                            }
                                        }

                                        @Override /**/
                                        public void onError(ANError error) {
                                            dismissMyDialog();
                                        }
                                    });

                        } else if (myURLIS.contains("veoh")) {

                            if (!iUtils.isSocialMediaOn("veoh")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                            }
                            myURLIS = myURLIS.substring(myURLIS.lastIndexOf("/") + 1);

                            AndroidNetworking.get("http://www.veoh.com/watch/getVideo/" + myURLIS)
                                    .addHeaders("User-Agent", "Mozilla/5.0 (Linux; Android 10;TXY567) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/8399.0.9993.96 Mobile Safari/599.36")
                                    .setPriority(Priority.MEDIUM)
                                    .build()
                                    .getAsJSONObject(new JSONObjectRequestListener() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            dismissMyDialog();
                                            String matag;
                                            try {
                                                JSONObject jsonObject = new JSONObject(response.toString());
                                                matag = jsonObject.getJSONObject("video").getJSONObject("src").getString("HQ");
                                                startDownloadWithPreview(matag, "Veoh_" + System.currentTimeMillis(), ".mp4");
                                            } catch (Exception e) {
                                                dismissMyDialog();
                                            }
                                        }

                                        @Override /**/
                                        public void onError(ANError error) {
                                            dismissMyDialog();
                                        }
                                    });

                        } else if (myURLIS.contains("moj")) {
                            if (!iUtils.isSocialMediaOn("moj")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            try {
                                myURLIS = myURLIS.substring(myURLIS.lastIndexOf("/") + 1);

                                if (myURLIS.contains("?referrer=share")) {
                                    myURLIS = myURLIS.substring(0, myURLIS.indexOf("?"));
                                }

                                JSONObject jsonObject = new JSONObject("{\"appVersion\":83,\"bn\":\"broker1\",\"client\":\"android\",\"deviceId\":\"ebb088d29e7287b1\",\"message\":{\"adData\":{\"adsShown\":0,\"firstFeed\":false},\"deviceInfoKey\":\"OSyQoHJLJ4NsXPLyQePkAICh3Q0ih0bveFwm1KEV+vReMuldqo+mSyMjdhb4EeryKxk1ctAbYaDH\\\\nTI+PMRPZVYH5pBccAm7OT2uz69vmD/wPqGuSgWV2aVNMdM75DMb8NZn1JU2b1bo/oKs80baklsvx\\\\n1X7jrFPL6M5EDTdPDhs=\\\\n\",\"deviceInfoPayload\":\"M6g+6j6irhFT/H6MsQ/n/tEhCl7Z5QgtVfNKU8M90zTJHxqljm2263UkjRR9bRXAjmQFXXOTXJ25\\\\nOHRjV7L5Lw+tUCONoYfyUEzADihWfAiUgXJEcKePfZONbdXXuwGgOPeD0k4iSvI7JdzroRCScKXd\\\\n41CkmXFayPaRL9aqgAgs6kSoIncCWBU2gEXiX1lgPVvdmUzCZ+yi2hFA+uFOmv1MJ6dcFKKcpBM6\\\\nHSPIrGV+YtTyfd8nElx0kyUbE4xmjOuMrctkjnJkd2tMdxB8qOFKeYrcLzy4LZJNXyUmzs29XSE+\\\\nhsrMZib8fFPJhJZIyGCWqfWiURut4Bg5HxYhYhg3ejPxFjNyXxS3Ja+/pA+A0olt5Uia7ync/Gui\\\\n58tlDQ4SKPthCzGa1tCVN+2y/PW30+LM79t0ltJ/YrNZivQx4eEnszlM9nwmIuj5z5LPniQghA6x\\\\nrfQ8IqVUZfiitXj/Fr7UjKg1cs/Ajj8g4u/KooRvVkg9tMwWePtJFqrkk1+DU4cylnSEG3XHgfer\\\\nslrzj5NNZessMEi+4Nz0O2D+b8Y+RjqN6HqpwZPDHhZwjz0Iuj2nhZLgu1bgNJev5BwxAr8akDWv\\\\nvKsibrJS9auQOYVzbYZFdKMiBnh+WHq0qO2aW1akYWCha3ZsSOtsnyPnFC+1PnMbBv+FiuJmPMXg\\\\nSODFoRIXfxgA/qaiKBipS+kIyfaPxn6O1i6MOwejVuQiWdAPTO132Spx0cFtdyj2hX6wAMe21cSy\\\\n8rs3KQxiz+cq7Rfwzsx4wiaMryFunfwUwnauGwTFOW98D5j6oO8=\\\\n\",\"lang\":\"Hindi\",\"playEvents\":[{\"authorId\":\"18326559001\",\"networkBitrate\":1900000,\"initialBufferPercentage\":100,\"isRepost\":false,\"sg\":false,\"meta\":\"NotifPostId\",\"md\":\"Stream\",\"percentage\":24.68405,\"p\":\"91484006\",\"radio\":\"wifi\",\"r\":\"deeplink_VideoPlayer\",\"repeatCount\":0,\"timeSpent\":9633,\"duration\":15,\"videoStartTime\":3916,\"t\":1602255552820,\"clientType\":\"Android\",\"i\":79,\"appV\":83,\"sessionId\":\"72137847101_8863b3f5-ad2d-4d59-aa7c-cf1fb9ef32ea\"},{\"authorId\":\"73625124001\",\"networkBitrate\":1900000,\"initialBufferPercentage\":100,\"isRepost\":false,\"sg\":false,\"meta\":\"list2\",\"md\":\"Stream\",\"percentage\":17.766666,\"p\":\"21594412\",\"radio\":\"wifi\",\"r\":\"First Launch_VideoPlayer\",\"repeatCount\":0,\"tagId\":\"0\",\"tagName\":\"\",\"timeSpent\":31870,\"duration\":17,\"videoStartTime\":23509,\"t\":1602218215942,\"clientType\":\"Android\",\"i\":79,\"appV\":83,\"sessionId\":\"72137847101_db67c0c9-a267-4cec-a3c3-4c0fa4ea16e1\"}],\"r\":\"VideoFeed\"},\"passCode\":\"9e32d6145bfe53d14a0c\",\"resTopic\":\"response/user_72137847101_9e32d6145bfe53d14a0c\",\"userId\":\"72137847101\"}");

                                AndroidNetworking.post("https://moj-apis.sharechat.com/videoFeed?postId=" + myURLIS + "&firstFetch=true")
                                        .addHeaders("X-SHARECHAT-USERID", "72137847101")
                                        .addHeaders("X-SHARECHAT-SECRET", "9e32d6145bfe53d14a0c")
                                        .addHeaders("APP-VERSION", "83")
                                        .addHeaders("PACKAGE-NAME", "in.mohalla.video")
                                        .addHeaders("DEVICE-ID", "ebb088d29e7287b1")
                                        .addHeaders("CLIENT-TYPE", "Android:")
                                        .addHeaders("Content-Type", "application/json; charset=UTF-8")
                                        .addHeaders("Host", "moj-apis.sharechat.com")
                                        .addHeaders("Connection", "Keep-Alive:")
                                        .addHeaders("User-Agent", "okhttp/3.12.12app-version:83")
                                        .addHeaders("cache-control", "no-cache")
                                        .addHeaders("client-type", "Android")
                                        .addHeaders("connection", "Keep-Alive")
                                        .addHeaders("content-type", "application/json;charset=UTF-8")
                                        .addHeaders("device-id", "ebb088d29e7287b1")
                                        .addHeaders("host", "moj-apis.sharechat.com")
                                        .addHeaders("package-name", "in.mohalla.video")
                                        .addHeaders("postman-token", "37d59a7c-f247-3b70-ab3c-1dedf4079852")
                                        .addHeaders("user-agent", "okhttp/3.12.12")
                                        .addHeaders("x-sharechat-secret", "9e32d6145bfe53d14a0c")
                                        .addHeaders("x-sharechat-userid", "72137847101")
                                        .addJSONObjectBody(jsonObject)
                                        .setPriority(Priority.MEDIUM)
                                        .build()
                                        .getAsJSONObject(new JSONObjectRequestListener() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                dismissMyDialog();
                                                String matag;
                                                try {
                                                    JSONObject jsonObject = new JSONObject(response.toString());
                                                    matag = jsonObject.getJSONObject("payload")
                                                            .getJSONArray("d").getJSONObject(0).getString("compressedVideoUrl");

                                                    startDownloadWithPreview(matag, "Moj_" + System.currentTimeMillis(), ".mp4");
                                                } catch (Exception e) {
                                                    dismissMyDialog();
                                                }
                                            }

                                            @Override /**/
                                            public void onError(ANError error) {
                                                dismissMyDialog();
                                            }
                                        });

                            } catch (Exception e) {
                                dismissMyDialog();
                            }
                        } else if (myURLIS.contains("fairtok")) {
                            if (!iUtils.isSocialMediaOn("fairtok")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            try {
                                myURLIS = myURLIS.substring(myURLIS.lastIndexOf("/") + 1);

                                JSONObject jsonObject = new JSONObject("{\"device_fingerprint_id\":\"838529202513017602\",\"identity_id\":\"838529202537882206\",\"hardware_id\":\"ebb088d29e7287b1\",\"is_hardware_id_real\":true,\"brand\":\"samsung\",\"model\":\"SM-J200G\",\"screen_dpi\":240,\"screen_height\":960,\"screen_width\":540,\"wifi\":true,\"ui_mode\":\"UI_MODE_TYPE_NORMAL\",\"os\":\"Android\",\"os_version\":22,\"cpu_type\":\"armv7l\",\"build\":\"LMY47X.J200GDCU2ARL1\",\"locale\":\"en_GB\",\"connection_type\":\"wifi\",\"os_version_android\":\"5.1.1\",\"country\":\"GB\",\"language\":\"en\",\"local_ip\":\"192.168.43.18\",\"app_version\":\"1.19\",\"facebook_app_link_checked\":false,\"is_referrable\":0,\"debug\":false,\"update\":1,\"latest_install_time\":1601158937336,\"latest_update_time\":1601158937336,\"first_install_time\":1601158937336,\"previous_update_time\":1601158937336,\"environment\":\"FULL_APP\",\"android_app_link_url\":\"https:\\/\\/fairtok.app.link\\/" + myURLIS + "\",\"external_intent_uri\":\"https:\\/\\/fairtok.app.link\\/Y7ov2al149\",\"cd\":{\"mv\":\"-1\",\"pn\":\"com.fairtok\"},\"metadata\":{},\"advertising_ids\":{\"aaid\":\"094dfa1f-77cf-4f84-b373-2c15bf74f9d1\"},\"lat_val\":0,\"google_advertising_id\":\"094dfa1f-77cf-4f84-b373-2c15bf74f9d1\",\"instrumentation\":{\"v1\\/open-qwt\":\"0\"},\"sdk\":\"android5.0.1\",\"branch_key\":\"key_live_hjLYp0Wi3i6R1qQ1Lr51TlpcBvkxEp53\",\"retryNumber\":0}");

                                AndroidNetworking.post("https://api2.branch.io/v1/open")
                                        .addHeaders("cache-control", "no-cache")
                                        .addJSONObjectBody(jsonObject)
                                        .setPriority(Priority.MEDIUM)
                                        .build()
                                        .getAsJSONObject(new JSONObjectRequestListener() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                dismissMyDialog();
                                                String matag;
                                                try {
                                                    JSONObject jsonObject = new JSONObject(response.toString());
                                                    matag = "https://bucket-fairtok.s3.ap-south-1.amazonaws.com/" + jsonObject.getString("post_video");
                                                    startDownloadWithPreview(matag, "Fairtok_" + System.currentTimeMillis(), ".mp4");
                                                } catch (Exception e) {
                                                    dismissMyDialog();
                                                }
                                            }

                                            @Override /**/
                                            public void onError(ANError error) {
                                                dismissMyDialog();
                                            }
                                        });

                            } catch (Exception e) {
                                dismissMyDialog();
                            }
                        } else if (myURLIS.contains("vlipsy")) {
                            if (!iUtils.isSocialMediaOn("vlipsy")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            try {
                                myURLIS = myURLIS.substring(myURLIS.lastIndexOf("/") + 1);
                                if (myURLIS.length() > 8) {
                                    String[] aa = myURLIS.split("-");
                                    myURLIS = aa[aa.length - 1];
                                }

                                AndroidNetworking.get("https://apiv2.vlipsy.com/v1/vlips/" + myURLIS + "?key=vl_R8daJGhs67i7Ej7y")
                                        .setPriority(Priority.MEDIUM)
                                        .build()
                                        .getAsJSONObject(new JSONObjectRequestListener() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                dismissMyDialog();
                                                String matag;
                                                try {
                                                    JSONObject jsonObject = new JSONObject(response.toString());
                                                    matag = jsonObject.getJSONObject("data").getJSONObject("media").getJSONObject("mp4").getString("url");
                                                    startDownloadWithPreview(matag, "Vlipsy_" + System.currentTimeMillis(), ".mp4");
                                                } catch (Exception e) {
                                                    dismissMyDialog();
                                                }
                                            }
                                            @Override /**/
                                            public void onError(ANError error) {
                                                dismissMyDialog();
                                            }
                                        });

                            } catch (Exception e) {
                                dismissMyDialog();
                            }
                        } else if (myURLIS.contains("l_ik_e_e")) {
                            if (!iUtils.isSocialMediaOn("likee")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            LikeeVideoDownloader tikTokNewTestDownloader = new LikeeVideoDownloader(Mcontext, myURLIS);
                            tikTokNewTestDownloader.DownloadVideo();

                        } else if (myURLIS.contains("likee")) {
                            if (!iUtils.isSocialMediaOn("likee")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            final String[] finalUrl3 = { myURLIS };
                            new Thread(() -> {
                                Looper.prepare();
                                try {
                                    if (finalUrl3[0].contains("likee.video/v/")) {
                                        try {
                                            OkHttpClient client = new OkHttpClient().newBuilder().build();
                                            Request request = new Request.Builder().url(finalUrl3[0]).method("GET", null).build();
                                            Response response = client.newCall(request).execute();
                                            String myres = Objects.requireNonNull(response.body()).string();
                                            String line2 = myres.substring(myres.indexOf("window.data ="), myres.indexOf("}</script>"));
                                            line2 = line2.replaceFirst("window.data = ", "") + "}";
                                            finalUrl3[0] = line2;
                                        } catch (Exception e) { }
                                    }

                                    String v;
                                    if (finalUrl3[0].contains("likee.video/@")) {
                                        v = finalUrl3[0].substring(finalUrl3[0].indexOf("/video/") + 7);
                                    } else {
                                        Uri uri = Uri.parse(finalUrl3[0]);
                                        v = uri.getQueryParameter("postId");
                                    }

                                    OkHttpClient client = new OkHttpClient.Builder()
                                            .connectTimeout(10, TimeUnit.SECONDS)
                                            .writeTimeout(10, TimeUnit.SECONDS)
                                            .readTimeout(30, TimeUnit.SECONDS)
                                            .build();
                                    RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                                            .addFormDataPart("postIds", v)
                                            .build();
                                    Request request = new Request.Builder()
                                            .url("https://likee.video/official_website/VideoApi/getVideoInfo")
                                            .method("POST", body)
                                            .addHeader("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36")
                                            .build();
                                    Response response = client.newCall(request).execute();

                                    if (response.code() == 200) {
                                        dismissMyDialog();
                                        String urls = new JSONObject(Objects.requireNonNull(response.body()).string()).getJSONObject("data").getJSONArray("videoList").getJSONObject(0).getString("videoUrl");
                                        if (urls.contains("_4")) {
                                            urls = urls.replace("_4", "");
                                        }
                                        if (!urls.equals("")) {
                                            startDownloadWithPreview(urls, "Likee_" + System.currentTimeMillis(), ".mp4");
                                        }
                                    } else {
                                        dismissMyDialogErrortoast();
                                    }
                                } catch (Exception e) {
                                    dismissMyDialogErrortoast();
                                }
                            }).start();

                        } else if (myURLIS.contains("kooapp")) {
                            if (!iUtils.isSocialMediaOn("kooapp")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            KooDownloader kooDownloader = new KooDownloader(Mcontext, myURLIS);
                            kooDownloader.DownloadVideo();

                        } else if (myURLIS.contains("gfycat") || myURLIS.contains("abc.com") || myURLIS.contains("videoclip.org") || myURLIS.contains("funimate") || myURLIS.contains("1tv.ru") || myURLIS.contains("naver") || myURLIS.contains("gloria.tv") || myURLIS.contains("vidcommons.org") || myURLIS.contains("media.ccc.de") || myURLIS.contains("vlive") || myURLIS.contains("blogspot.com") || myURLIS.contains("vimeo.com")) {

                            if(!iUtils.isSocialMediaOn(myURLIS)){
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            CalldlApisDataData(myURLIS, true);

                        } else if (myURLIS.contains("flickr") || myURLIS.contains("flic.kr") || myURLIS.contains("streamable")) {
                            CalldlApisDataData(myURLIS, true);

                        } else if (myURLIS.contains("vk.com")) {
                            CalldlApisDataData(myURLIS, false);
                        } else if (myURLIS.contains("soundcloud")) {
                            if (Constants.showyoutube) {
                                myURLIS = myURLIS.replace("//m.", "//");
                                CalldlApisDataData(myURLIS, true);
                            } else {
                                dismissMyDialogErrortoast();
                            }
                        } else if (myURLIS.contains("bandcamp") || myURLIS.contains("cocoscope") || myURLIS.contains("vidlit") || myURLIS.contains("izlesene")) {
                            CalldlApisDataData(myURLIS, true);
                        } else if (myURLIS.contains("linkedin")) {
                            if (!iUtils.isSocialMediaOn("linkedin")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CalllinkedinData(Mcontext).execute(myURLIS);
                        } else if (myURLIS.contains("kwai") || myURLIS.contains("kw.ai") || myURLIS.contains("bitchute") || myURLIS.contains("ojoo") || myURLIS.contains("blogger") || myURLIS.contains("break.com") || myURLIS.contains("espn") || myURLIS.contains("coub") || myURLIS.contains("ted.com") || myURLIS.contains("fansubs.tv") || myURLIS.contains("twitch")) {
                            CalldlApisDataData(myURLIS, true);
                        } else if (myURLIS.contains("imgur.com") || myURLIS.contains("rumble.com")) {
                            myURLIS = myURLIS.replace("//m.", "//");
                            CalldlApisDataData(myURLIS, false);
                        } else if (myURLIS.contains("youtube.com") || myURLIS.contains("youtu.be")) {
                            if (Constants.showyoutube) {
                                callDlApiNew(myURLIS);
                            } else {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                            }
                        } else if (myURLIS.contains("sharechat.com")) {

                            if (!iUtils.isSocialMediaOn("sharechat.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            try {
                                myURLIS = iUtils.extractUrls(myURLIS).get(0);
                                int index = myURLIS.lastIndexOf('/') + 1;
                                myURLIS = myURLIS.substring(index);
                                if (myURLIS.contains("?")) {
                                    myURLIS = myURLIS.split("[?]")[0];
                                }

                                JSONObject jsonObject = new JSONObject("{\"bn\":\"broker3\",\"userId\":644045091,\"passCode\":\"52859d76753457f8dcae\",\"client\":\"web\",\"message\":{\"key\":\"" + myURLIS + "\",\"ph\":\"" + myURLIS + "\"}}");
                                AndroidNetworking.post("https://apis.sharechat.com/requestType45")
                                        .addJSONObjectBody(jsonObject)
                                        .addHeaders("Content-Type", "application/json")
                                        .addHeaders("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36")
                                        .setPriority(Priority.MEDIUM)
                                        .build()
                                        .getAsJSONObject(new JSONObjectRequestListener() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                dismissMyDialog();
                                                String matag;
                                                try {
                                                    JSONObject jsonObject = new JSONObject(response.toString());
                                                    boolean isvideo = true;
                                                    try {
                                                        matag = jsonObject.getJSONObject("payload").getJSONObject("d").getString("v");
                                                        isvideo = true;
                                                    } catch (Exception e) {
                                                        matag = jsonObject.getJSONObject("payload").getJSONObject("d").getString("g");
                                                        isvideo = false;
                                                    }
                                                    startDownloadWithPreview(matag, "Sharechat_" + System.currentTimeMillis(), ((isvideo) ? ".mp4" : ".jpg"));
                                                } catch (Exception e) {
                                                    dismissMyDialog();
                                                }
                                            }
                                            @Override
                                            public void onError(ANError error) {
                                                dismissMyDialog();
                                            }
                                        });

                            } catch (Exception e) {
                                dismissMyDialog();
                            }

                        } else if (myURLIS.contains("roposo.com")) {
                            if (!iUtils.isSocialMediaOn("roposo.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new callGetRoposoData().execute(myURLIS);
                        } else if (myURLIS.contains("snackvideo") || myURLIS.contains("sck.io")) {
                            if (!iUtils.isSocialMediaOn("snackvideo") || !iUtils.isSocialMediaOn("sck.io")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new callGetsnackvideoData().execute(myURLIS);
                        } else if ((myURLIS.contains("facebook.com") || myURLIS.contains("fb.watch"))) {

                            if (!iUtils.isNonPlayStoreApp) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            if (!iUtils.isSocialMediaOn("facebook.com") || !iUtils.isSocialMediaOn("fb.watch")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            if (!((Activity) Mcontext).isFinishing()) {
                                AndroidNetworking.get("https://s4.downloadfacebook.net/ajax/getLinks.php?video=" + myURLIS + "&rand=PNSQNPOPRTTUOLP")
                                        .setPriority(Priority.MEDIUM)
                                        .addHeaders("Content-type", "application/x-www-form-urlencoded")
                                        .addHeaders("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36")
                                        .build()
                                        .getAsJSONObject(new JSONObjectRequestListener() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                try {
                                                    dismissMyDialog();
                                                    JSONObject jsonObject = new JSONObject(response.toString());
                                                    JSONArray jsonaaa = jsonObject.getJSONObject("data").getJSONArray("av");
                                                    String matag = jsonaaa.getJSONObject(0).getString("url");
                                                    startDownloadWithPreview(matag, "Facebook_" + System.currentTimeMillis(), ".mp4");
                                                } catch (Exception e) {
                                                    fallbackToFbWebview();
                                                }
                                            }
                                            @Override
                                            public void onError(ANError error) {
                                                fallbackToFbWebview();
                                            }
                                        });
                            }

                        } else if (myURLIS.contains("instagram.com")) {
                            if (!iUtils.isNonPlayStoreApp || !iUtils.isSocialMediaOn("instagram.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            callDlApiNew(myURLIS);
                        } else if (myURLIS.contains("bilibili.com")) {
                            if (!iUtils.isSocialMediaOn("bilibili.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new callGetbilibiliAppData().execute(myURLIS);
                        } else if (myURLIS.contains("mitron.tv")) {
                            if (!iUtils.isSocialMediaOn("mitron.tv")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallMitronData().execute(myURLIS);
                        } else if (myURLIS.contains("josh")) {
                            if (!iUtils.isSocialMediaOn("josh")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallJoshData().execute(myURLIS);
                        } else if (myURLIS.contains("kuaishou")) {
                            if (!iUtils.isSocialMediaOn("kuaishou")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            if (myURLIS.contains("https://www.kuaishou.com/short-video/")) {
                                new CallkuaishouData().execute(myURLIS);
                            } else {
                                if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
                                    pd.dismiss();
                                    Mcontext.runOnUiThread(() -> {
                                        iUtils.ShowToast(Mcontext, "Please Use this url type \"https://www.kuaishou.com/short-video/\"");
                                    });
                                }
                            }
                        } else if (myURLIS.contains("triller")) {
                            if (!iUtils.isSocialMediaOn("triller")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            getTrillerData(myURLIS);

                        } else if (myURLIS.contains("rizzle")) {
                            if (!iUtils.isSocialMediaOn("rizzle")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallRizzleData().execute(myURLIS);
                        } else if (myURLIS.contains("solidfiles")) {
                            if (!iUtils.isSocialMediaOn("solidfiles")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            SolidfilesDownloader solidfilesDownloader = new SolidfilesDownloader(Mcontext, myURLIS);
                            solidfilesDownloader.DownloadVideo();

                        } else if (myURLIS.contains("ifunny")) {
                            if (!iUtils.isSocialMediaOn("ifunny")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallIfunnyData().execute(myURLIS);
                        } else if (myURLIS.contains("trell.co")) {
                            if (!iUtils.isSocialMediaOn("trell.co")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }

                            if (myURLIS.contains("?")) {
                                myURLIS = myURLIS.split("\\?")[0];
                            }
                            myURLIS = myURLIS.substring(myURLIS.indexOf("watch"));
                            myURLIS = myURLIS.substring(myURLIS.indexOf("/") + 1);

                            AndroidNetworking.get("https://api.trell.co/api/v1/trail/" + myURLIS)
                                    .setPriority(Priority.MEDIUM)
                                    .build()
                                    .getAsJSONObject(new JSONObjectRequestListener() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            try {
                                                dismissMyDialog();
                                                String html = response.toString();
                                                if (!html.equals("")) {
                                                    VideoUrl = String.valueOf(new JSONObject(new JSONObject(html)
                                                            .getJSONObject("result").getJSONObject("trail").getJSONArray("posts").get(0).toString()).get("video"));

                                                    if (VideoUrl != null && !VideoUrl.equals("")) {
                                                        startDownloadWithPreview(VideoUrl, "trellvideo_" + System.currentTimeMillis(), ".mp4");
                                                        VideoUrl = "";
                                                    }
                                                }
                                            } catch (Exception unused) {
                                                dismissMyDialog();
                                            }
                                        }
                                        @Override
                                        public void onError(ANError error) {
                                            dismissMyDialog();
                                        }
                                    });

                        } else if (myURLIS.contains("boloindya.com")) {
                            if (!iUtils.isSocialMediaOn("boloindya.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallBoloindyaData().execute(myURLIS);
                        } else if (myURLIS.contains("chingari")) {
                            if (!iUtils.isSocialMediaOn("chingari")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            CallchingariData(myURLIS);
                        } else if (myURLIS.contains("dubsmash")) {
                            if (!iUtils.isSocialMediaOn("dubsmash")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CalldubsmashData().execute(myURLIS);
                        } else if (myURLIS.contains("bittube")) {
                            if (!iUtils.isSocialMediaOn("bittube")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            String myurlis1 = myURLIS;
                            if (myurlis1.contains(".tv")) {
                                String str = "/";
                                myurlis1 = myurlis1.split(str)[myurlis1.split(str).length - 1];
                                myurlis1 = "https://bittube.video/videos/watch/" + myurlis1;
                            }
                            new CallgdriveData().execute(myurlis1);

                        } else if (myURLIS.contains("drive.google.com") || myURLIS.contains("mp4upload") || myURLIS.contains("ok.ru") || myURLIS.contains("mediafire") || myURLIS.contains("gphoto") || myURLIS.contains("uptostream") || myURLIS.contains("fembed") || myURLIS.contains("cocoscope") || myURLIS.contains("sendvid") || myURLIS.contains("vivo") || myURLIS.contains("4shared")) {

                            new CallgdriveData().execute(myURLIS);
                        } else if (myURLIS.contains("hind")) {
                            if (!iUtils.isSocialMediaOn("hind")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallhindData().execute(myURLIS);
                        } else if (myURLIS.contains("topbuzz.com")) {
                            if (!iUtils.isSocialMediaOn("topbuzz.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            TopBuzzDownloader downloader = new TopBuzzDownloader(Mcontext, myURLIS);
                            downloader.DownloadVideo();

                        } else if (myURLIS.contains("audioboom") || myURLIS.contains("zingmp3.vn") || myURLIS.contains("twitter.com") || myURLIS.contains("gag.com") || myURLIS.contains("redd.it") || myURLIS.contains("reddit")) {
                            CalldlApisDataData(myURLIS, true);
                        } else if (myURLIS.contains("buzzfeed.com")) {
                            dismissMyDialogErrortoast();
                        } else if (myURLIS.contains("mxtakatak")) {
                            if (!iUtils.isSocialMediaOn("mxtakatak")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            String finalUrl3 = myURLIS;
                            if (finalUrl3.contains("share.mxtakatak.com")) {
                                new Thread(() -> {
                                    Looper.prepare();
                                    HttpURLConnection con;
                                    try {
                                        con = (HttpURLConnection) (new URL(finalUrl3).openConnection());
                                        con.setInstanceFollowRedirects(false);
                                        con.connect();
                                        String location = con.getHeaderField("Location");

                                        if (location != null && !location.equals("") && location.contains("https://www.mxtakatak.com/")) {
                                            String urls = location.split("/")[5];
                                            urls = urls.substring(0, urls.indexOf("?"));
                                            String newuuu = "https://mxshorts.akamaized.net/video/" + urls + "/download/1/h264_high_720.mp4";
                                            dismissMyDialog();
                                            startDownloadWithPreview(newuuu, "Mxtaktak_" + System.currentTimeMillis(), ".mp4");
                                        } else {
                                            dismissMyDialog();
                                        }
                                    } catch (Exception e) {
                                        dismissMyDialogErrortoast();
                                    }
                                }).start();
                            } else {
                                try {
                                    String urls = finalUrl3.split("/")[5];
                                    urls = urls.substring(0, urls.indexOf("?"));
                                    String newuuu = "https://mxshorts.akamaized.net/video/" + urls + "/download/1/h264_high_720.mp4";
                                    dismissMyDialog();
                                    startDownloadWithPreview(newuuu, "Mxtaktak_" + System.currentTimeMillis(), ".mp4");
                                } catch (Exception e) {
                                    dismissMyDialogErrortoast();
                                }
                            }
                        } else if (myURLIS.contains("test.com")) {
                            new CallgaanaData().execute(myURLIS);
                        } else if (myURLIS.contains("20min.ch")) {
                            if (!iUtils.isSocialMediaOn("20min.ch")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            Twenty_min_ch_Downloader twenty_min_ch_downloader = new Twenty_min_ch_Downloader(Mcontext, myURLIS);
                            twenty_min_ch_downloader.DownloadVideo();

                        } else if (myURLIS.contains("gaana")) {
                            if (!iUtils.isSocialMediaOn("gaana")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            String finalUrl = myURLIS;
                            new Thread(() -> {
                                HttpURLConnection con;
                                try {
                                    con = (HttpURLConnection) (new URL("https://tinyurl.com/f67p797b").openConnection());
                                    con.setInstanceFollowRedirects(false);
                                    con.connect();
                                    String location = con.getHeaderField("Location");

                                    AndroidNetworking.post(location)
                                            .addBodyParameter("url", finalUrl)
                                            .addBodyParameter("weburl", "https://video.infusiblecoder.com/")
                                            .setPriority(Priority.MEDIUM)
                                            .build()
                                            .getAsJSONObject(new JSONObjectRequestListener() {
                                                @Override
                                                public void onResponse(JSONObject response) {
                                                    dismissMyDialog();
                                                    String matag;
                                                    try {
                                                        JSONObject jsonObject = new JSONObject(response.toString());
                                                        matag = jsonObject.getJSONArray("songlinks").getJSONObject(0).getString("songurl");
                                                        startDownloadWithPreview(matag, "Gaana_" + System.currentTimeMillis(), ".mp3");
                                                    } catch (Exception e) {
                                                        dismissMyDialog();
                                                    }
                                                }
                                                @Override /**/
                                                public void onError(ANError error) {
                                                    dismissMyDialog();
                                                }
                                            });
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }).start();

                        } else if (myURLIS.contains("douyin")) {
                            if (!iUtils.isSocialMediaOn("douyin")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            String finalUrl = myURLIS;
                            new Thread(() -> {
                                HttpURLConnection con;
                                try {
                                    String[] idis = new String[0];
                                    if (!finalUrl.contains("/video/")) {
                                        con = (HttpURLConnection) (new URL(finalUrl).openConnection());
                                        con.setInstanceFollowRedirects(false);
                                        con.connect();
                                        String location = con.getHeaderField("Location");
                                        if (location != null && location.contains("?")) {
                                            location = location.split("\\?")[0];
                                        }
                                        if (location != null && location.contains("/video/")) {
                                            idis = location.split("/");
                                        }
                                    } else {
                                        idis = finalUrl.split("/");
                                    }

                                    AndroidNetworking.get("https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids=" + idis[idis.length - 1])
                                            .setPriority(Priority.MEDIUM)
                                            .build()
                                            .getAsJSONObject(new JSONObjectRequestListener() {
                                                @Override
                                                public void onResponse(JSONObject response) {
                                                    dismissMyDialog();
                                                    String matag;
                                                    try {
                                                        JSONObject jsonObject = new JSONObject(response.toString());
                                                        JSONArray itemlist = jsonObject.getJSONArray("item_list");
                                                        matag = itemlist.getJSONObject(0).getJSONObject("video").getJSONObject("play_addr").getJSONArray("url_list").getString(0);
                                                        matag = matag.replace("playwm", "play");
                                                        startDownloadWithPreview(matag, "Douyin_" + System.currentTimeMillis(), ".mp4");
                                                    } catch (Exception e) {
                                                        dismissMyDialog();
                                                    }
                                                }
                                                @Override /**/
                                                public void onError(ANError error) {
                                                    dismissMyDialogErrortoast();
                                                }
                                            });
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }).start();

                        } else if (myURLIS.contains("dailymotion") || myURLIS.contains("dai.ly")) {
                            if (!iUtils.isSocialMediaOn("dailymotion") && !iUtils.isSocialMediaOn("dai.ly")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            CalldlApisDataData(myURLIS, false);

                        } else if (myURLIS.contains("mashable.com")) {
                            if (!iUtils.isSocialMediaOn("mashable.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            MashableDownloader mashableDownloader = new MashableDownloader(Mcontext, myURLIS);
                            mashableDownloader.DownloadVideo();

                        } else if (myURLIS.contains("kickstarter")) {
                            if (!iUtils.isSocialMediaOn("kickstarter")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            KickstarterDownloader kickstarterDownloader = new KickstarterDownloader(Mcontext, myURLIS);
                            kickstarterDownloader.DownloadVideo();

                        } else if (myURLIS.contains("aparat")) {
                            if (!iUtils.isSocialMediaOn("aparat")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            AparatDownloader aparatDownloader = new AparatDownloader(Mcontext, myURLIS);
                            aparatDownloader.DownloadVideo();

                        } else if (myURLIS.contains("allocine.fr")) {
                            if (!iUtils.isSocialMediaOn("allocine.fr")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            AllocineDownloader allocineDownloader = new AllocineDownloader(Mcontext, myURLIS);
                            allocineDownloader.DownloadVideo();

                        } else if (myURLIS.contains("imdb.com")) {
                            if (!iUtils.isSocialMediaOn("imdb.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            new CallIMDBData().execute(myURLIS);

                        } else if (myURLIS.contains("camdemy")) {
                            if (!iUtils.isSocialMediaOn("camdemy")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            CalldlApisDataData(myURLIS, false);

                        } else if (myURLIS.contains("pinterest") || myURLIS.contains("pin.it")) {
                            if (!iUtils.isSocialMediaOn("pinterest") && !iUtils.isSocialMediaOn("pin.it")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            CalldlApisDataData(myURLIS, true);
                        } else if (myURLIS.contains("tumblr.com")) {
                            if (!iUtils.isSocialMediaOn("tumblr.com")) {
                                dismissMyDialogErrorToastForBlockedWebsitePanel();
                                return;
                            }
                            CalldlApisDataData(myURLIS, true);
                        } else {
                            CalldlApisDataData(myURLIS, true);
                        }

                        prefs = Mcontext.getSharedPreferences("AppConfig", MODE_PRIVATE);
                    } else {
                        dismissMyDialog();
                    }

                });
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void fallbackToFbWebview() {
        ((Activity) Mcontext).runOnUiThread(() -> {
            dismissMyDialog();
            Intent intent = new Intent(Mcontext, FacebookDownloadCloudBypassWebview_method_0_new.class);
            intent.putExtra("myvidurl", myURLIS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Mcontext.startActivity(intent);
        });
    }

    public static void getDataFromNewJetApi(String videoUrl, DataCallBackNewJetApi callBackNewJetApi) {

        if (!NewJetApi.isAllowedDomain(videoUrl)) {
            Log.d("isAllowedDomain: ", "unsupported domain " + videoUrl);
            callBackNewJetApi.onResult(false);
            return;
        }

        NewJetApi.sendNewJetApiDataRequest(Mcontext, videoUrl, encryptedData -> {
            try {
                if (encryptedData != null) {

                    Log.d("LOGClipboard111111 clip", "Response: " + encryptedData);

                    JSONObject jsonObject = new JSONObject(encryptedData);

                    if (jsonObject.has("error") && jsonObject.getBoolean("error")) {
                        String errorMessage = jsonObject.getString("message");
                        throw new IllegalArgumentException(errorMessage);
                    }

                    JSONArray mymedias = jsonObject.getJSONArray("medias");
                    String source = jsonObject.getString("source");
                    String nametitle = source + "_" + jsonObject.getString("author") + "_" +
                            System.currentTimeMillis();

                    Handler mainHandler = new Handler(Looper.getMainLooper());

                    Runnable runnable = () -> {
                        boolean isTikTokVideoDownloaded = false;
                        List<String> urls = new ArrayList<>();
                        List<String> exts = new ArrayList<>();

                        try {
                            for (int i = 0; i < mymedias.length(); i++) {
                                var mediaItem = mymedias.getJSONObject(i);
                                var mediaType = mediaItem.getString("type");
                                var mediaUrl = mediaItem.getString("url");

                                if (source.contains("tiktok") && mediaType.equals("video")) {
                                    if (isTikTokVideoDownloaded) {
                                        continue;
                                    }
                                    isTikTokVideoDownloaded = true;
                                }

                                urls.add(mediaUrl);
                                exts.add(mediaType.equals("video") ? ".mp4" : ".jpg");
                            }

                            if (!urls.isEmpty()) {
                                showMultiMediaPreviewDialog(urls, exts, nametitle);
                            }

                            callBackNewJetApi.onResult(true);
                        } catch (Exception e) {
                            e.printStackTrace();
                            callBackNewJetApi.onResult(false);
                        }
                    };

                    mainHandler.post(runnable);
                } else {

                    Handler mainHandler = new Handler(Looper.getMainLooper());
                    mainHandler.post(() -> {
                        callBackNewJetApi.onResult(false);
                    });
                }
            } catch (Exception e) {
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(() -> {
                    callBackNewJetApi.onResult(false);
                    e.printStackTrace();
                });
            }
        });
    }

    private static void getTrillerData(String url1) {
        new Thread(() -> {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) (new URL(url1).openConnection());
                con.setInstanceFollowRedirects(false);
                con.connect();
                String location = con.getHeaderField("Location");
                newurl = "https://social.triller.co/v1.5/api/videos/" + location.substring(location.indexOf("/video/") + 7);

                AndroidNetworking.get(newurl)
                        .setPriority(Priority.MEDIUM)
                        .build()
                        .getAsJSONObject(new JSONObjectRequestListener() {
                            @Override
                            public void onResponse(JSONObject response) {
                                dismissMyDialog();
                                String matag;
                                try {
                                    matag = response.getJSONArray("videos").getJSONObject(0).getString("video_url");
                                    startDownloadWithPreview(matag, "Triller_" + System.currentTimeMillis(), ".mp4");
                                } catch (Exception e) {
                                    dismissMyDialog();
                                }
                            }
                            @Override /**/
                            public void onError(ANError error) {
                                dismissMyDialog();
                            }
                        });
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private static void CallchingariData(String url) {
        try {
            String[] urlstr = url.split("=");

            AndroidNetworking.get("https://api.chingari.io/post/post_details/" + urlstr[1])
                    .setPriority(Priority.MEDIUM)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            dismissMyDialog();
                            String matag = "";
                            try {
                                JSONObject jsonObject = new JSONObject(response.toString());
                                JSONObject transcode = jsonObject.getJSONObject("data").getJSONObject("mediaLocation").getJSONObject("transcoded");

                                if (transcode.has("p1024")) matag = transcode.getString("p1024");
                                else if (transcode.has("p720")) matag = transcode.getString("p720");
                                else if (transcode.has("p480")) matag = transcode.getString("p480");

                                matag = "https://media.chingari.io" + matag;
                                startDownloadWithPreview(matag, "Chingari_" + System.currentTimeMillis(), ".mp4");
                            } catch (Exception e) {
                                dismissMyDialog();
                            }
                        }
                        @Override
                        public void onError(ANError error) {
                            dismissMyDialog();
                        }
                    });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showdownload_progress(int timeelipsed, long filesize) {
        Thread thread = new Thread() {
            @Override
            public void run() {

                String filesize2 = iUtils.getStringSizeLengthFile(filesize);

                NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(Mcontext);

                String contentTitle = "Downloaded";
                Intent notifyIntent = new Intent();
                PendingIntent notifyPendingIntent = PendingIntent.getActivity(Mcontext, DOWNLOAD_NOTIFICATION_ID, notifyIntent, PendingIntent.FLAG_UPDATE_CURRENT);

                NotificationCompat.Builder notificationBuilder = createNotificationBuilder("downloader_channel");
                notificationBuilder.setContentIntent(notifyPendingIntent);
                notificationBuilder.setTicker("Start downloading from the server");
                notificationBuilder.setOngoing(true);
                notificationBuilder.setAutoCancel(false);
                notificationBuilder.setSmallIcon(android.R.drawable.stat_sys_download);
                notificationBuilder.setContentTitle(contentTitle);

                notificationManagerCompat.notify(DOWNLOAD_NOTIFICATION_ID, notificationBuilder.build());

                notificationBuilder.setContentText("time elipsed: " + iUtils.formatDuration(timeelipsed) + " downloaded : " + filesize2);
                notificationBuilder.setProgress(100, timeelipsed, false);
                notificationManagerCompat.notify(DOWNLOAD_NOTIFICATION_ID, notificationBuilder.build());

                notificationBuilder.setContentTitle(contentTitle);
                notificationBuilder.setSmallIcon(android.R.drawable.stat_sys_download_done);
                notificationBuilder.setOngoing(false);
                notificationBuilder.setAutoCancel(true);
                notificationManagerCompat.notify(DOWNLOAD_NOTIFICATION_ID, notificationBuilder.build());

            }
        };

        thread.start();
    }

    private static NotificationCompat.Builder createNotificationBuilder(String channelId) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            String channelName = Mcontext.getString(R.string.app_name);
            NotificationChannel notificationChannel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setLightColor(Color.BLUE);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager notificationManager = (NotificationManager) Mcontext.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }
        return new NotificationCompat.Builder(Mcontext, channelId);
    }

    public static void dismissMyDialog() {

        if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
        }
    }

    public static void dismissMyDialogErrortoast() {

        if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
            Mcontext.runOnUiThread(() -> {
                iUtils.ShowToastError(Mcontext,
                        Mcontext.getResources().getString(R.string.somthing)
                );
            });
        }
    }

    public static void dismissMyDialogErrorToastForBlockedWebsitePanel() {

        if (pd != null && pd.isShowing() && !fromService && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
            Mcontext.runOnUiThread(() -> {
                iUtils.ShowToast(Mcontext,
                        Mcontext.getResources().getString(R.string.somthing_webiste_panele_block)
                );
            });
        }
    }

    public static void download(String url12) {
        String readLine;
        URL url = null;
        try {
            url = new URL(url12);
            URL url1 = new URL(url12);
            URLConnection connection = url1.openConnection();
            connection.connect();

            InputStream stream = connection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));

            while ((readLine = bufferedReader.readLine()) != null) {
                readLine = readLine.substring(readLine.indexOf("VideoObject"));
                String substring = readLine.substring(readLine.indexOf("thumbnailUrl") + 16);
                substring = substring.substring(0, substring.indexOf("\""));

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("ThumbnailURL: ");
                stringBuilder.append(substring);

                readLine = readLine.substring(readLine.indexOf("contentUrl") + 13);
                readLine = readLine.substring(0, readLine.indexOf("?"));
                stringBuilder = new StringBuilder();
                stringBuilder.append("ContentURL: ");
                stringBuilder.append(readLine);

                if (readLine == null) {
                    break;
                }
            }
            bufferedReader.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private static void addButtonToMainLayouttest_allvideo(final String videoTitle, String ytfile, String video_title) {
        try {
            Button btn = new Button(Mcontext);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(8, 8, 8, 8);
            btn.setLayoutParams(params);

            btn.setBackground(Mcontext.getResources().getDrawable(R.drawable.btn_bg_download_screen));
            btn.setTextColor(Color.WHITE);
            btn.setText(videoTitle);

            btn.setOnClickListener(v -> {
                if (windowManager2 != null) {
                    try {
                        windowManager2.removeView(mChatHeadView);
                    } catch (Exception e) {
                        Log.i("LOGClipboard111111", "error is " + e.getMessage());
                    }
                }

                if (videoTitle.equals("audio/mp4")) {
                    DownloadFileMain.startDownloading(Mcontext, ytfile, video_title + "_" + videoTitle, ".mp3");
                } else {
                    DownloadFileMain.startDownloading(Mcontext, ytfile, video_title + "_" + videoTitle, ".mp4");
                }
                dialog_quality_allvids.dismiss();
            });
            mainLayout.addView(btn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void callSnackVideoResult(String URL, String shortKey, String os, String sig, String client_key) {
        RetrofitApiInterface apiService = RetrofitClient.getClient();
        Call<JsonObject> callResult = apiService.getsnackvideoresult(URL + "&" + shortKey + "&" + os + "&sig=" + sig + "&" + client_key);

        callResult.enqueue(new Callback<>() {
            @Override
            public void onResponse(@NonNull Call<JsonObject> call, @NonNull retrofit2.Response<JsonObject> response) {
                assert response.body() != null;
                VideoUrl = response.body().getAsJsonObject("photo").get("main_mv_urls").getAsJsonArray().get(0).getAsJsonObject().get("url").getAsString();
                if (!VideoUrl.equals("")) {
                    try {
                        dismissMyDialog();
                        startDownloadWithPreview(VideoUrl, "snackvideo_" + System.currentTimeMillis(), ".mp4");
                        VideoUrl = "";
                    } catch (Exception document2) {
                        document2.printStackTrace();
                    }
                }
            }
            @Override
            public void onFailure(@NonNull Call<JsonObject> call, @NonNull Throwable t) {
                dismissMyDialog();
            }
        });
    }

    @SuppressLint("NewApi")
    public static void getSnackVideoData(String str, Context vc) {
        URI uri;
        try {
            uri = new URI(str);
        } catch (Exception e) {
            e.printStackTrace();
            uri = null;
            dismissMyDialog();
        }
        assert uri != null;
        String[] uripath = uri.getPath().split("/");
        String uripath2 = uripath[uripath.length - 1];
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("mod=OnePlus(ONEPLUS A5000)");
        arrayList.add("lon=0");
        arrayList.add("country_code=in");
        String mydid = "did=" + "ANDROID_" + Settings.Secure.getString(vc.getContentResolver(), "android_id");

        arrayList.add(mydid);
        arrayList.add("app=1");
        arrayList.add("oc=UNKNOWN");
        arrayList.add("egid=");
        arrayList.add("ud=0");
        arrayList.add("c=GOOGLE_PLAY");
        arrayList.add("sys=KWAI_BULLDOG_ANDROID_9");
        arrayList.add("appver=2.7.1.153");
        arrayList.add("mcc=0");
        arrayList.add("language=en-in");
        arrayList.add("lat=0");
        arrayList.add("ver=2.7");

        ArrayList<String> arrayList2 = new ArrayList<>(arrayList);
        String shortKey = "shortKey=" + uripath2;
        arrayList2.add(shortKey);

        String os = "os=" + "android";
        arrayList2.add(os);
        String client_key = "client_key=" + "8c46a905";
        arrayList2.add(client_key);

        try {
            Collections.sort(arrayList2);
        } catch (Exception str225) {
            str225.printStackTrace();
            dismissMyDialog();
        }

        String clockData = CPU.getClockData(Mcontext, TextUtils.join("", arrayList2).getBytes(StandardCharsets.UTF_8), 0);
        String nowaterurl = "https://g-api.snackvideo.com/rest/bulldog/share/get?" + TextUtils.join("&", arrayList);
        callSnackVideoResult(nowaterurl, shortKey, os, clockData, client_key);
    }


    private static void splitDataToVideoAndAudio_video(List<Video> videoList, RecyclerView recyclerView_video, RecyclerView recyclerView_audio, QualityBottomsheetAdapter qualityBottomsheetAdapter, String extractor) {
        List<Video> videoList_sub = new ArrayList<>();
        List<Video> videoList_sub_video = new ArrayList<>();
        for (int i = 0; i < videoList.size(); i++) {
            if (videoList.get(i).getProtocol().contains("http") && !videoList.get(i).getProtocol().contains("http_dash_segments") && !videoList.get(i).getURL().contains(".m3u8") && !videoList.get(i).getProtocol().contains("m3u8_native")) {
                if (videoList.get(i).getEXT().equals("m4a") || videoList.get(i).getEXT().equals("mp3") || videoList.get(i).getEXT().equals("wav")) {
                    videoList_sub.add(videoList.get(i));
                } else if (videoList.get(i).getEXT().equals("mp4") || videoList.get(i).getEXT().equals("mpeg")) {
                    videoList_sub_video.add(videoList.get(i));
                }
            }
        }
        Collections.reverse(videoList_sub_video);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, videoList_sub_video.get(0).getExtractor(), false, videoList_sub_video, true);
        recyclerView_video.setAdapter(qualityBottomsheetAdapter);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, videoList_sub.get(0).getExtractor(), false, videoList_sub, true);
        recyclerView_audio.setAdapter(qualityBottomsheetAdapter);
    }

    private static void splitDataToVideoAndAudio_format(List<Format> formatList, RecyclerView recyclerView_video, RecyclerView recyclerView_audio, QualityBottomsheetAdapter qualityBottomsheetAdapter, String extractor) {
        List<Format> formatList_sub = new ArrayList<>();
        List<Format> formatList_sub_video = new ArrayList<>();
        for (int i = 0; i < formatList.size(); i++) {
            if (formatList.get(i).getProtocol().contains("http") && !formatList.get(i).getProtocol().contains("http_dash_segments") && !formatList.get(i).getURL().contains(".m3u8") && !formatList.get(i).getProtocol().contains("m3u8_native")) {
                if (formatList.get(i).getAcodec() != null && !formatList.get(i).getAcodec().equals("none")) {
                    if (formatList.get(i).getEXT().equals("m4a") || formatList.get(i).getEXT().equals("mp3") || formatList.get(i).getEXT().equals("wav")) {
                        formatList_sub.add(formatList.get(i));
                    } else if (formatList.get(i).getEXT().equals("mp4") || formatList.get(i).getEXT().equals("unknown_video") || formatList.get(i).getEXT().equals("mpeg")) {
                        formatList_sub_video.add(formatList.get(i));
                    }
                } else {
                    if (formatList.get(i).getEXT().equals("m4a") || formatList.get(i).getEXT().equals("mp3") || formatList.get(i).getEXT().equals("wav")) {
                        formatList_sub.add(formatList.get(i));
                    } else if (formatList.get(i).getEXT().equals("mp4") || formatList.get(i).getEXT().equals("unknown_video") || formatList.get(i).getEXT().equals("mpeg")) {
                        formatList_sub_video.add(formatList.get(i));
                    }
                    formatList.get(i).setFormat("" + formatList.get(i).getFormat());
                }
            }
        }
        Collections.reverse(formatList_sub_video);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, formatList_sub_video, extractor, false);
        recyclerView_video.setAdapter(qualityBottomsheetAdapter);

        qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, formatList_sub, extractor, false);
        recyclerView_audio.setAdapter(qualityBottomsheetAdapter);
    }

    @Keep
    public static void CalldlApisDataData(String url, boolean hasQualityOption) {
        callDlApiNew(url);
    }

    static void callM3u8Backup(String url) {
        AndroidNetworking.get("https://api.m3u8-downloader.com/api/parse?url=" + url)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject obj = new JSONObject();
                            JSONArray jsonArray = new JSONArray();
                            jsonArray.put(0, response);
                            obj.put("url", "" + url);
                            obj.put("videos", jsonArray);
                            parseCalldlApisDataData(obj, url, true);
                        } catch (Exception e) {
                            dismissMyDialogErrortoast();
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onError(ANError error) {
                        dismissMyDialogErrortoast();
                    }
                });
    }

    static void callBackup(String url) {
        AndroidNetworking.get("http://199.192.20.82:9191/api/info?url=" + url + "&flatten=True")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        parseCalldlApisDataData(response, url, true);
                    }
                    @Override
                    public void onError(ANError error) {
                        dismissMyDialogErrortoast();
                    }
                });
    }


    static void callDlApiNew(String url) {
        Executors.newSingleThreadExecutor().submit(() -> {
            try {
                streamInfo = YoutubeDL.getInstance().getInfo(url);
                Mcontext.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        parseCalldlApisLocalDataData(streamInfo, url);
                    }
                });
            } catch (Throwable e) {
                callBackup(url);
            }
        });
    }


    @Keep
    public static void parseCalldlApisLocalDataData(VideoInfo response, String url) {
        try {
            dismissMyDialog();

            View view = LayoutInflater.from(Mcontext).inflate(R.layout.bottomsheet_quality_layout, null);
            String[] dataSize;
            Button btncancel_bottomsheet = view.findViewById(R.id.btncancel_bottomsheet);
            Button btnopen_bottomsheet = view.findViewById(R.id.btnopen_bottomsheet);
            TextView source_bottomsheet = view.findViewById(R.id.source_bottomsheet);
            TextView title_bottomsheet = view.findViewById(R.id.bottomsheet_title);
            TextView duration_bottomsheet = view.findViewById(R.id.bottomsheet_duration);
            ImageView thumb_bottomsheet = view.findViewById(R.id.bottomsheet_thumbnail);
            TextView bottomsheet_description = view.findViewById(R.id.bottomsheet_description);

            TabLayout tabLayout = view.findViewById(R.id.tab_layout);
            ViewPager viewPager = view.findViewById(R.id.view_pager);

            tabLayout.setTabTextColors(ContextCompat.getColor(Mcontext, R.color.tab_unselected_text_color),
                    ContextCompat.getColor(Mcontext, R.color.tab_selected_text_color));

            QualityPagerAdapter pagerAdapter = new QualityPagerAdapter(
                    Mcontext,
                    response.getExtractor(),
                    response.getTitle(),
                    response.getId(),
                    url
            );

            viewPager.setAdapter(pagerAdapter);
            tabLayout.setupWithViewPager(viewPager);
            tabLayout.getTabAt(0).setText("Video");
            tabLayout.getTabAt(1).setText("Audio");

            if (response.getFormats().size() > 0) {
                dataSize = splitDataToVideoAndAudio_dlapiformat(response.getFormats(), pagerAdapter, response.getExtractor(), response.getTitle(), response.getId(), url);
            }

            BottomSheetDialog dialog = new BottomSheetDialog(Mcontext);

            if (!TextUtils.isEmpty(response.getDescription())) {
                String descriptiontext = "Description: " + String.format("%s", response.getDescription());
                bottomsheet_description.setText(Html.fromHtml(descriptiontext), TextView.BufferType.SPANNABLE);
            }
            if (!TextUtils.isEmpty(response.getExtractor())) {
                String styledText = "";
                switch (response.getExtractor()) {
                    case "youtube":
                        styledText = "Source: <font color='red'>YTD</font>";
                        break;
                    case "soundcloud":
                        styledText = "Source: <font color='red'>SCloud</font>";
                        break;
                    case "facebook":
                        styledText = "Source: <font color='red'>SocialF</font>";
                        break;
                    default:
                        styledText = "Source: <font color='red'>" + response.getExtractor() + "</font>";
                        break;
                }
                source_bottomsheet.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);
            }

            if (response.getDuration() > 0) {
                String mystring = response.getDuration() + "";
                String[] correctstring = mystring.split("\\.");
                long hours = Long.parseLong(correctstring[0]) / 3600;
                long minutes = (Long.parseLong(correctstring[0]) % 3600) / 60;
                long seconds = Long.parseLong(correctstring[0]) % 60;
                String durationStyledText = "Duration: <font color='red'>" + String.format("%02d:%02d:%02d", hours, minutes, seconds) + "</font>";
                duration_bottomsheet.setText(Html.fromHtml(durationStyledText), TextView.BufferType.SPANNABLE);
            }

            if (!TextUtils.isEmpty(response.getTitle())) {
                String titleStyledText = "Title: <font color='red'>" + String.format("%s", response.getTitle()) + "</font>";
                title_bottomsheet.setText(Html.fromHtml(titleStyledText), TextView.BufferType.SPANNABLE);
            }

            if (!TextUtils.isEmpty(response.getThumbnail())) {
                GlideApp.with(Mcontext)
                        .load(response.getThumbnail())
                        .placeholder(R.drawable.ic_appicon_pro)
                        .into(thumb_bottomsheet);
            }

            btncancel_bottomsheet.setOnClickListener(v -> dialog.cancel());

            btnopen_bottomsheet.setOnClickListener(v -> {
                if (dialog.getBehavior().getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    dialog.getBehavior().setState(BottomSheetBehavior.STATE_COLLAPSED);
                    dialog.getBehavior().setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);
                    btnopen_bottomsheet.animate().rotationBy(180f).start();
                } else {
                    dialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
                    dialog.getBehavior().setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);
                    btnopen_bottomsheet.animate().rotationBy(180f).start();
                }
            });

            dialog.setContentView(view);
            dialog.show();
            dismissMyDialog();

        } catch (Exception str2) {
            dismissMyDialogErrortoast();
        }
    }

    private static String[] splitDataToVideoAndAudio_dlapiformat(ArrayList<VideoFormat> videoList, QualityPagerAdapter pagerAdapter, String extractor, String title, String id, String url) {
        List<VideoFormat> videoList_sub = new ArrayList<>();
        List<VideoFormat> videoList_sub_video = new ArrayList<>();

        for (int i = 0; i < videoList.size(); i++) {
            String myext = videoList.get(i).getExt();
            if (myext.equals("m4a") || myext.equals("mp3") || myext.equals("wav") ||
                    (myext.equals("webm") && !videoList.get(i).getAcodec().equals("none"))) {
                videoList_sub.add(videoList.get(i));
            } else if (myext.equals("mp4") || myext.equals("mpeg") ||
                    (myext.equals("webm") && videoList.get(i).getAcodec().equals("none"))) {
                videoList_sub_video.add(videoList.get(i));
            }
        }

        Collections.reverse(videoList_sub_video);

        pagerAdapter.setVideoData(videoList_sub_video);
        pagerAdapter.setAudioData(videoList_sub);

        String[] dataSize = {"n", "n"};
        if (videoList_sub_video.size() > 0) dataSize[0] = "y";
        if (videoList_sub.size() > 0) dataSize[1] = "y";
        return dataSize;
    }

    @Keep
    public static void parseCalldlApisDataData(JSONObject response, String url, boolean isFromBackup) {
        try {
            try {
                if (!response.getString("error").equals("")) {
                    if (isFromBackup) {
                        dismissMyDialogErrortoast();
                    } else {
                        callBackup(url);
                    }
                }
            } catch (Exception e) {

                Gson gson = new Gson();
                DLDataParser gsonObj = gson.fromJson(response.toString(), DLDataParser.class);

                View view = LayoutInflater.from(Mcontext).inflate(R.layout.bottomsheet_quality_layout, null);

                Button btncancel_bottomsheet = view.findViewById(R.id.btncancel_bottomsheet);
                Button btnopen_bottomsheet = view.findViewById(R.id.btnopen_bottomsheet);
                TextView source_bottomsheet = view.findViewById(R.id.source_bottomsheet);
                TextView title_bottomsheet = view.findViewById(R.id.bottomsheet_title);
                TextView duration_bottomsheet = view.findViewById(R.id.bottomsheet_duration);
                ImageView thumb_bottomsheet = view.findViewById(R.id.bottomsheet_thumbnail);

                RecyclerView recyclerView = view.findViewById(R.id.recqualitybottomsheet);
                recyclerView.setLayoutManager(new LinearLayoutManager(Mcontext));

                RecyclerView recyclerView_audio = view.findViewById(R.id.recqualitybottomsheet_aud);
                recyclerView_audio.setHasFixedSize(true);
                recyclerView_audio.setLayoutManager(new LinearLayoutManager(Mcontext));

                QualityBottomsheetAdapter qualityBottomsheetAdapter = null;

                if (response.getJSONArray("videos").length() > 1) {

                    if (response.getJSONArray("videos").getJSONObject(0).has("protocol")) {
                        splitDataToVideoAndAudio_video(gsonObj.getVideos(), recyclerView, recyclerView_audio, qualityBottomsheetAdapter, gsonObj.getVideos().get(0).getExtractor());
                    }

                    BottomSheetDialog dialog = new BottomSheetDialog(Mcontext);

                    if (response.getJSONArray("videos").getJSONObject(0).has("extractor")) {
                        String styledText = "";
                        switch (gsonObj.getVideos().get(0).getExtractor()) {
                            case "youtube": styledText = "Source: <font color='red'>YTD</font>"; break;
                            case "soundcloud": styledText = "Source: <font color='red'>SCloud</font>"; break;
                            case "facebook": styledText = "Source: <font color='red'>SocialF</font>"; break;
                            default: styledText = "Source: <font color='red'>" + gsonObj.getVideos().get(0).getExtractor() + "</font>"; break;
                        }
                        source_bottomsheet.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);
                    }

                    if (response.getJSONArray("videos").getJSONObject(0).has("duration")) {
                        String mystring = gsonObj.getVideos().get(0).getDuration() + "";
                        String[] correctstring = mystring.split("\\.");
                        long hours = Long.parseLong(correctstring[0]) / 3600;
                        long minutes = (Long.parseLong(correctstring[0]) % 3600) / 60;
                        long seconds = Long.parseLong(correctstring[0]) % 60;
                        String DurationstyledText = "Duration: <font color='red'>" + String.format("%02d:%02d:%02d", hours, minutes, seconds) + "</font>";
                        duration_bottomsheet.setText(Html.fromHtml(DurationstyledText), TextView.BufferType.SPANNABLE);
                    }

                    if (response.getJSONArray("videos").getJSONObject(0).has("title")) {
                        String titletyledText = "Title: <font color='red'>" + String.format("%s", gsonObj.getVideos().get(0).getTitle()) + "</font>";
                        title_bottomsheet.setText(Html.fromHtml(titletyledText), TextView.BufferType.SPANNABLE);
                    }

                    if (response.getJSONArray("videos").getJSONObject(0).has("thumbnail")) {
                        GlideApp.with(Mcontext).load(gsonObj.getVideos().get(0).getThumbnail()).placeholder(R.drawable.ic_appicon_pro).into(thumb_bottomsheet);
                    }

                    btncancel_bottomsheet.setOnClickListener(v -> dialog.cancel());
                    btnopen_bottomsheet.setOnClickListener(v -> {
                        dialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
                        dialog.getBehavior().setPeekHeight(BottomSheetBehavior.PEEK_HEIGHT_AUTO);
                    });

                    dialog.setContentView(view);
                    dialog.show();
                    dismissMyDialog();

                } else {

                    if (response.getJSONArray("videos").getJSONObject(0).has("formats")) {
                        splitDataToVideoAndAudio_format(gsonObj.getVideos().get(0).getFormats(), recyclerView, recyclerView_audio, qualityBottomsheetAdapter, gsonObj.getVideos().get(0).getExtractor());
                    } else {
                        if (response.getJSONArray("videos").getJSONObject(0).has("protocol")) {
                            String ishttp = response.getJSONArray("videos").getJSONObject(0).getString("protocol");
                            if (ishttp.contains("http")) {
                                qualityBottomsheetAdapter = new QualityBottomsheetAdapter(Mcontext, gsonObj.getVideos().get(0).getURL(), gsonObj.getVideos().get(0).getExtractor(), true);
                                recyclerView.setAdapter(qualityBottomsheetAdapter);
                            }
                        }
                    }

                    if (!((Activity) Mcontext).isFinishing()) {
                        BottomSheetDialog dialog = new BottomSheetDialog(Mcontext);
                        if (response.getJSONArray("videos").getJSONObject(0).has("extractor")) {
                            String styledText = "";
                            switch (gsonObj.getVideos().get(0).getExtractor()) {
                                case "youtube": styledText = "Source: <font color='red'>YTD</font>"; break;
                                case "soundcloud": styledText = "Source: <font color='red'>SCloud</font>"; break;
                                case "facebook": styledText = "Source: <font color='red'>SocialF</font>"; break;
                                default: styledText = "Source: <font color='red'>" + gsonObj.getVideos().get(0).getExtractor() + "</font>"; break;
                            }
                            source_bottomsheet.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);
                        }

                        if (response.getJSONArray("videos").getJSONObject(0).has("duration")) {
                            String mystring = gsonObj.getVideos().get(0).getDuration() + "";
                            String[] correctstring = mystring.split("\\.");
                            long hours = Long.parseLong(correctstring[0]) / 3600;
                            long minutes = (Long.parseLong(correctstring[0]) % 3600) / 60;
                            long seconds = Long.parseLong(correctstring[0]) % 60;
                            String DurationstyledText = "Duration: <font color='red'>" + String.format("%02d:%02d:%02d", hours, minutes, seconds) + "</font>";
                            duration_bottomsheet.setText(Html.fromHtml(DurationstyledText), TextView.BufferType.SPANNABLE);
                        }

                        if (response.getJSONArray("videos").getJSONObject(0).has("title")) {
                            String titletyledText = "Title: <font color='red'>" + String.format("%s", gsonObj.getVideos().get(0).getTitle()) + "</font>";
                            title_bottomsheet.setText(Html.fromHtml(titletyledText), TextView.BufferType.SPANNABLE);
                        }

                        if (response.getJSONArray("videos").getJSONObject(0).has("thumbnail")) {
                            GlideApp.with(Mcontext).load(gsonObj.getVideos().get(0).getThumbnail()).placeholder(R.drawable.ic_appicon_pro).into(thumb_bottomsheet);
                        }

                        btncancel_bottomsheet.setOnClickListener(v -> dialog.cancel());
                        dialog.setContentView(view);
                        dialog.show();
                    }
                    dismissMyDialog();
                }
            }
        } catch (Exception str2) {
            dismissMyDialogErrortoast();
        }
    }

    static class QualityPagerAdapter extends PagerAdapter {
        private List<VideoFormat> videoData = new ArrayList<>();
        private List<VideoFormat> audioData = new ArrayList<>();
        private Context context;
        private String extractor;
        private String title;
        private String id;
        private String url;

        public QualityPagerAdapter(Context context, String extractor, String title, String id, String url) {
            this.context = context;
            this.extractor = extractor;
            this.title = title;
            this.id = id;
            this.url = url;
        }

        public void setVideoData(List<VideoFormat> videoData) {
            this.videoData = videoData;
        }

        public void setAudioData(List<VideoFormat> audioData) {
            this.audioData = audioData;
        }

        @Override
        public int getCount() { return 2; }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) { return view == object; }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view;
            if (position == 0) {
                view = inflater.inflate(R.layout.video_quality_layout, container, false);
                RecyclerView recyclerView = view.findViewById(R.id.recqualitybottomsheet);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                QualityBottomsheetAdapter adapter = new QualityBottomsheetAdapter((Activity) context, extractor, false, videoData, true, title, id, url, false);
                recyclerView.setAdapter(adapter);
            } else {
                view = inflater.inflate(R.layout.audio_quality_layout, container, false);
                RecyclerView recyclerView = view.findViewById(R.id.recqualitybottomsheet_aud);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
                QualityBottomsheetAdapter adapter = new QualityBottomsheetAdapter((Activity) context, extractor, false, audioData, true, title, id, url, true);
                recyclerView.setAdapter(adapter);
            }
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }
    }

    private static class GetInstagramVideo extends AsyncTask<String, Void, Document> {
        Document doc;
        @Override
        protected Document doInBackground(String... urls) {
            try {
                doc = Jsoup.connect(urls[0]).get();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return doc;
        }
        protected void onPostExecute(Document result) {
            dismissMyDialog();
            try {
                String URL = result.select("meta[property=\"og:video\"]").last().attr("content");
                Title = result.title();
                startDownloadWithPreview(URL, Title + ".mp4", ".mp4");
            } catch (Exception e) {
                Mcontext.runOnUiThread(() -> {
                    iUtils.ShowToastError(Mcontext, Mcontext.getResources().getString(R.string.somthing));
                });
            }
        }
    }

    private static class callGetRoposoData extends AsyncTask<String, Void, Document> {
        Document ShareChatDoc;
        protected void onPreExecute() { super.onPreExecute(); }
        protected Document doInBackground(String... strArr) {
            try { this.ShareChatDoc = Jsoup.connect(strArr[0]).get(); }
            catch (Exception strArr2) { strArr2.printStackTrace(); }
            return this.ShareChatDoc;
        }
        protected void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                String html = document.select("script[id=\"__NEXT_DATA__\"]").last().html();
                if (!html.equals("")) {
                    VideoUrl = new JSONObject(html).getJSONObject("props").getJSONObject("pageProps").getJSONObject("meta").getString("og:video");
                    if (VideoUrl != null && !VideoUrl.equals("")) {
                        startDownloadWithPreview(VideoUrl, "roposo_" + System.currentTimeMillis() + ".mp4", ".mp4");
                        return;
                    }
                }
            } catch (Exception document22) {
                dismissMyDialog();
            }
        }
    }

    public static class CallMitronData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            String str;
            try {
                String str2 = strArr[0];
                if (str2.contains("api.mitron.tv")) {
                    String[] split = str2.split("=");
                    str = "https://web.mitron.tv/video/" + split[split.length - 1];
                } else { str = strArr[0]; }
                this.RoposoDoc = Jsoup.connect(str).get();
            } catch (IOException e) {
                dismissMyDialog();
            }
            return this.RoposoDoc;
        }

        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                String html = document.select("script[id=\"__NEXT_DATA__\"]").last().html();
                if (!html.equals("")) {
                    this.VideoUrl = String.valueOf(new JSONObject(html).getJSONObject("props").getJSONObject("pageProps").getJSONObject("video").get("videoUrl"));
                    if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                        startDownloadWithPreview(VideoUrl, "mitron_" + System.currentTimeMillis(), ".mp4");
                        return;
                    }
                    return;
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CallIMDBData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); }
            catch (IOException e) { dismissMyDialog(); }
            return this.RoposoDoc;
        }

        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                String html = document.select("script[id=\"__NEXT_DATA__\"]").last().html();
                if (!html.equals("")) {
                    JSONArray listOfUrls = new JSONObject(html).getJSONObject("props").getJSONObject("pageProps").getJSONObject("videoPlaybackData").getJSONObject("video").getJSONArray("playbackURLs");
                    ArrayList<String> arrayList = new ArrayList<>();
                    ArrayList<String> qualityArrayList = new ArrayList<>();
                    for (int i = 1; i < listOfUrls.length(); i++) {
                        arrayList.add(listOfUrls.getJSONObject(i).getString("url"));
                        qualityArrayList.add(listOfUrls.getJSONObject(i).getJSONObject("displayName").getString("value"));
                    }
                    CharSequence[] charSequenceArr = qualityArrayList.toArray(new String[0]);
                    if (!Mcontext.isFinishing()) {
                        new AlertDialog.Builder(Mcontext).setTitle("Quality!")
                                .setItems(charSequenceArr, (dialogInterface, i) -> startDownloadWithPreview(arrayList.get(i), "IMDB_" + System.currentTimeMillis(), ".mp4"))
                                .setPositiveButton("OK", (dialogInterface, i) -> dismissMyDialog()).setCancelable(false).show();
                    }
                } else {
                    dismissMyDialogErrortoast();
                }
            } catch (Throwable f) {
                dismissMyDialogErrortoast();
            }
        }
    }

    public static class CallJoshData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        String link = "";

        String getVideoIdjosh(String link) {
            if (link.contains("?")) {
                link = link.split("\\?")[0];
                link = (link.contains("video")) ? link.substring(link.indexOf("video")) : link.substring(link.indexOf("content"));
                link = link.substring(link.indexOf("/") + 1);
            } else {
                link = (link.contains("video")) ? link.substring(link.indexOf("video")) : link.substring(link.indexOf("content"));
                link = link.substring(link.indexOf("/") + 1);
            }
            return link;
        }

        public Document doInBackground(String... strArr) {
            try { link = getVideoIdjosh(strArr[0]); } catch (Exception e) { }
            return this.RoposoDoc;
        }

        public void onPostExecute(Document document) {
            try {
                JSONObject snackvideoDoc = new JSONObject("{\"method\": \"GET\",\"url\": \"https://api-internal.myjosh.in/share/content/" + link + "\",\"platform\": \"PWA\"}");
                AndroidNetworking.post("https://share.myjosh.in/webview/apiwbody")
                        .addJSONObjectBody(snackvideoDoc)
                        .setPriority(Priority.MEDIUM)
                        .build()
                        .getAsJSONObject(new JSONObjectRequestListener() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    dismissMyDialog();
                                    VideoUrl = response.getJSONObject("data").getString("mp4_url");
                                    String myurldocument = VideoUrl.replace("_r4_wmj_480.mp4", ".mp4");
                                    startDownloadWithPreview(myurldocument, "joshvideo_" + System.currentTimeMillis(), ".mp4");
                                } catch (Exception document2) {
                                    dismissMyDialog();
                                }
                            }
                            @Override
                            public void onError(ANError error) {
                                dismissMyDialogErrortoast();
                            }
                        });
            } catch (Exception eee) {
                dismissMyDialog();
            }
        }
    }

    public static class CallRizzleData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); } catch (IOException e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                String html = document.select("script[id=\"__NEXT_DATA__\"]").last().html();
                if (!html.equals("")) {
                    this.VideoUrl = String.valueOf(new JSONObject(html).getJSONObject("props").getJSONObject("pageProps").getJSONObject("post").getJSONObject("video").get("originalUrl"));
                    if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                        startDownloadWithPreview(VideoUrl, "rizzlevideo_" + System.currentTimeMillis(), ".mp4");
                        return;
                    }
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CallIfunnyData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).userAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36").get(); }
            catch (Exception e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                this.VideoUrl = document.select("meta[property=\"og:video:url\"]").last().attr("content");
                if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                    startDownloadWithPreview(VideoUrl, "ifunnyvideo_" + System.currentTimeMillis(), ".mp4");
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CallBoloindyaData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); } catch (Exception e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                Iterator it = document.getElementsByTag("script").iterator();
                while (it.hasNext()) {
                    Element element = (Element) it.next();
                    if (element.data().contains("videoFileCDN")) {
                        for (String str : element.data().split(StringUtils.LF)) {
                            if (str.contains("var videoFileCDN=\"https")) {
                                this.VideoUrl = str.split("=")[1].replace("\"", "").replace(";", "");
                            }
                        }
                    }
                }
                if (this.VideoUrl.startsWith("//")) this.VideoUrl = "https:" + this.VideoUrl;
                if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                    startDownloadWithPreview(VideoUrl, "Boloindyavideo_" + System.currentTimeMillis(), ".mp4");
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CallhindData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); } catch (Exception e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                for (Element element : document.getElementsByTag("script")) {
                    if (element.data().contains("window.__STATE__")) {
                        String replace = element.html().replace("window.__STATE__", "").replace(";", "").replace("=", "");
                        this.VideoUrl = String.valueOf(new JSONObject(new JSONObject(new JSONArray("[" + replace + "]").get(0).toString()).getJSONObject("feed").getJSONArray("feed").get(0).toString()).get("download_media"));
                        if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                            startDownloadWithPreview(VideoUrl, "hindvideo_" + System.currentTimeMillis(), ".mp4");
                            return;
                        }
                    }
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CalldubsmashData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); } catch (Exception e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                this.VideoUrl = document.select("video").last().attr("src");
                if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                    startDownloadWithPreview(VideoUrl, "dubsmashvideo_" + System.currentTimeMillis(), ".mp4");
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CalltumblerData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); } catch (Exception e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                this.VideoUrl = document.select("source").last().attr("src");
                if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                    startDownloadWithPreview(VideoUrl, "tumbler_" + System.currentTimeMillis(), ".mp4");
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CallRedditData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            try { this.RoposoDoc = Jsoup.connect(strArr[0]).get(); } catch (Exception e) { }
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                this.VideoUrl = document.select("a").get(10).attr("href");
                if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                    startDownloadWithPreview(VideoUrl, "Reddit_" + System.currentTimeMillis(), ".mp4");
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CalllinkedinData extends AsyncTask<String, Void, Document> {
        private final Context context;
        private Document roposoDoc;
        private String videoUrl = "";

        public CalllinkedinData(Context context) { this.context = context; }

        @Override
        protected Document doInBackground(String... strArr) {
            try {
                roposoDoc = Jsoup.connect(strArr[0])
                        .header("authority", "www.linkedin.com")
                        .header("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
                        .get();
            } catch (Exception e) {
                dismissMyDialogErrortoast();
            }
            return roposoDoc;
        }

        @Override
        protected void onPostExecute(Document document) {
            try {
                Elements elements = document.select("script");
                int totalElements = elements.size();
                int currentIndex = 0;
                boolean isElementFound = false;

                for (Element element : elements) {
                    currentIndex++;
                    if ("application/ld+json".equals(element.attr("type"))) {
                        JSONObject obj = new JSONObject(element.html());
                        String typeOfElement = obj.getString("@type");

                        if (typeOfElement.contains("SocialMediaPosting")) {
                            new HandleImageDownloadTask().execute(obj);
                            isElementFound = true;
                        } else if (typeOfElement.contains("VideoObject")) {
                            handleVideoDownload(obj);
                            isElementFound = true;
                        }
                    }
                    if (currentIndex == totalElements) {
                        if (!isElementFound) {
                            dismissMyDialogErrortoast();
                        } else {
                            dismissMyDialog();
                        }
                    }
                }
            } catch (Exception e) {
                try {
                    videoUrl = document.select("video").first().attr("data-sources");
                    JSONArray jsonArray = new JSONArray(videoUrl);
                    ArrayList<String> arrayList = new ArrayList<>();
                    arrayList.add(jsonArray.getJSONObject(0).getString("src"));
                    arrayList.add(jsonArray.getJSONObject(1).getString("src"));

                    CharSequence[] charSequenceArr = new CharSequence[arrayList.size()];
                    charSequenceArr[0] = "Low quality";
                    charSequenceArr[1] = "High quality";
                    dismissMyDialog();

                    if (!Mcontext.isFinishing()) {
                        new AlertDialog.Builder(Mcontext).setTitle("Quality!").setItems(charSequenceArr, (dialogInterface, i) -> startDownloadWithPreview(arrayList.get(i), "Linkedin_" + System.currentTimeMillis(), ".mp4")).setPositiveButton("OK", (dialogInterface, i) -> dismissMyDialog()).setCancelable(false).show();
                    }
                } catch (Exception unused) {
                    dismissMyDialogErrortoast();
                }
            }
        }

        private String getImageExtension(String imageUrl) {
            try {
                Connection.Response response = Jsoup.connect(imageUrl).ignoreContentType(true).execute();
                String contentType = response.header("Content-Type");
                if (contentType != null) {
                    if (contentType.contains("image/png")) return ".png";
                    else if (contentType.contains("image/jpeg") || contentType.contains("image/jpg")) return ".jpg";
                    else if (contentType.contains("image/gif")) return ".gif";
                }
            } catch (IOException e) { }
            return null;
        }

        private void handleVideoDownload(JSONObject obj) {
            try {
                videoUrl = obj.getString("contentUrl");
                startDownloadWithPreview(videoUrl, "LinkedIn_video_" + System.currentTimeMillis(), ".mp4");
            } catch (Exception e) { }
        }

        private JSONObject getJsonData(String url) {
            try {
                String json = Jsoup.connect(url).ignoreContentType(true).execute().body();
                return new JSONObject(json);
            } catch (Exception e) { }
            return new JSONObject();
        }

        private JSONArray getJsonArrayFrom(String url) {
            try {
                String json = Jsoup.connect(url).ignoreContentType(true).execute().body();
                return new JSONObject(json).getJSONArray("pages");
            } catch (Exception e) { }
            return new JSONArray();
        }

        private class HandleImageDownloadTask extends AsyncTask<JSONObject, Void, Void> {
            @Override
            protected Void doInBackground(JSONObject... objs) {
                try {
                    JSONObject obj = objs[0];
                    if (obj.has("sharedContent") && obj.getJSONObject("sharedContent").has("url")) {
                        String playlistUrl = obj.getJSONObject("sharedContent").getString("url");
                        JSONObject playlistJson = getJsonData(playlistUrl);
                        JSONArray arrayJson = playlistJson.getJSONArray("perResolutions");
                        String imageManifestUrl = arrayJson.getJSONObject(arrayJson.length() - 1).getString("imageManifestUrl");

                        JSONArray jsonImages = getJsonArrayFrom(imageManifestUrl);
                        List<String> imgUrls = new ArrayList<>();
                        List<String> exts = new ArrayList<>();
                        for (int i = 0; i < jsonImages.length(); i++) {
                            String imageUrl = jsonImages.getString(i);
                            String imageExtension = getImageExtension(imageUrl);
                            if (imageExtension == null) imageExtension = ".jpg";
                            imgUrls.add(imageUrl);
                            exts.add(imageExtension);
                        }
                        if(!imgUrls.isEmpty()) showMultiMediaPreviewDialog(imgUrls, exts, "LinkedIn_image_" + System.currentTimeMillis());
                    } else if (obj.has("image") && obj.getJSONObject("image").has("url")) {
                        String imageUrl = obj.getJSONObject("image").getString("url");
                        String imageExtension = getImageExtension(imageUrl);
                        if (imageExtension == null) imageExtension = ".jpg";
                        startDownloadWithPreview(imageUrl, "LinkedIn_image_" + System.currentTimeMillis(), imageExtension);
                    }
                } catch (Exception e) { }
                return null;
            }
        }
    }

    public static class CallgaanaData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            return this.RoposoDoc;
        }
        public void onPostExecute(Document document) {
            dismissMyDialog();
        }
    }

    public static class CallgdriveData extends AsyncTask<String, Void, String> {
        String VideoUrl = "";
        LowCostVideo xGetter;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            this.xGetter = new LowCostVideo(Mcontext);
            this.xGetter.onFinish(new LowCostVideo.OnTaskCompleted() {
                public void onTaskCompleted(ArrayList<XModel> arrayList, boolean z) {
                    if (!z) { CallgdriveData.this.done(arrayList.get(0)); }
                    else if (arrayList != null) { CallgdriveData.this.multipleQualityDialog(arrayList); }
                    else { dismissMyDialog(); }
                }
                public void onError() { dismissMyDialog(); }
            });
        }
        public String doInBackground(String... strArr) { return strArr[0]; }

        public void onPostExecute(String str) {
            if (xGetter != null) {
                this.xGetter.find(str);
            } else {
                this.xGetter = new LowCostVideo(Mcontext);
                this.xGetter.onFinish(new LowCostVideo.OnTaskCompleted() {
                    public void onTaskCompleted(ArrayList<XModel> arrayList, boolean z) {
                        if (!z) { CallgdriveData.this.done(arrayList.get(0)); }
                        else if (arrayList != null) { CallgdriveData.this.multipleQualityDialog(arrayList); }
                        else { dismissMyDialog(); }
                    }
                    public void onError() { dismissMyDialog(); }
                });
                this.xGetter.find(str);
            }
        }

        public void multipleQualityDialog(final ArrayList<XModel> arrayList) {
            CharSequence[] charSequenceArr = new CharSequence[arrayList.size()];
            for (int i = 0; i < arrayList.size(); i++) {
                charSequenceArr[i] = arrayList.get(i).getQuality();
            }
            if (!Mcontext.isFinishing()) {
                new AlertDialog.Builder(Mcontext).setTitle("Quality!").setItems(charSequenceArr, (dialogInterface, i) -> CallgdriveData.this.done(arrayList.get(i))).setPositiveButton("OK", (dialogInterface, i) -> dismissMyDialog()).setCancelable(false).show();
            }
        }

        public void done(XModel xModel) {
            try {
                dismissMyDialog();
                this.VideoUrl = xModel.getUrl();
                if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                    startDownloadWithPreview(VideoUrl, "Allvideo_" + System.currentTimeMillis(), ".mp4");
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class callGetsnackvideoData extends AsyncTask<String, Void, JSONObject> {
        JSONObject snackvideoDoc;
        @Override
        protected void onPreExecute() { super.onPreExecute(); }
        @Override
        protected JSONObject doInBackground(String... urls) {
            try {
                String photoId, authorId;
                String location = iUtils.getRedirectUrl(urls[0]);
                if (location.contains("?")) location = location.split("\\?")[0];
                if (location != null) {
                    authorId = location.split("/")[4];
                    photoId = location.split("/")[5];
                } else {
                    location = urls[0];
                    authorId = location.split("/")[4];
                    photoId = location.split("/")[5];
                }
                snackvideoDoc = new JSONObject("{\"photoId\":\"" + photoId + "\",\"authorId\":\"" + authorId + "\"}");
            } catch (Exception e) { }
            return snackvideoDoc;
        }

        @Override
        protected void onPostExecute(JSONObject result) {
            try {
                AndroidNetworking.post("https://m.snackvideo.com/rest/o/w/photo/getUserHotPhoto?kpn=KWAI_BULLDOG")
                        .addJSONObjectBody(result)
                        .addHeaders("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36")
                        .addHeaders("x-csrf-token", "Acn4pAjr5lT5AT6OBjzyB9VP")
                        .setPriority(Priority.MEDIUM)
                        .build()
                        .getAsJSONObject(new JSONObjectRequestListener() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    VideoUrl = response.getJSONArray("datas").getJSONObject(0).getString("mp4Url");
                                    startDownloadWithPreview(VideoUrl, "snackvideo_" + System.currentTimeMillis(), ".mp4");
                                    VideoUrl = "";
                                    dismissMyDialog();
                                } catch (Exception e) { dismissMyDialogErrortoast(); }
                            }
                            @Override
                            public void onError(ANError error) { dismissMyDialogErrortoast(); }
                        });
            } catch (Exception e) {
                dismissMyDialogErrortoast();
            }
        }
    }

    private static class callGetbilibiliAppData extends AsyncTask<String, Void, Document> {
        Document ShareChatDoc;
        private Iterator<Element> abk;
        callGetbilibiliAppData() { }

        protected void onPreExecute() { super.onPreExecute(); }
        protected Document doInBackground(String... strArr) {
            try { this.ShareChatDoc = Jsoup.connect(strArr[0]).get(); } catch (Exception strArr2) { }
            return this.ShareChatDoc;
        }
        protected void onPostExecute(Document document) {
            try {
                ArrayList<String> mp4List = new ArrayList<>();
                ArrayList<String> qualitylist = new ArrayList<>();
                String data = "";
                Iterator<Element> documentitrator = document.select("script").iterator();
                do {
                    if (!documentitrator.hasNext()) break;
                    data = documentitrator.next().data();
                } while (!data.contains("window.__playinfo__="));

                String stringbuil = data.substring(data.indexOf("{"), data.lastIndexOf("}"));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(stringbuil);
                stringBuilder.append("}");

                if (!document.equals("")) {
                    try {
                        JSONObject jSONObject = new JSONObject(stringBuilder.toString());
                        JSONObject datajSONObject = jSONObject.getJSONObject("data");
                        JSONObject dashjSONObject1 = datajSONObject.getJSONObject("dash");
                        JSONArray videojSONObject1 = dashjSONObject1.getJSONArray("video");

                        for (int i = 0; i < videojSONObject1.length(); i++) {
                            JSONObject jsonObject12 = videojSONObject1.getJSONObject(i);
                            mp4List.add(jsonObject12.getString("base_url"));
                            qualitylist.add(jsonObject12.getString("width"));
                        }
                        try {
                            JSONArray audiojSONObject1 = dashjSONObject1.getJSONArray("audio");
                            for (int i = 0; i < audiojSONObject1.length(); i++) {
                                JSONObject jsonObject12 = audiojSONObject1.getJSONObject(i);
                                mp4List.add(jsonObject12.getString("base_url"));
                                qualitylist.add(jsonObject12.getString("mime_type"));
                            }
                        } catch (Exception e) { }

                        if (videojSONObject1.length() > 0) {
                            if (!((Activity) Mcontext).isFinishing()) {
                                dialog_quality_allvids = new Dialog(Mcontext);
                                dismissMyDialog();
                                windowManager2 = (WindowManager) Mcontext.getSystemService(WINDOW_SERVICE);
                                LayoutInflater layoutInflater = (LayoutInflater) Mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                                mChatHeadView = layoutInflater.inflate(R.layout.dialog_quality_ytd, null);
                                dialog_quality_allvids.setContentView(mChatHeadView);

                                mainLayout = mChatHeadView.findViewById(R.id.linlayout_dialog);
                                img_dialog = mChatHeadView.findViewById(R.id.img_dialog);

                                int size = 0;
                                try {
                                    DisplayMetrics displayMetrics = new DisplayMetrics();
                                    ((Activity) Mcontext).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                                    size = displayMetrics.widthPixels / 2;
                                } catch (Exception e) { size = WindowManager.LayoutParams.WRAP_CONTENT; }

                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    params = new WindowManager.LayoutParams(
                                            size, WindowManager.LayoutParams.WRAP_CONTENT,
                                            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                                            PixelFormat.TRANSLUCENT);
                                } else {
                                    params = new WindowManager.LayoutParams(
                                            size, WindowManager.LayoutParams.WRAP_CONTENT,
                                            WindowManager.LayoutParams.TYPE_PHONE,
                                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                                            PixelFormat.TRANSLUCENT);
                                }
                                params.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
                                params.x = 0; params.y = 100;

                                for (int i = 0; i < mp4List.size(); i++) {
                                    addButtonToMainLayouttest_allvideo(qualitylist.get(i), mp4List.get(i), "Bilibili_" + qualitylist.get(i) + "_" + System.currentTimeMillis());
                                }

                                img_dialog.setOnClickListener(v -> dialog_quality_allvids.dismiss());
                                dialog_quality_allvids.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
                                dialog_quality_allvids.getWindow().setAttributes(params);
                                dialog_quality_allvids.show();
                            }
                        } else {
                            startDownloadWithPreview(mp4List.get(0), "Bilibili_" + System.currentTimeMillis(), ".mp4");
                            dismissMyDialog();
                        }
                    } catch (Exception document2) {
                        dismissMyDialog();
                    }
                }
            } catch (Exception document22) {
                dismissMyDialog();
            }
        }
    }

    public static class Call9gagData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        public Document doInBackground(String... strArr) {
            OkHttpClient client = new OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).writeTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
            okhttp3.Request request = new okhttp3.Request.Builder().url(strArr[0]).method("GET", null).build();
            try {
                okhttp3.Response response = client.newCall(request).execute();
                return this.RoposoDoc = Jsoup.parse(Objects.requireNonNull(response.body()).string());
            } catch (IOException e) { return this.RoposoDoc; }
        }
        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                Iterator it = document.getElementsByTag("script").iterator();
                while (it.hasNext()) {
                    Element element = (Element) it.next();
                    if (element.data().contains("window.__STATE__")) {
                        String replace = element.html().replace("window.__STATE__", "").replace(";", "").replace("=", "");
                        this.VideoUrl = String.valueOf(new JSONObject(new JSONObject(new JSONArray("[" + replace + "]").get(0).toString()).getJSONObject("feed").getJSONArray("feed").get(0).toString()).get("download_media"));
                        if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                            startDownloadWithPreview(VideoUrl, "hindvideo_" + System.currentTimeMillis(), ".mp4");
                            return;
                        }
                    }
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }

    public static class CallkuaishouData extends AsyncTask<String, Void, Document> {
        Document RoposoDoc;
        String VideoUrl = "";
        private String getCookiesFromWebsite(String websiteUrl) {
            try {
                URL url = new URL(websiteUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                Map<String, List<String>> headerFields = connection.getHeaderFields();
                List<String> cookiesHeader = headerFields.get("Set-Cookie");
                if (cookiesHeader != null) {
                    StringBuilder cookies = new StringBuilder();
                    for (String cookie : cookiesHeader) cookies.append(cookie).append("; ");
                    return cookies.toString();
                }
            } catch (IOException e) { }
            return "";
        }

        public Document doInBackground(String... strArr) {
            try {
                String tempCookies = getCookiesFromWebsite("https://www.kuaishou.com/");
                ClearableCookieJar cookieJar = new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(Mcontext));
                HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
                logging.setLevel(HttpLoggingInterceptor.Level.BODY);
                OkHttpClient client = new OkHttpClient.Builder().cookieJar(cookieJar).addInterceptor(logging).connectTimeout(10, TimeUnit.SECONDS).writeTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

                okhttp3.Request request = new okhttp3.Request.Builder()
                        .url(strArr[0])
                        .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
                        .addHeader("Cookie", tempCookies)
                        .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36")
                        .build();

                okhttp3.Response response = client.newCall(request).execute();
                return this.RoposoDoc = Jsoup.parse(Objects.requireNonNull(response.body()).string());
            } catch (IOException e) { return this.RoposoDoc; }
        }

        public void onPostExecute(Document document) {
            try {
                dismissMyDialog();
                Iterator it = document.getElementsByTag("script").iterator();
                while (it.hasNext()) {
                    Element element = (Element) it.next();
                    if (element.data().contains("window.__APOLLO_STATE__=")) {
                        String replace = element.html().replace("window.__APOLLO_STATE__=", "");
                        replace = replace.substring(0, replace.indexOf("{}};") + 3);
                        String sr = StringUtils.substringBetween(replace, "\"videoResource\"", "\"__typename\"");
                        sr = sr.substring(1, sr.length() - 1);

                        this.VideoUrl = new JSONObject(sr).getJSONObject("json").getJSONObject("h264").getJSONArray("adaptationSet").getJSONObject(0).getJSONArray("representation").getJSONObject(0).getString("url");
                        this.VideoUrl = URLDecoder.decode(this.VideoUrl, "UTF-8");

                        if (this.VideoUrl != null && !this.VideoUrl.equals("")) {
                            startDownloadWithPreview(VideoUrl, "kuaishou_" + System.currentTimeMillis(), ".mp4");
                            return;
                        }
                    }
                }
            } catch (Exception unused) {
                dismissMyDialog();
            }
        }
    }
}