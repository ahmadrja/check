package com.allvideodown.socialdownloader

import android.content.Context
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import androidx.multidex.MultiDexApplication
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.allvideodown.socialdownloader.receiver.DownloadBroadcastReceiver
import com.allvideodown.socialdownloader.utils.AdsManager
import com.allvideodown.socialdownloader.utils.AppOpenManager
import com.allvideodown.socialdownloader.utils.Constants
import com.allvideodown.socialdownloader.utils.LocaleHelper
import com.allvideodown.socialdownloader.utils.PrefsCoins
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp
import com.allvideodown.socialdownloader.utils.iUtils
import com.onesignal.OneSignal
import io.reactivex.rxjava3.exceptions.UndeliverableException
import io.reactivex.rxjava3.plugins.RxJavaPlugins
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AppController : MultiDexApplication() {
    var appOpenManager: AppOpenManager? = null
    private var firebaseRemoteConfig: FirebaseRemoteConfig? = null

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.onAttach(base))
    }

    override fun onCreate() {
        super.onCreate()
        // Initialize OneSignal on the main thread
        initializeOneSignal()
        // Launch coroutine for initialization
        CoroutineScope(Dispatchers.Default).launch {
            initializeApplication()
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(
                    DownloadBroadcastReceiver(),
                    IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"),
                    RECEIVER_EXPORTED
                )
            } else {
                registerReceiver(
                    DownloadBroadcastReceiver(),
                    IntentFilter("android.intent.action.DOWNLOAD_COMPLETE")
                )
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }


    override fun onTerminate() {
        super.onTerminate()
        AdsManager.cleanup(applicationContext)
    }

    private suspend fun initializeApplication() {
        withContext(Dispatchers.Default) {
            try {
                configureRxJavaErrorHandler()
                // Add network monitoring initialization here
                AdsManager.initNetworkMonitoring(applicationContext)
                initializeAds()
                initializeCoins()
                initializeFirebase()
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    private fun initializeCoins() {
        try {
            val prefs = PrefsCoins(applicationContext)

            if (prefs.premium == 1) {
                if (System.currentTimeMillis() < prefs.getLong(
                        "time",
                        System.currentTimeMillis()
                    )
                ) {
                    SharedPrefsMainApp(applicationContext).preferencE_inappads = "ppp"
                    prefs.premium = 1
                } else {
                    SharedPrefsMainApp(applicationContext).preferencE_inappads = "nnn"
                    prefs.premium = 0
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }

    private fun configureRxJavaErrorHandler() {
        RxJavaPlugins.setErrorHandler { e: Throwable ->
            var error = e
            if (error is UndeliverableException) {
                error = error.cause ?: error
            }
            if (error !is InterruptedException) {
                Log.e("configureRxJavaErrorHandler", "Undeliverable exception received", error)
            }
        }
    }

    private suspend fun initializeAds() {
        withContext(Dispatchers.Default) {
            if (!BuildConfig.DEBUG) {
                if (!Constants.iSAdminAttached) {
                    fetchRemoteTitle()
                }
            } else if (Constants.enableTestAds) {
                setTestAdsIds()
            }

            AudienceNetworkAds.initialize(applicationContext)
            MobileAds.initialize(applicationContext) { _ ->
                appOpenManager = AppOpenManager(this@AppController)
            }
        }
    }

    private fun setTestAdsIds() {
        AdsManager.apply {
            videoapp_AdmobNativeID = "ca-app-pub-3940256099942544/2247696110"
            videoapp_AdmobRewardVideoExtraFeatures = "ca-app-pub-3940256099942544/5224354917"
            videoapp_AdmobRewardID = "ca-app-pub-3940256099942544/5224354917"
            videoapp_AdmobInterstitial = "ca-app-pub-3940256099942544/1033173712"
            videoapp_AdmobBanner = "ca-app-pub-3940256099942544/6300978111"
            videoapp_AdmobAppId = "ca-app-pub-3940256099942544~3347511713"
        }
    }

    private suspend fun initializeFirebase() {
        withContext(Dispatchers.IO) {
            FirebaseMessaging.getInstance().subscribeToTopic("all")

            firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
            firebaseRemoteConfig?.setDefaultsAsync(R.xml.remote_config_defaults)

            val configBuilder = FirebaseRemoteConfigSettings.Builder()
            if (BuildConfig.DEBUG) {
                configBuilder.setMinimumFetchIntervalInSeconds(0)
            }
            firebaseRemoteConfig?.setConfigSettingsAsync(configBuilder.build())
        }
    }

    private fun initializeOneSignal() {
        try {
            OneSignal.initWithContext(
                applicationContext,
                applicationContext.resources.getString(R.string.onsignalappid)
            )

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private suspend fun fetchRemoteTitle() {
        withContext(Dispatchers.IO) {
            firebaseRemoteConfig?.let { config ->
                AdsManager.apply {
                    videoapp_AdmobNativeID = config.getString("videoapp_AdmobNativeID")
                    videoapp_AdmobRewardID = config.getString("videoapp_AdmobRewardID")
                    videoapp_AdmobRewardVideoExtraFeatures =
                        config.getString("videoapp_AdmobRewardVideoExtraFeatures")
                    videoapp_AdmobInterstitial = config.getString("videoapp_AdmobInterstitial")
                    videoapp_AdmobBanner = config.getString("videoapp_AdmobBanner")
                    videoapp_AdmobAppId = config.getString("videoapp_AdmobAppId")
                }
                iUtils.isNonPlayStoreApp = config.getBoolean("isNonPlayStoreApp")

                try {
                    config.fetchAndActivate().await()
                    // Handle successful fetch if needed
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.e("fetchRemoteTitle", "Failed to fetch remote config", e)
                }
            }
        }
    }
}
