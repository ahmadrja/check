/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023-2026 . All rights reserved.
 *
 */

package com.allvideodown.socialdownloader.receiver;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.services.MyFirebaseMessagingService;

public class DownloadBroadcastReceiver extends BroadcastReceiver {
    public static boolean isFirstTimeDownload = false;

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);

            if (downloadId == -1)
                return;

            // query download status
            Cursor cursor = downloadManager.query(new DownloadManager.Query().setFilterById(downloadId));
            if (cursor != null && cursor.moveToFirst()) {
                @SuppressLint("Range") int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));

                if (status == DownloadManager.STATUS_SUCCESSFUL) {

                    // --- FIX: Media Scanner for Gallery Sync (Issue 2) ---
                    @SuppressLint("Range") String uriString = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
                    @SuppressLint("Range") String mimeType = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE));

                    if (uriString != null) {
                        String filePath = Uri.parse(uriString).getPath();
                        if (filePath != null) {
                            // यह कोड फाइल को तुरंत फोन की गैलरी में शो कर देगा
                            MediaScannerConnection.scanFile(context,
                                    new String[]{filePath},
                                    new String[]{mimeType != null ? mimeType : "video/mp4"},
                                    (path, uri) -> Log.i("GalleryFix", "Scanned " + path + ": -> uri=" + uri)
                            );
                        }
                    }
                    // -----------------------------------------------------

                    // download is successful notification
                    if (!isFirstTimeDownload) {
                        DownloadBroadcastReceiver.isFirstTimeDownload = true;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            MyFirebaseMessagingService.sendOreoNotification(context, context.getResources().getString(R.string.app_name), context.getResources().getString(R.string.yourdoncomple));
                        } else {
                            MyFirebaseMessagingService.sendNotification(context, context.getResources().getString(R.string.app_name), context.getResources().getString(R.string.yourdoncomple));
                        }
                    }
                } else if (status == DownloadManager.STATUS_FAILED) {
                    Log.d("DownloadReceiver", "Download Failed");
                }
                cursor.close();
            } else {
                Log.d("DownloadReceiver", "Cursor empty or null");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
}