/*
 * *
 * * Created by Syed Usama Ahmad
 * * Master Updated for Premium UX & Logo Animations (Android 12+ Fix)
 *
 */

package com.allvideodown.socialdownloader.activities;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Toast;

import androidx.annotation.Keep;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.ConfigurationCompat;

import com.google.android.gms.tasks.Task;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.allvideodown.socialdownloader.BuildConfig;
import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.activities.newUi.MainActivityNewUi;
import com.allvideodown.socialdownloader.databinding.ActivitySplashScreenBinding;
import com.allvideodown.socialdownloader.models.adminpanel.AdId;
import com.allvideodown.socialdownloader.models.adminpanel.AppSettings;
import com.allvideodown.socialdownloader.models.adminpanel.Setting;
import com.allvideodown.socialdownloader.models.adminpanel.SocialMedia;
import com.allvideodown.socialdownloader.onboarding.OnboardingActivity;
import com.allvideodown.socialdownloader.utils.AdsManager;
import com.allvideodown.socialdownloader.utils.Constants;
import com.allvideodown.socialdownloader.utils.GlideApp;
import com.allvideodown.socialdownloader.utils.LocaleHelper;
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp;
import com.allvideodown.socialdownloader.utils.iUtils;
import com.libs.androidnetworking.AndroidNetworking;
import com.libs.androidnetworking.common.Priority;
import com.libs.androidnetworking.error.ANError;
import com.libs.androidnetworking.interfaces.JSONObjectRequestListener;
import com.yausername.ffmpeg.FFmpeg;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLException;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.Executors;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Completable;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.CompositeDisposable;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.exceptions.UndeliverableException;
import io.reactivex.rxjava3.observers.DisposableCompletableObserver;
import io.reactivex.rxjava3.plugins.RxJavaPlugins;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class SplashScreen extends AppCompatActivity {

    AppUpdateManager appUpdateManager;
    boolean isScreenShitStarted = false;
    androidx.core.splashscreen.SplashScreen splashScreen;

    static void initDlLibs(Context context, boolean isStart) throws YoutubeDLException {
        try {
            YoutubeDL.getInstance().init(context);
            FFmpeg.getInstance().init(context);

            if (isStart && Constants.showyoutube) {
                updateYoutubeDL(context);
            }
        } catch (Throwable e) {
            Log.e("SplashScreenError", "failed ", e);
            e.printStackTrace();
        }
    }

    InstallStateUpdatedListener installStateUpdatedListener = new InstallStateUpdatedListener() {
        @Override
        public void onStateUpdate(InstallState state) {
            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                Log.i("SplashScreen", "InstallStateUpdatedListener: download complete");
            } else if (state.installStatus() == InstallStatus.INSTALLED) {
                if (appUpdateManager != null) {
                    appUpdateManager.unregisterListener(installStateUpdatedListener);
                }
            } else if (state.installStatus() == InstallStatus.FAILED) {
                if (appUpdateManager != null) {
                    appUpdateManager.unregisterListener(installStateUpdatedListener);
                }
            }
        }
    };

    static void updateYoutubeDL(Context context) {
        if (!shouldUpdate(context)) {
            return;
        }

        final CompositeDisposable compositeDisposable = new CompositeDisposable();
        Disposable disposable = Observable.fromCallable(() -> YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel._NIGHTLY))
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(status -> {
                    // Handled in background
                }, e -> {
                    if (BuildConfig.DEBUG) Log.e("SplashScreen", "failed to update", e);
                });
        compositeDisposable.add(disposable);
    }

    private static boolean shouldUpdate(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("whatsapp_pref", Context.MODE_PRIVATE);
            long lastUpdateTime = prefs.getLong("last_update_time_dlp", 0);
            long currentTime = System.currentTimeMillis();

            if (currentTime - lastUpdateTime >= 24 * 60 * 60 * 1000) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putLong("last_update_time_dlp", currentTime);
                return editor.commit();
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    @Keep
    public static void getExistingAdminPanelData(Context context) {
        if (new SharedPrefsMainApp(context) != null && new SharedPrefsMainApp(context).getPREFERENCE_adminpanelapidata() != null && Constants.iSAdminAttached) {
            AppSettings appSettings = new SharedPrefsMainApp(context).getPREFERENCE_adminpanelapidata();
            if (appSettings.getAdIds() != null) {
                AdId adId = appSettings.getAdIds().get(0);
                AdsManager.status_AdmobBanner = adId.getBannerIDStatus();
                AdsManager.status_AdmobInterstitial = adId.getIntIDStatus();
                AdsManager.status_AdmobRewardID = adId.getRewardVideoIDStatus();
                AdsManager.status_AdmobNativeID = adId.getNativeAdIDStatus();
                AdsManager.NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION = adId.getIntClicks();

                if (Constants.enableTestAds) {
                    AdsManager.setDefaults((Application) context);
                } else {
                    AdsManager.videoapp_AdmobNativeID = adId.getNativeAdID();
                    AdsManager.videoapp_AdmobRewardID = adId.getRewardVideoID();
                    AdsManager.videoapp_AdmobRewardVideoExtraFeatures = adId.getRewardVideoID();
                    AdsManager.videoapp_AdmobInterstitial = adId.getIntID();
                    AdsManager.videoapp_AdmobBanner = adId.getBannerID();
                    AdsManager.videoapp_AdmobAppId = context.getResources().getString(R.string.AdmobAppId);
                }

                Setting setting = appSettings.getSettings().get(0);
                iUtils.isNewUi = setting.getNewUi();
                iUtils.myAppSettings = setting;
            }

            if (appSettings.getSocialMedias() != null) {
                if (iUtils.socialMediaList != null) {
                    iUtils.socialMediaList.clear();
                } else {
                    iUtils.socialMediaList = new ArrayList<>();
                }
                for (SocialMedia socialMedia : appSettings.getSocialMedias()) {
                    if (socialMedia.getStatus() == 1) {
                        iUtils.socialMediaList.add(socialMedia.getSource().toLowerCase());
                    }
                }
            }
        }
    }

    @Keep
    public static void checkExistingAppDataFromAdminPanelAndSetData(Context context) {
        AndroidNetworking.get(Constants.adminApiUrl + "/all")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response.toString());
                            if (jsonObject.getBoolean("status")) {
                                new SharedPrefsMainApp(context).setPREFERENCE_adminpanelapidata(response.toString());
                                AppSettings appSettings = new SharedPrefsMainApp(context).getPREFERENCE_adminpanelapidata();

                                // Process Admin Data
                                if (appSettings.getAdIds() != null) {
                                    AdId adId = appSettings.getAdIds().get(0);
                                    AdsManager.status_AdmobBanner = adId.getBannerIDStatus();
                                    AdsManager.status_AdmobInterstitial = adId.getIntIDStatus();
                                    AdsManager.status_AdmobRewardID = adId.getRewardVideoIDStatus();
                                    AdsManager.status_AdmobNativeID = adId.getNativeAdIDStatus();
                                    AdsManager.NUMBER_OF_INTERSTISHAL_ADS_PER_SESSION = adId.getIntClicks();

                                    if (Constants.enableTestAds) {
                                        AdsManager.setDefaults((Application) context);
                                    } else {
                                        AdsManager.videoapp_AdmobNativeID = adId.getNativeAdID();
                                        AdsManager.videoapp_AdmobRewardID = adId.getRewardVideoID();
                                        AdsManager.videoapp_AdmobRewardVideoExtraFeatures = adId.getRewardVideoID();
                                        AdsManager.videoapp_AdmobInterstitial = adId.getIntID();
                                        AdsManager.videoapp_AdmobBanner = adId.getBannerID();
                                        AdsManager.videoapp_AdmobAppId = context.getResources().getString(R.string.AdmobAppId);
                                    }
                                    Setting setting = appSettings.getSettings().get(0);
                                    iUtils.isNewUi = setting.getNewUi();
                                    iUtils.myAppSettings = setting;
                                }

                                if (appSettings.getSocialMedias() != null) {
                                    if (iUtils.socialMediaList != null) {
                                        iUtils.socialMediaList.clear();
                                    } else {
                                        iUtils.socialMediaList = new ArrayList<>();
                                    }
                                    for (SocialMedia socialMedia : appSettings.getSocialMedias()) {
                                        if (socialMedia.getStatus() == 1) {
                                            iUtils.socialMediaList.add(socialMedia.getSource().toLowerCase());
                                        }
                                    }
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            getExistingAdminPanelData(context);
                        }
                    }

                    @Override
                    public void onError(ANError error) {
                        getExistingAdminPanelData(context);
                    }
                });
    }

    @Keep
    public static void uploadDownloadedUrl(String myUrl) {
        if (Constants.iSAdminAttached) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("download_url", myUrl);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            AndroidNetworking.post(Constants.adminApiUrl + "/downloadedurl")
                    .addJSONObjectBody(jsonObject)
                    .setPriority(Priority.MEDIUM)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) { }

                        @Override
                        public void onError(ANError error) { }
                    });
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Handle Android 12+ Splash Screen API seamlessly
        if (Build.VERSION.SDK_INT >= 31) {
            splashScreen = androidx.core.splashscreen.SplashScreen.installSplashScreen(this);
        }

        super.onCreate(savedInstanceState);

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        ActivitySplashScreenBinding binding = ActivitySplashScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        isScreenShitStarted = false;

        try {
            // ----- PREMIUM UI ANIMATIONS START -----
            startPremiumAnimations(binding);
            // ----- PREMIUM UI ANIMATIONS END -----

            appUpdateManager = AppUpdateManagerFactory.create(SplashScreen.this);
            appUpdateManager.registerListener(installStateUpdatedListener);

            binding.version.setText(String.format("%s %s\nBy: %s", getString(R.string.version), BuildConfig.VERSION_NAME, getString(R.string.developer_name)));
            if (com.allvideodown.socialdownloader.BuildConfig.ISPRO) {
                GlideApp.with(SplashScreen.this)
                        .load(R.drawable.ic_appicon_pro)
                        .placeholder(R.drawable.ic_appicon_pro)
                        .into(binding.iconmain);
            }
            AdsManager.setDefaults(getApplication());

            Executors.newSingleThreadExecutor().submit(() -> {
                try {
                    iUtils.myInstagramTempCookies = iUtils.showCookies("https://www.instagram.com/");
                    if (Constants.iSAdminAttached) {
                        getAppDataFromAdminPanel();
                    }
                } catch (Throwable e) {
                    e.printStackTrace();
                    goToMainAndFinish();
                }
            });

            setDefaultLanguage();
            configureRxJavaErrorHandler();

            Completable.fromAction(() -> initLibraries(SplashScreen.this))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new DisposableCompletableObserver() {
                        @Override
                        public void onComplete() {
                            Log.e("configureRxJava", "Done");
                        }

                        @Override
                        public void onError(Throwable e) {
                            if (BuildConfig.DEBUG) {
                                Toast.makeText(getApplicationContext(), "init failed: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        } catch (Throwable e) {
            e.printStackTrace();
            goToMainAndFinish();
        }

        // NOTE: The freeze code for Android 12+ has been completely removed from here!
    }

    // --- PREMIUM ANIMATION METHOD ---
    private void startPremiumAnimations(ActivitySplashScreenBinding binding) {
        // 1. Logo Animation (Zoom in with Bounce)
        binding.iconmain.setAlpha(0f);
        binding.iconmain.setScaleX(0.7f);
        binding.iconmain.setScaleY(0.7f);

        binding.iconmain.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(1200)
                .setInterpolator(new OvershootInterpolator(1.2f)) // Bouncy effect
                .start();

        // 2. Full Loader & Version Animation (Slide up and fade in perfectly)
        binding.bottomLoaderLayout.setAlpha(0f);
        binding.bottomLoaderLayout.setTranslationY(60f); // Start slightly lower

        binding.bottomLoaderLayout.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(1000)
                .setStartDelay(400) // Delay to start after logo pops
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    void setDefaultLanguage() {
        try {
            SharedPreferences prefs = getSharedPreferences("lang_pref", MODE_PRIVATE);
            String deviceLang = Objects.requireNonNull(ConfigurationCompat.getLocales(Resources.getSystem().getConfiguration()).get(0)).getLanguage();
            String lang = prefs.getString("lang", deviceLang);

            if (!deviceLang.equals(lang)) {
                SharedPreferences sharedPreference = getSharedPreferences("lang_pref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreference.edit();
                editor.putString("lang", deviceLang);
                editor.apply();
                lang = deviceLang;
            }
            LocaleHelper.setLocale(getApplicationContext(), lang);
            if (lang.equals("ur") || lang.equals("ar")) {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            } else {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void configureRxJavaErrorHandler() {
        RxJavaPlugins.setErrorHandler(e -> {
            if (e instanceof UndeliverableException) {
                e = e.getCause();
            }
            if (e instanceof InterruptedException) {
                return;
            }
            Log.e("RxJavaError", "Undeliverable exception received", e);
        });
    }

    private void initLibraries(Context context) throws YoutubeDLException {
        try {
            initDlLibs(context, true);
            if (!BuildConfig.DEBUG) {
                checkAppUpdate();
            } else {
                goToMainAndFinish();
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!BuildConfig.DEBUG) {
            appUpdateManager.getAppUpdateInfo().addOnSuccessListener(appUpdateInfo -> {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(
                                appUpdateInfo, AppUpdateType.IMMEDIATE, SplashScreen.this, 1009);
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();
                    }
                }
            });
        } else {
            goToMainAndFinish();
        }
    }

    private void goToMainAndFinish() {
        if (!isScreenShitStarted) {
            isScreenShitStarted = true;
            // Increased delay to 2500ms so users can fully enjoy the premium animation
            new Handler(Looper.getMainLooper()).postDelayed(() -> {

                boolean isFirstTime = new SharedPrefsMainApp(SplashScreen.this).getPREFERENCE_isFirstTime();

                if (isFirstTime) {
                    startActivity(new Intent(SplashScreen.this, OnboardingActivity.class));
                } else {
                    if (iUtils.isNewUi) {
                        startActivity(new Intent(SplashScreen.this, MainActivityNewUi.class));
                    } else {
                        startActivity(new Intent(SplashScreen.this, MainActivity.class));
                    }
                }
                finish();

            }, 2500); // <-- Time increased for premium feel
        }
    }

    public void checkAppUpdate() {
        try {
            Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
            appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    try {
                        appUpdateManager.startUpdateFlowForResult(
                                appUpdateInfo, AppUpdateType.IMMEDIATE, SplashScreen.this, 1009);
                    } catch (IntentSender.SendIntentException e) {
                        e.printStackTrace();
                    }
                } else {
                    goToMainAndFinish();
                }
            }).addOnFailureListener(e -> {
                goToMainAndFinish();
            });

        } catch (Exception e) {
            goToMainAndFinish();
        }
    }

    @Keep
    public void getAppDataFromAdminPanel() {
        JSONObject jsonObject = new JSONObject();
        try {
            @SuppressLint("HardwareIds") String android_id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiInfo wInfo = wifiManager.getConnectionInfo();
            @SuppressLint("HardwareIds") String macAddress = wInfo.getBSSID();

            jsonObject.put("macAddress", macAddress);
            jsonObject.put("deviceId", android_id);
            jsonObject.put("packageName", BuildConfig.APPLICATION_ID);
            jsonObject.put("appVersion", BuildConfig.VERSION_NAME);
            jsonObject.put("appBuildNo", BuildConfig.VERSION_CODE);
            if (new SharedPrefsMainApp(SplashScreen.this) != null && new SharedPrefsMainApp(SplashScreen.this).getPREFERENCE_adminpanelapidata() != null && Constants.iSAdminAttached) {
                jsonObject.put("isFirstBoolean", "0");
            } else {
                jsonObject.put("isFirstBoolean", "1");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        AndroidNetworking.post(Constants.adminApiUrl + "/storeanalytics")
                .addJSONObjectBody(jsonObject)
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {}

                    @Override
                    public void onError(ANError error) {}
                });

        checkExistingAppDataFromAdminPanelAndSetData(SplashScreen.this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1009) {
            goToMainAndFinish();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        newBase = LocaleHelper.onAttach(newBase);
        super.attachBaseContext(newBase);
    }
}